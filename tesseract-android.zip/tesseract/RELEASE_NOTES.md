1.32.0 — Earnings by place labels places by where they are.

- The label under each place was the state its most recent worked day was
  earned in, so one travel day earned in Virginia relabeled the Florida
  residence "VA". It now shows the state the datum sits in (read from the
  fixes inside it) and its role: "Residence · FL · residence".
- A datum only takes pay earned in its own state. The morning you leave the
  Oviedo residence and start in Virginia is Virginia pay; it now goes to the
  Virginia duty station if the day touched it, otherwise "Elsewhere in VA",
  never to the residence. The CSV's work_place column follows the same rule.
- Datums › Re-match past fixes: a datum added or moved after the fact (the
  Pentagon) now can reach back over fixes already logged. Previewed first,
  tap twice to apply, and undoable — each fix keeps its original tag. Only the
  datum tag changes, never the state, time or coordinates.
- Datum radius keeps decimals (0.3 mi) on screen and on re-save; it used to
  show and re-save as a whole number.

1.31.3 — Needs review only lists days that still need you, with the reason.

package com.tesseract.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        Notifier.createChannels(this)
        Store.seedDefaultCategories(this)
        Scheduler.scheduleNextCheck(this)
        Scheduler.scheduleMonthlyReport(this)
    }
}

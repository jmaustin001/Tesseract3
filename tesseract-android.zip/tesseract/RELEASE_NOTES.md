Wage allocation, in Reports.

Enter your gross wages and the app works the nonresident allocation: days
worked in the counted state over days worked anywhere, applied to the W-2
figure. It shows the ratio, the allocated wages, and the implied daily and
hourly rates.

It also shows how solid the figure is — days with no location data, days never
categorized, worked days with no fix during duty hours, days set by hand. A
number without its weak spots attached is worth less than no number.

The output is a plain-language worksheet, not a filled tax form. It states the
method, shows every count, and explains how each figure was reached, so a CPA
can check the reasoning rather than trust the arithmetic. Tax forms change
yearly and a wrong box filled confidently is worse than a clean worksheet.

Worth knowing, and stated in the app: staying under the day threshold does not
stop a state taxing wages earned there. It keeps that state to those wages
rather than all of your income.

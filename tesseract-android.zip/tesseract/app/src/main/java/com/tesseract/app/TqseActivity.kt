package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class TqseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { TqseScreen() } }
    }
}

private fun cash(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)
private val MONTHS_T = listOf("Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec")

@Composable
private fun TqseScreen() {
    val ctx = LocalContext.current

    var method by remember { mutableIntStateOf(0) }        // 0 = LP, 1 = LS
    var days by remember { mutableStateOf("30") }
    var lodgingMax by remember { mutableStateOf("199") }
    var mieMax by remember { mutableStateOf("92") }
    var actualLodging by remember { mutableStateOf("180") }
    var over12 by remember { mutableStateOf("0") }
    var under12 by remember { mutableStateOf("0") }
    var dependents by remember { mutableStateOf("0") }
    var month by remember {
        mutableIntStateOf(java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1)
    }
    var locTick by remember { mutableIntStateOf(0) }
    var loc by remember { mutableStateOf<Locality?>(null) }

    // tax inputs
    var fed by remember { mutableStateOf("22") }
    var state by remember { mutableStateOf("5.75") }

    val lMax = loc?.lodgingFor(month)?.toDouble() ?: (lodgingMax.toDoubleOrNull() ?: 0.0)
    val mMax = loc?.mie?.toDouble() ?: (mieMax.toDoubleOrNull() ?: 0.0)
    val localityRate = lMax + mMax

    val lp = Perdiem.lodgingsPlus(
        days = days.toIntOrNull() ?: 0,
        actualLodgingPerNight = actualLodging.toDoubleOrNull() ?: 0.0,
        lodgingMax = lMax, mieMax = mMax,
        over12 = over12.toIntOrNull() ?: 0,
        under12 = under12.toIntOrNull() ?: 0
    )
    val ls = Perdiem.lumpSum(days.toIntOrNull() ?: 0, localityRate, dependents.toIntOrNull() ?: 0)

    val payout = if (method == 0) lp.total else ls.total
    val tax = RelocTax.compute(
        taxable = payout,
        federalMarginal = (fed.toDoubleOrNull() ?: 22.0) / 100.0,
        stateMarginal = (state.toDoubleOrNull() ?: 0.0) / 100.0
    )

    TessScreen("TQSE", "temporary quarters · relocation") {

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Lodgings Plus", "Lump Sum").forEachIndexed { i, label ->
                val on = method == i
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                        .background(if (on) T.Cyan.copy(alpha = .18f) else T.Glow)
                        .border(1.dp, if (on) T.Cyan else T.Edge, RoundedCornerShape(9.dp))
                        .clickable { method = i }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 12.sp, color = if (on) T.Cyan else T.Mid,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        TCard(if (method == 0) "reimbursement" else "lump sum payment", T.Gold) {
            Text(cash(payout), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text(
                if (method == 0) "lodging against receipts, M&IE flat"
                else "paid whatever you actually spend",
                fontSize = 12.sp, color = T.Mid
            )

            Spacer(Modifier.height(14.dp))
            if (method == 0) {
                Row(Modifier.fillMaxWidth()) {
                    Text("First ${lp.first.days} days at ${(lp.first.factor * 100).toInt()}%",
                        fontSize = 12.sp, color = T.Low, modifier = Modifier.weight(1f))
                }
                Line("  lodging, capped at ${cash(lp.first.lodgingCap)} a night",
                    cash(lp.first.lodgingPaid))
                Line("  M&IE, flat", cash(lp.first.miePaid))
                if (lp.second.days > 0) {
                    Spacer(Modifier.height(8.dp))
                    Text("Next ${lp.second.days} days at ${(lp.second.factor * 100).toInt()}%",
                        fontSize = 12.sp, color = T.Low)
                    Line("  lodging, capped at ${cash(lp.second.lodgingCap)} a night",
                        cash(lp.second.lodgingPaid))
                    Line("  M&IE, flat", cash(lp.second.miePaid))
                }
                HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 8.dp))
                Line("Lodging", cash(lp.lodgingTotal))
                Line("M&IE", cash(lp.mieTotal))
                Line("Total", cash(lp.total), bold = true)
                if (lp.cappedOut) {
                    Spacer(Modifier.height(8.dp))
                    Text("Your lodging exceeds the cap — the excess is yours to absorb.",
                        fontSize = 11.sp, color = T.Danger)
                }
            } else {
                Line("You, ${ls.days} days at 75% of ${cash(ls.rate)}", cash(ls.employeeShare))
                if (ls.dependents > 0)
                    Line("${ls.dependents} dependent${if (ls.dependents == 1) "" else "s"} at 25% each",
                        cash(ls.dependentShare))
                HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 8.dp))
                Line("Total", cash(ls.total), bold = true)
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("what this is taxed at", T.Danger) {
            Text("Every dollar of it is wages.", fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold, color = T.Hi)
            Spacer(Modifier.height(6.dp))
            Hint("Since 2018 civilian relocation reimbursements are reported on the W-2 " +
                    "and taxed. TDY per diem is not — that is the difference between the " +
                    "two calculators, and it is why WTA and RITA exist.")

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(fed, "Federal marginal %", Modifier.weight(1f)) { fed = it }
                DarkField(state, "State marginal %", Modifier.weight(1f)) { state = it }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Leave state at zero if you will still be a Florida resident when this is " +
                    "paid. If Virginia has you by then, 5.75 is the top rate.")

            Spacer(Modifier.height(14.dp))
            Line("Reimbursement", cash(tax.taxable))
            Line("WTA advanced at ${(tax.wtaRate * 100).toInt()}%", cash(tax.wta))
            Line("Reported as wages", cash(tax.grossedUp), bold = true)
            Spacer(Modifier.height(10.dp))
            Line("Combined marginal rate", String.format(Locale.US, "%.2f%%", tax.cmtr * 100))
            Line("Full gross-up needed", cash(tax.trueGrossUp))
            Line(
                if (tax.ritaEstimate >= 0) "RITA owed to you next year"
                else "Owed back at RITA settlement",
                cash(kotlin.math.abs(tax.ritaEstimate)),
                bad = tax.ritaEstimate < 0
            )
            Spacer(Modifier.height(10.dp))
            Hint("WTA is an advance at the flat 22% supplemental rate. RITA settles the " +
                    "difference the following year against what you actually owed — and if " +
                    "your real rate is below 22%, RITA runs the other way and you repay. " +
                    "You must file for RITA; it does not arrive on its own.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("the locality", T.Teal) {
            if (loc != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(loc!!.name, fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold, color = T.Hi)
                        Text("lodging ${cash(lMax)} · M&IE ${cash(mMax)} · ${MONTHS_T[month - 1]}",
                            fontSize = 11.sp, color = T.Mid)
                    }
                    TextButton(onClick = { loc = null }) {
                        Text("Clear", fontSize = 12.sp, color = T.Mid)
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(lodgingMax, "Lodging max", Modifier.weight(1f), numeric = true) {
                        lodgingMax = it
                    }
                    DarkField(mieMax, "M&IE max", Modifier.weight(1f), numeric = true) {
                        mieMax = it
                    }
                }
            }

            val saved = remember(locTick) { Localities.all(ctx) }
            if (saved.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                saved.forEach { l ->
                    Row(Modifier.fillMaxWidth().clickable { loc = l }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (loc?.id == l.id) T.Teal else T.Edge))
                        Spacer(Modifier.width(10.dp))
                        Text(l.name, fontSize = 14.sp, color = T.Hi, modifier = Modifier.weight(1f))
                        Text(cash(l.rateFor(month).toDouble()), fontSize = 12.sp, color = T.Mid)
                    }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Hint("Destinations saved on the TDY screen appear here too.")
            }

            Spacer(Modifier.height(12.dp))
            Text("MONTH IN QUARTERS", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(7.dp))
            Column {
                MONTHS_T.chunked(6).forEachIndexed { row, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        chunk.forEachIndexed { col, m ->
                            val idx = row * 6 + col + 1
                            val on = month == idx
                            Box(
                                Modifier.weight(1f).clip(RoundedCornerShape(7.dp))
                                    .background(if (on) T.Teal.copy(alpha = .20f) else T.Glow)
                                    .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(7.dp))
                                    .clickable { month = idx }.padding(vertical = 9.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(m, fontSize = 10.sp, color = if (on) T.Teal else T.Mid)
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("the stay", T.Cyan) {
            DarkField(days, "Days in temporary quarters", Modifier.fillMaxWidth(), numeric = true) {
                days = it
            }
            Spacer(Modifier.height(6.dp))
            Hint(
                if (method == 0)
                    "The multiplier drops from 100% to 75% after day 30. The clock does not " +
                    "stop for leave taken during the period."
                else "Lump sum caps at 30 days; anything beyond is ignored."
            )

            Spacer(Modifier.height(12.dp))
            if (method == 0) {
                DarkField(actualLodging, "What lodging actually costs, per night",
                    Modifier.fillMaxWidth(), numeric = true) { actualLodging = it }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(over12, "Spouse and 12+", Modifier.weight(1f), numeric = true) {
                        over12 = it
                    }
                    DarkField(under12, "Under 12", Modifier.weight(1f), numeric = true) {
                        under12 = it
                    }
                }
                Spacer(Modifier.height(8.dp))
                Hint("Each person adds to the daily ceiling: 50% for a spouse or anyone " +
                        "twelve and over, 30% for under twelve, in the first period.")
            } else {
                DarkField(dependents, "Dependents in temporary quarters",
                    Modifier.fillMaxWidth(), numeric = true) { dependents = it }
                Spacer(Modifier.height(8.dp))
                Hint("Each dependent draws 25% of the locality rate whatever their age.")
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("which method", T.Violet) {
            Hint(
                if (method == 0)
                    "Lodgings Plus pays what you actually spend on lodging up to the cap, " +
                    "plus flat M&IE. It wins when quarters are expensive. You keep receipts, " +
                    "and spending under the cap saves the government money rather than you."
                else
                    "Lump Sum pays the full amount whatever you spend, so staying somewhere " +
                    "cheap — or with family — is money in your pocket. No receipts. Capped " +
                    "at thirty days."
            )
            Spacer(Modifier.height(10.dp))
            Text("Same inputs the other way: " +
                    (if (method == 0) "lump sum ${cash(ls.total)}"
                     else "lodgings plus ${cash(lp.total)}"),
                fontSize = 12.sp, color = T.Violet)
            Spacer(Modifier.height(6.dp))
            Hint("The election is made on the orders and cannot be changed afterwards.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("before you rely on this", T.Edge) {
            Hint("DoD dropped TQSE Actual Expense; Lodgings Plus is the preferred method and " +
                    "Lump Sum the alternative. The percentage multipliers come from JTR Table " +
                    "5-85 and have already moved once — confirm them against the current table " +
                    "before planning around a figure. A planning estimate, settled by your " +
                    "travel office.")
        }
    }
}

@Composable
private fun Line(label: String, value: String, bold: Boolean = false, bad: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (bad) T.Danger else T.Hi)
    }
}

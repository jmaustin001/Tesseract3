The Virginia tax those days have accrued now sits on the dashboard, under the
wages, with the effective rate beside it. Tapping the card opens the full
working — the Form 763 order, the allocation percentage, what is unpaid, and
how it splits across the remaining quarterly estimates.

It was all there already, behind Reports, which is a poor place for the number
you most want to see.

Also in this build: the wage base is visible, editable and clearable on the Pay
screen, and a base well below your SF-50 salary is flagged rather than quietly
divided by.

package com.tesseract.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.util.Locale

class AllocationActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { AllocationScreen() } }
    }
}

private fun money(v: Double) = "$" + String.format(Locale.US, "%,.0f", v)

@Composable
private fun AllocationScreen() {
    val ctx = LocalContext.current
    val resumed = (ctx as? AllocationActivity)?.resumeTick ?: 0
    var year by remember { mutableIntStateOf(Store.year()) }
    var gross by remember { mutableStateOf(Store.grossWages(ctx).let {
        if (it <= 0) "" else it.toInt().toString() }) }
    var hours by remember { mutableStateOf(Store.hoursPerDay(ctx).toString()) }
    var tick by remember { mutableIntStateOf(0) }
    var totalInc by remember { mutableStateOf(Store.totalIncome(ctx).let {
        if (it <= 0) "" else it.toInt().toString() }) }
    var exemptions by remember { mutableStateOf(Store.exemptions(ctx).toString()) }
    var withheld by remember { mutableStateOf(Store.vaWithheld(ctx).let {
        if (it <= 0) "" else it.toInt().toString() }) }
    var joint by remember { mutableStateOf(Store.filingJoint(ctx)) }
    var direct by remember { mutableStateOf(Store.directWages(ctx).let {
        if (it <= 0) "" else it.toInt().toString() }) }
    var directLabel by remember { mutableStateOf(Store.directLabel(ctx)) }

    val r = remember(tick, resumed, year) { Allocation.compute(ctx, year) }
    val name = States.fullName(r.state)

    TessScreen("Wage allocation", "$name · $year") {

        TCard("the ratio", T.Gold) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${r.stateWorkdays}", fontSize = 44.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Text(" / ${r.totalWorkdays}", fontSize = 20.sp, color = T.Mid,
                    modifier = Modifier.padding(bottom = 7.dp))
            }
            Text("days worked in ${r.state} out of days worked anywhere",
                fontSize = 12.sp, color = T.Mid)
            Spacer(Modifier.height(10.dp))
            Text(String.format(Locale.US, "%.2f%%", r.ratio * 100),
                fontSize = 26.sp, fontWeight = FontWeight.Bold, color = T.Hi)
        }

        Spacer(Modifier.height(10.dp))
        TCard("your pay", T.Teal) {
            DarkField(gross, "W-2 Box 1 wages for $year", Modifier.fillMaxWidth(), numeric = true) {
                gross = it
                Store.setGrossWages(ctx, it.toDoubleOrNull() ?: 0.0); tick++
            }
            Spacer(Modifier.height(8.dp))
            DarkField(hours, "Hours in a duty day", Modifier.fillMaxWidth(), numeric = true) {
                hours = it
                it.toDoubleOrNull()?.let { v -> Store.setHoursPerDay(ctx, v); tick++ }
            }
            Spacer(Modifier.height(14.dp))
            DarkField(direct, "Wages already sourced to $name",
                Modifier.fillMaxWidth(), numeric = true) {
                direct = it
                Store.setDirectWages(ctx, it.toDoubleOrNull() ?: 0.0); tick++
            }
            Spacer(Modifier.height(8.dp))
            DarkField(directLabel, "What that is", Modifier.fillMaxWidth()) {
                directLabel = it; Store.setDirectLabel(ctx, it); tick++
            }
            Spacer(Modifier.height(8.dp))
            Hint("A relocation W-2 with a figure in Box 16 has already been sourced by the " +
                    "payer — TQSE, the WTA gross-up, RITA when it settles. That amount is " +
                    "added whole and never run through the working-day ratio, because the " +
                    "decision was made when it was reported. Keep it out of the Box 1 field " +
                    "above or it will be counted twice.")

            Spacer(Modifier.height(14.dp))
            Hint("Box 1, not your salary. Virginia starts from federal adjusted gross " +
                    "income, so traditional TSP, FEHB premiums, FSA and dental come out " +
                    "before Virginia sees the number — and Box 1 already has them removed. " +
                    "Roth TSP does not reduce it. Entering your salary instead would " +
                    "overstate Virginia wages by whatever you put in TSP.")
        }

        val est = remember(tick, resumed, year, r) {
            VaTax.estimate(
                // when no household figure is given, total must still include the
                // separately reported wages or the state share could exceed 100%
                totalIncome = Store.totalIncome(ctx)
                    .let { if (it > 0) it else r.gross + r.directWages },
                vaIncome = r.stateWages,
                relocationIncome = r.directWages,
                joint = Store.filingJoint(ctx),
                exemptions = Store.exemptions(ctx),
                withheld = Store.vaWithheld(ctx),
                monthsElapsed = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH),
                year = year)
        }

        if (r.gross > 0) {
            Spacer(Modifier.height(10.dp))
            TCard("allocated to $name", T.Gold) {
                Text(money(r.stateWages), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Spacer(Modifier.height(10.dp))
                EstLine("By working-day ratio", money(r.ratioWages))
                if (r.directWages > 0)
                    EstLine(r.directLabel, money(r.directWages))
                if (r.directWages > 0) {
                    Spacer(Modifier.height(6.dp))
                    Hint("The second line skipped the ratio — it was already sourced when " +
                            "it was reported.")
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip(money(r.dailyRate), "per duty day", T.Teal, Modifier.weight(1f))
                    StatChip(money(r.hourlyRate), "per hour", T.Teal, Modifier.weight(1f))
                }
            }
        }

        if (r.gross > 0) {
            Spacer(Modifier.height(10.dp))
            TCard("estimated $name tax", if (est.shortfall > 0) T.Danger else T.Teal) {
                Text(money(est.vaTax), fontSize = 32.sp,
                    fontWeight = FontWeight.Bold, color = T.Hi)
                Text(String.format(Locale.US,
                    "%.2f%% of the wages allocated to $name", est.effectiveOnVaWages * 100),
                    fontSize = 12.sp, color = T.Mid)
                Spacer(Modifier.height(8.dp))
                Hint("\"As a resident\" below is a step in the nonresident form's own math, " +
                        "not a statement about your residency. Form 763 works out the rate by " +
                        "pretending, for one line, that all your income were $name's — then " +
                        "taxes only the allocated share. Staying under the day count is what " +
                        "keeps you filing this form rather than becoming a resident, where " +
                        "everything on the return would be real rather than hypothetical.")

                Spacer(Modifier.height(14.dp))
                EstLine("Income from all sources (VAGI)", money(est.totalIncome))
                EstLine("Standard deduction, $year", "− " + money(est.deduction))
                EstLine("Exemptions", "− " + money(est.exemptionTotal))
                EstLine("Taxable as a resident", money(est.taxableAsResident))

                // how that taxable figure climbs the brackets
                Spacer(Modifier.height(10.dp))
                est.brackets.filter { it.taxed > 0 }.forEach { band ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(
                            String.format(Locale.US, "  %.2f%% on ", band.rate * 100) +
                                money(band.taxed) +
                                (if (band.to == null) " over " + money(band.from)
                                 else " (" + money(band.from) + "–" + money(band.to) + ")"),
                            fontSize = 11.sp, color = T.Low, modifier = Modifier.weight(1f))
                        Text(money(band.tax), fontSize = 11.sp, color = T.Mid)
                    }
                }
                Spacer(Modifier.height(6.dp))
                EstLine("Tax as a resident on all income", money(est.taxAsResident))
                EstLine("× allocation percentage",
                    String.format(Locale.US, "%.1f%%", est.allocationPct * 100))
                EstLine("= $name tax", money(est.vaTax))
                EstLine("Withheld so far", money(est.withheld))
                EstLine("Unpaid", money(est.shortfall), est.shortfall > 0)

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = T.Edge)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (est.mustFile) "Form 763 is required for $year"
                    else "Below the filing threshold for $year",
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = if (est.mustFile) T.Gold else T.Teal
                )
                Spacer(Modifier.height(4.dp))
                Hint("The threshold is " + money(est.filingThreshold) + " of VAGI — income " +
                        "from every source, not just what you earned in $name. With a federal " +
                        "salary you are over it from the first Virginia workday; it only " +
                        "matters for someone with very little income overall.")
                if (VaTax.deductionIsProvisional(year)) {
                    Spacer(Modifier.height(8.dp))
                    Hint("The $year standard deduction is not settled yet — the higher figure " +
                            "was scheduled to end after 2026. This uses the 2026 amount until " +
                            "the law is known.")
                }

                if (est.taxOnRelocation > 0) {
                    Spacer(Modifier.height(14.dp))
                    HorizontalDivider(color = T.Edge)
                    Spacer(Modifier.height(10.dp))
                    EstLine("On relocation wages — RITA should cover",
                        money(est.taxOnRelocation))
                    EstLine("On ordinary wages — yours", money(est.taxYouBear), true)
                    Spacer(Modifier.height(8.dp))
                    Hint("RITA reimburses substantially all of the additional federal, state " +
                            "and local tax caused by taxable relocation benefits, so the " +
                            "first line is largely recoverable and the second is not. It is " +
                            "a formula, not your actual return, so expect it to land close " +
                            "rather than exact — and you have to file for it.")
                }

                if (est.shortfall > 0) {
                    Spacer(Modifier.height(12.dp))
                    Text("${money(est.perQuarter)} across ${est.quartersLeft} remaining " +
                            "quarterly estimate${if (est.quartersLeft == 1) "" else "s"}",
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = T.Danger)
                    Spacer(Modifier.height(6.dp))
                    Hint("Virginia charges underpayment penalties on tax that should have " +
                            "been paid quarterly. If DFAS is withholding nothing because " +
                            "your record says Florida, this is accruing whether or not " +
                            "anyone has mentioned it.")
                }
                Spacer(Modifier.height(10.dp))
                Hint("Planning estimate only. Ignores credits, itemized deductions, " +
                        "additions and subtractions. Rates are 2% / 3% / 5% / 5.75%, " +
                        "current for 2026.")
            }

            Spacer(Modifier.height(10.dp))
            TCard("estimate inputs", T.Edge) {
                DarkField(totalInc, "Total household income (federal AGI)",
                    Modifier.fillMaxWidth(), numeric = true) {
                    totalInc = it
                    Store.setTotalIncome(ctx, it.toDoubleOrNull() ?: 0.0); tick++
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(exemptions, "Exemptions", Modifier.weight(1f), integer = true) {
                        exemptions = it
                        it.toIntOrNull()?.let { v -> Store.setExemptions(ctx, v); tick++ }
                    }
                    DarkField(withheld, "$name tax withheld", Modifier.weight(1f), numeric = true) {
                        withheld = it
                        Store.setVaWithheld(ctx, it.toDoubleOrNull() ?: 0.0); tick++
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Married filing jointly", fontSize = 14.sp, color = T.Hi)
                        Text("Uses the ${money(VaTax.standardDeduction(year, true))} standard deduction",
                            fontSize = 11.sp, color = T.Low)
                    }
                    Switch(checked = joint, onCheckedChange = {
                        joint = it; Store.setFilingJoint(ctx, it); tick++
                    })
                }
                Spacer(Modifier.height(10.dp))
                Hint("Filing jointly can pull a spouse's income into $name's reach. " +
                        "$name allows separate filing to keep a nonresident spouse out. " +
                        "Worth settling with a CPA before the first return, not after.")
            }
        }

        Spacer(Modifier.height(10.dp))
        val problems = r.gapDays + r.uncategorized
        TCard("how solid this is", if (problems > 0) T.Danger else T.Teal) {
            Line("Days with no location data", r.gapDays, r.gapDays > 0)
            Line("Days never categorized", r.uncategorized, r.uncategorized > 0)
            Line("Worked days with no fix in duty hours", r.weakIncomeDays, false)
            Line("Days set by hand rather than by rule", r.manualOverrides, false)
            Line("Days reconstructed from your schedule", r.reconstructedDays, false)
            Spacer(Modifier.height(10.dp))
            Hint(
                if (problems > 0)
                    "Clear these before relying on the figures. Every unexplained gap is a " +
                            "day an examiner is free to assign as they like."
                else "No gaps and nothing unlabeled. This is what a contemporaneous record " +
                        "is supposed to look like."
            )
        }

        Spacer(Modifier.height(10.dp))
        TCard("the worksheet", T.Violet) {
            Hint("A plain-language sheet showing every figure and how it was reached — " +
                    "the method, the day counts, the ratio, and the weak spots above. " +
                    "Built to be handed to a CPA, not filed.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Share the worksheet", accent = T.Violet) {
                val f = Allocation.writeFile(ctx, r)
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                ctx.startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "$name wage allocation $year")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share worksheet"))
            }
            Spacer(Modifier.height(8.dp))
            Hint("Send the day-by-day and fix-by-fix CSVs with it. The worksheet is the " +
                    "summary; those are the evidence.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("read it first", T.Edge) {
            Hint("The working-day ratio is the usual method, not the only one, and this " +
                    "app is not qualified to say which applies to you. Staying under the " +
                    "day threshold does not stop $name taxing wages you earned there — " +
                    "it keeps $name to those wages rather than all your income. If nothing " +
                    "is being withheld, that liability is accruing somewhere. Worth a CPA " +
                    "before a quarterly deadline rather than after the year closes.")
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostBtn("◀ ${year - 1}", Modifier.weight(1f), color = T.Mid) { year -= 1 }
            GhostBtn("${year + 1} ▶", Modifier.weight(1f), color = T.Mid) { year += 1 }
        }
    }
}

@Composable
private fun Line(label: String, n: Int, bad: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Hi, modifier = Modifier.weight(1f))
        Text("$n", fontSize = 15.sp, fontWeight = FontWeight.Bold,
            color = if (bad) T.Danger else T.Mid)
    }
}

@Composable
private fun EstLine(label: String, value: String, bad: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            color = if (bad) T.Danger else T.Hi)
    }
}

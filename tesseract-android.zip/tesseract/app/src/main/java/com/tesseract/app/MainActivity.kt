package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.onboarded(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java)); finish(); return
        }
        val want = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
        Scheduler.scheduleNextCheck(this)
        setContent { TessTheme { Dashboard() } }
    }

    fun requestBackground() {
        if (Build.VERSION.SDK_INT >= 29)
            perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }

    /** Bumped on every resume so the dashboard re-reads the log after you have
     *  been off categorizing a day, editing a datum, or changing settings. */
    var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    fun restartSetup() { startActivity(Intent(this, OnboardingActivity::class.java)); finish() }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val year = remember { Store.year() }
    var tick by remember { mutableIntStateOf(0) }
    val resumed = (ctx as? MainActivity)?.resumeTick ?: 0
    val scope = rememberCoroutineScope()
    var fixing by remember { mutableStateOf(false) }
    var fixMsg by remember { mutableStateOf("") }
    var fixBad by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { tick++ }

    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)
    val days = remember(tick, resumed) { Store.days(ctx, year) }
    val n = remember(tick, resumed) { Store.stateDays(ctx, counted, year) }
    val homeN = remember(tick, resumed) { Store.stateDays(ctx, home, year) }
    val offN = remember(tick, resumed) { Store.offStationDays(ctx, year) }
    val untagged = remember(tick, resumed) { Store.untaggedOutDays(ctx, year) }
    val gaps = remember(tick, resumed) { Store.gapDays(ctx, year) }
    val projected = remember(tick, resumed) { Store.projectedStateDays(ctx, counted, year) }
    val limit = Store.limit(ctx)
    val soft1 = Store.soft1(ctx); val soft2 = Store.soft2(ctx); val hard = Store.hard(ctx)

    val stage = when {
        n >= limit -> 4; n >= hard -> 3; n >= soft2 -> 2; n >= soft1 -> 1; else -> 0
    }
    val accent = when (stage) { 0 -> T.Cyan; 1, 2 -> T.Gold; else -> T.Danger }

    TessScreen(
        title = "TESSERACT",
        subtitle = "residency log · $year",
        showBack = false,
        action = {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                    .background(T.Deep).border(1.dp, T.Edge, RoundedCornerShape(10.dp))
                    .clickable { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = T.Mid, fontSize = 17.sp) }
        }
    ) {
        /* ---- hero ---- */
        Box(
            Modifier.fillMaxWidth().height(196.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0C1930), Color(0xFF071120))))
                .border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(18.dp))
                .clickable { ctx.startActivity(Intent(ctx, AllocationActivity::class.java)) }
        ) {
            TesseractMarkLive(
                modifier = Modifier.size(190.dp).align(Alignment.CenterEnd).offset(x = 52.dp),
                outer = accent, inner = accent, strut = accent, alpha = .16f, stroke = 2.4f
            )
            Column(Modifier.padding(18.dp).align(Alignment.CenterStart)) {
                Text("EARNING DAYS IN ${counted.uppercase()}", fontSize = 10.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(6.dp))
                val earnDays = Store.earningDays(ctx, counted, year)
                // summed one logged workday at a time, at that day's own salary
                // rate — grows only as real days are logged, never a projection
                val accrued = remember(tick, resumed) { Workdays.earningsAccrued(ctx, year, counted) }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$earnDays", fontSize = 62.sp,
                        fontWeight = FontWeight.Bold, color = T.Hi, letterSpacing = (-2).sp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (earnDays == 1) "day" else "days", fontSize = 18.sp,
                        color = T.Mid, modifier = Modifier.padding(bottom = 12.dp))
                }
                if (accrued > 0) {
                    Text("≈ " + "$" + String.format(java.util.Locale.US, "%,.0f", accrued) +
                            " earned in $counted so far", fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Gold)
                    Text("day by day, from " + Workdays.rateBasis(ctx, year),
                        fontSize = 11.sp, color = T.Low)

                    // the CPA-facing projection — a different question, answered
                    // with the same figures the allocation worksheet uses, so the
                    // two can never disagree
                    val alloc = remember(tick, resumed) { Allocation.compute(ctx, year) }
                    val est = remember(tick, resumed, alloc) {
                        VaTax.estimate(
                            totalIncome = Store.totalIncome(ctx)
                                .let { if (it > 0) it else alloc.gross + alloc.directWages },
                            vaIncome = alloc.stateWages,
                            relocationIncome = alloc.directWages,
                            joint = Store.filingJoint(ctx),
                            exemptions = Store.exemptions(ctx),
                            withheld = Store.vaWithheld(ctx),
                            monthsElapsed = java.util.Calendar.getInstance()
                                .get(java.util.Calendar.MONTH),
                year = year)
                    }
                    if (alloc.stateWages > 0) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "if this pace holds all year: " + "$" +
                                String.format(java.util.Locale.US, "%,.0f", alloc.stateWages) +
                                " in $counted, ≈ " + "$" +
                                String.format(java.util.Locale.US, "%,.0f", est.vaTax) + " tax",
                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = T.Danger
                        )
                        Text("projected from ${(alloc.ratio * 100).let {
                                String.format(java.util.Locale.US, "%.1f", it) }}% of days worked " +
                                "so far · tap for the full working",
                            fontSize = 10.sp, color = T.Low)
                    }

                    if (Workdays.rateLooksWrong(ctx, year)) {
                        Spacer(Modifier.height(4.dp))
                        Text("That is well under your SF-50 salary — check the wage base on " +
                                "the Pay screen.", fontSize = 11.sp, color = T.Danger)
                    }
                } else {
                    Text("Enter your SF-50 salary under Pay to see what these days earned",
                        fontSize = 11.sp, color = T.Low)
                }
                Spacer(Modifier.height(6.dp))
                Text("$n of $limit days present — the residency count",
                    fontSize = 12.sp, color = T.Mid)

                Spacer(Modifier.height(10.dp))
                StageBar(n, soft1, soft2, hard, limit, accent)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (n < limit) "${limit - n} days of room left" else "${n - limit} days past the line",
                    fontSize = 12.sp, color = if (stage >= 3) T.Danger else T.Mid
                )
                val pcs = Store.pcsDate(ctx)
                if (pcs.isNotBlank() && Store.today() >= pcs) {
                    val sincePcs = Store.stateDaysFrom(ctx, counted, year, pcs)
                    Text("$sincePcs of those since the PCS on $pcs",
                        fontSize = 11.sp, color = T.Violet)
                }
                if (projected >= 0) Text(
                    "pace projects $projected by year end",
                    fontSize = 11.sp, color = if (projected > limit) T.Danger else T.Low
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("$homeN", "$home days", T.Teal, Modifier.weight(1f))
            StatChip("$offN", "off station", T.Violet, Modifier.weight(1f))
            StatChip("${days.size}", "days logged", T.Cyan, Modifier.weight(1f))
        }

        /* ---- today ---- */
        Spacer(Modifier.height(10.dp))
        val today = remember(tick, resumed) { Store.days(ctx, year).firstOrNull { it.date == Store.today() } }
        TCard(label = "today", accent = T.Cyan) {
            if (today == null) {
                Text("No fix yet today.", fontSize = 15.sp, color = T.Hi)
                Spacer(Modifier.height(3.dp))
                Hint("Next automatic check at ${Store.checkHours(ctx).firstOrNull { it > java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) } ?: Store.checkHours(ctx).firstOrNull() ?: 0}:00.")
            } else {
                Text(today.states.joinToString(", "), fontSize = 19.sp,
                    fontWeight = FontWeight.SemiBold, color = T.Hi)
                Spacer(Modifier.height(2.dp))
                Text(today.status.ifBlank { "not categorized" }, fontSize = 13.sp,
                    color = if (today.status.isBlank()) T.Gold else T.Mid)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryBtn(if (fixing) "Locating…" else "Log me now", Modifier.weight(1f)) {
                    if (fixing) return@PrimaryBtn
                    fixing = true; fixMsg = ""; fixBad = false
                    scope.launch {
                        val r = Fixer.capture(ctx, highAccuracy = true)
                        fixing = false
                        r.fold(
                            onSuccess = { fixMsg = "Logged — ${it.summary}"; tick++ },
                            onFailure = { fixMsg = it.message ?: "Could not get a fix."; fixBad = true }
                        )
                    }
                }
                GhostBtn("Categorize", Modifier.weight(1f)) {
                    ctx.startActivity(Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", Store.today())
                        .putExtra("summary", "Set today's category.")
                        .putExtra("guess", Status.DUTY))
                }
            }
            if (fixMsg.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(fixMsg, fontSize = 12.sp, color = if (fixBad) T.Danger else T.Teal)
            }
        }

        /* ---- the in-office requirement, this pay period ---- */
        val pp = remember(tick, resumed) { PayPeriods.current(ctx) }
        if (pp != null) {
            Spacer(Modifier.height(10.dp))
            val short = pp.officeDays < pp.required
            TCard(pp.label.lowercase(), if (short) T.Gold else T.Teal) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${pp.officeDays}", fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (short) T.Gold else T.Teal)
                    Text(" of ${pp.required} days in the office", fontSize = 14.sp,
                        color = T.Mid, modifier = Modifier.padding(bottom = 6.dp))
                }
                Text("${pp.start} to ${pp.end}", fontSize = 11.sp, color = T.Low)
                if (short && pp.verdict == PayPeriods.Verdict.IN_PROGRESS) {
                    Spacer(Modifier.height(6.dp))
                    Text("${pp.required - pp.officeDays} more before ${pp.end} to keep the " +
                            "locality", fontSize = 12.sp, color = T.Gold)
                }
            }
        }

        /* ---- anything demanding attention ---- */
        if (untagged.isNotEmpty() || gaps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            TCard(label = "needs you", accent = T.Gold) {
                if (untagged.isNotEmpty())
                    AlertRow("${untagged.size} day${if (untagged.size == 1) "" else "s"} without a category",
                        "Off station and unlabeled", T.Gold) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
                if (untagged.isNotEmpty() && gaps.isNotEmpty()) Spacer(Modifier.height(10.dp))
                if (gaps.isNotEmpty())
                    AlertRow("${gaps.size} day${if (gaps.size == 1) "" else "s"} with no data",
                        "Gaps weaken the whole log", T.Danger) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
            }
        }

        /* ---- navigation ---- */
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Year view", "Every day as one picture", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, YearActivity::class.java))
            }
            NavTile("Datums", Store.datums(ctx).size.let {
                "$it reference point${if (it == 1) "" else "s"}" }, T.Teal, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, DatumsActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Reports", "CSV, email, backup", T.Violet, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, ReportsActivity::class.java))
            }
            NavTile("The log", "Every day, filterable", T.Cyan, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, LogActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("TDY per diem", "M&IE, not taxable", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, PerdiemActivity::class.java))
            }
            NavTile("TQSE (LP)", "Lodgings plus · all taxable", T.Danger, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, TqseActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Pay", "LES year to date", T.Teal, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, PayActivity::class.java))
            }
            NavTile("Settings", "States, schedule, warnings", T.Cyan, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
            }
        }

        Spacer(Modifier.height(16.dp))
        Hint("Physical presence is what counts — any part of a day in $counted is a $counted day. " +
                "A record-keeping aid, not tax advice.")
    }
}

/** Progress with the three warning stages marked on it. */
@Composable
private fun StageBar(n: Int, s1: Int, s2: Int, hard: Int, limit: Int, accent: Color) {
    Box(
        Modifier.fillMaxWidth(.62f).height(7.dp)
            .clip(RoundedCornerShape(4.dp)).background(Color(0xFF16243A))
    ) {
        Box(
            Modifier.fillMaxWidth((n.toFloat() / limit).coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = .6f), accent)))
        )
        listOf(s1, s2, hard).forEach { mark ->
            Box(
                Modifier.fillMaxWidth((mark.toFloat() / limit).coerceIn(0f, 1f))
                    .fillMaxHeight(), contentAlignment = Alignment.CenterEnd
            ) { Box(Modifier.width(1.5.dp).fillMaxHeight().background(T.Void.copy(alpha = .85f))) }
        }
    }
}

@Composable
private fun AlertRow(title: String, detail: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = T.Hi)
            Text(detail, fontSize = 11.sp, color = T.Low)
        }
        Text("›", color = T.Mid, fontSize = 19.sp)
    }
}

The work schedule is now yours to set, in Settings.

- Duty days: tick the weekdays you actually work, rather than assuming Mon-Fri
- Federal holidays: on or off, all eleven with the weekend observed shift
- Regular day off: the every-other-Friday of a 5-4-9 or Maxiflex. Pick the
  weekday, the interval in weeks, and any one date you had off — the pattern
  counts outward from there in both directions
- Mark a stretch: set a date range Worked, Day off, or back to automatic, for
  a leave block or a TDY run in one go

The categorize screen now shows why a day did or did not earn, with Automatic
/ Worked / Day off right there. Manual marks always beat the rules, and the
CSV records that a person set them.

All of this decides income only. The 183-day residency count is untouched —
a Saturday in Virginia still counts toward that.

package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One SF-50 pay action, as printed. Every field is the exact text typed, so
 * what was saved is what is shown — no rounding on the way in or out.
 */
data class SalaryRecord(
    val id: String,
    val effective: String,   // block 4, yyyy-MM-dd — the first day this rate applies
    val grade: String,       // pay plan and grade or band, e.g. NH-04
    val base: String,        // basic pay, block 20A
    val locPct: String,      // locality percentage
    val locAmt: String,      // locality adjustment, block 20B
    val adjusted: String     // adjusted basic pay, block 20C — the rate itself
) {
    /** The annual rate: 20C as typed, or 20A + 20B if 20C was left blank. */
    val rate: Double
        get() = adjusted.toDoubleOrNull()
            ?: ((base.toDoubleOrNull() ?: 0.0) + (locAmt.toDoubleOrNull() ?: 0.0))
}

/**
 * Every SF-50 on record, in date order. A day is priced at the SF-50 whose
 * effective date is the latest one on or before it — so three pay actions in
 * one year give three rates, each applied only to the days it actually covered.
 * A day earlier than every SF-50 on record takes the earliest one, since that is
 * the best evidence of what was being paid then.
 */
object Salaries {

    private const val KEY = "salaryHistory"

    fun all(ctx: Context): List<SalaryRecord> {
        val raw = Store.prefString(ctx, KEY, "")
        if (raw.isBlank()) return migrate(ctx)
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                SalaryRecord(
                    o.optString("id"), o.optString("eff"), o.optString("grade"),
                    o.optString("base"), o.optString("locPct"), o.optString("locAmt"),
                    o.optString("adj")
                )
            }.sortedBy { it.effective }
        } catch (e: Exception) { emptyList() }
    }

    fun save(ctx: Context, list: List<SalaryRecord>) {
        val a = JSONArray()
        list.sortedBy { it.effective }.forEach { r ->
            a.put(JSONObject().apply {
                put("id", r.id); put("eff", r.effective); put("grade", r.grade)
                put("base", r.base); put("locPct", r.locPct); put("locAmt", r.locAmt)
                put("adj", r.adjusted)
            })
        }
        Store.setPrefString(ctx, KEY, a.toString())
    }

    fun upsert(ctx: Context, r: SalaryRecord) =
        save(ctx, all(ctx).filterNot { it.id == r.id } + r)

    fun delete(ctx: Context, id: String) = save(ctx, all(ctx).filterNot { it.id == id })

    fun newId() = "sf" + System.currentTimeMillis().toString().takeLast(9)

    /** The SF-50 in effect on a date. */
    fun recordOn(ctx: Context, date: String): SalaryRecord? {
        val list = all(ctx).filter { it.rate > 0 }
        if (list.isEmpty()) return null
        return list.lastOrNull { it.effective.isBlank() || it.effective <= date } ?: list.first()
    }

    fun rateOn(ctx: Context, date: String): Double = recordOn(ctx, date)?.rate ?: 0.0

    fun current(ctx: Context): SalaryRecord? = recordOn(ctx, Store.today())

    data class Window(val record: SalaryRecord, val from: String, val toExclusive: String)

    /** The stretch of a year each SF-50 governed, clipped to that year. */
    fun windows(ctx: Context, year: Int): List<Window> {
        val list = all(ctx).filter { it.rate > 0 }
        if (list.isEmpty()) return emptyList()
        val yStart = "$year-01-01"
        val yEnd = "${year + 1}-01-01"
        val out = mutableListOf<Window>()
        list.forEachIndexed { i, r ->
            val start = if (i == 0) yStart else maxOf(r.effective.ifBlank { yStart }, yStart)
            val end = minOf(list.getOrNull(i + 1)?.effective?.ifBlank { yEnd } ?: yEnd, yEnd)
            if (start < end) out.add(Window(r, start, end))
        }
        return out
    }

    /**
     * Build the history from the two-card version (current and prior) so that
     * nothing typed there is lost. Runs once, the first time the history is read.
     */
    private fun migrate(ctx: Context): List<SalaryRecord> {
        val out = mutableListOf<SalaryRecord>()
        val prior = Store.sf50(ctx, "prior")
        val cur = Store.sf50(ctx, "cur")
        if (prior.adjusted.isNotBlank() || prior.base.isNotBlank())
            out.add(SalaryRecord("sfprior", "", prior.grade, prior.base, prior.locPct,
                prior.locAmt, prior.adjusted))
        if (cur.adjusted.isNotBlank() || cur.base.isNotBlank())
            out.add(SalaryRecord("sfcur", Store.salaryEffective(ctx), cur.grade, cur.base,
                cur.locPct, cur.locAmt, cur.adjusted))
        if (out.isNotEmpty()) save(ctx, out)
        return out.sortedBy { it.effective }
    }
}

package com.tesseract.app

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.getValue
import kotlin.math.cos
import kotlin.math.sin

/* ---------------- palette ---------------- */

object T {
    val Void = Color(0xFF05090F)        // page
    val Deep = Color(0xFF0A1220)        // panel
    val Edge = Color(0xFF1B2A42)        // hairline
    val Glow = Color(0xFF0F2137)        // raised panel

    val Hi = Color(0xFFE8F0F8)          // primary text
    val Mid = Color(0xFF8FA3BC)         // secondary text
    val Low = Color(0xFF56687F)         // tertiary

    val Cyan = Color(0xFF5AB0FF)        // the app's signature
    val Ice = Color(0xFFB0DEFF)
    val Gold = Color(0xFFE0A93B)        // counted state
    val Teal = Color(0xFF35B39B)        // home state
    val Violet = Color(0xFFA07BE0)      // TDY other
    val Danger = Color(0xFFFF6B5A)
}

/**
 * One dark scheme for the whole app, so stock Material components — text fields,
 * dialogs, dropdowns, chips — come out readable without being restyled one by one.
 */
@Composable
fun TessTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scale = Store.textScale(ctx)
    val base = LocalDensity.current
    // Scales every sp in the app at once, on top of whatever the phone's own
    // font setting already does.
    val density = Density(base.density, base.fontScale * scale)
    CompositionLocalProvider(LocalDensity provides density) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = T.Cyan,
            onPrimary = Color(0xFF051020),
            secondary = T.Gold,
            background = T.Void,
            onBackground = T.Hi,
            surface = T.Deep,
            onSurface = T.Hi,
            surfaceVariant = T.Glow,
            onSurfaceVariant = T.Mid,
            outline = T.Edge,
            error = T.Danger,
            onError = Color(0xFF1A0604)
        ),
        content = content
    )
    }
}

/* ---------------- the mark ---------------- */

/** The tesseract itself: cube inside a cube, joined corner to corner. */
@Composable
fun TesseractMark(
    modifier: Modifier = Modifier,
    outer: Color = T.Cyan,
    inner: Color = T.Ice,
    strut: Color = Color(0xFF2E5C8F),
    alpha: Float = 1f,
    stroke: Float = 2.2f,
    phase: Float = 0f,        // outer cube rotation, degrees
    innerPhase: Float = 0f,   // inner cube rotation, degrees
    core: Float = 0f          // 0 = no nebula, 1 = full
) {
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val rOut = minOf(size.width, size.height) * 0.46f
        val rIn = rOut * 0.45f

        fun hex(r: Float, spin: Float) = (0..5).map {
            val a = Math.toRadians((90 + it * 60 + spin).toDouble())
            Offset(cx + r * cos(a).toFloat(), cy - r * sin(a).toFloat())
        }

        val o = hex(rOut, phase)
        val i = hex(rIn, innerPhase)

        // the nebula, drawn behind the cage
        if (core > 0f) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = .85f * core),
                        inner.copy(alpha = .45f * core),
                        outer.copy(alpha = .12f * core),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = rIn * 2.1f
                ),
                radius = rIn * 2.1f,
                center = Offset(cx, cy)
            )
        }

        for (k in 0..5) drawLine(strut.copy(alpha = alpha * .85f), o[k], i[k], stroke, StrokeCap.Round)
        for (k in 0..5) drawLine(outer.copy(alpha = alpha), o[k], o[(k + 1) % 6], stroke * 1.15f, StrokeCap.Round)
        for (k in 0..5) drawLine(inner.copy(alpha = alpha), i[k], i[(k + 1) % 6], stroke, StrokeCap.Round)
        for (k in listOf(0, 2, 4)) drawLine(inner.copy(alpha = alpha), i[k], Offset(cx, cy), stroke, StrokeCap.Round)

        if (core > 0f) drawCircle(
            Color.White.copy(alpha = core), radius = stroke * 1.1f, center = Offset(cx, cy)
        )
    }
}

/**
 * The same mark, turning. Two cubes on slightly different periods so the shape
 * keeps changing rather than looping, and a core that breathes.
 */
@Composable
fun TesseractMarkLive(
    modifier: Modifier = Modifier,
    outer: Color = T.Cyan,
    inner: Color = T.Ice,
    strut: Color = Color(0xFF2E5C8F),
    alpha: Float = 1f,
    stroke: Float = 2.2f,
    withCore: Boolean = true
) {
    val t = rememberInfiniteTransition(label = "tesseract")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(52_000, easing = LinearEasing)),
        label = "spin"
    )
    val counter by t.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(71_000, easing = LinearEasing)),
        label = "counter"
    )
    val pulse by t.animateFloat(
        initialValue = .62f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    TesseractMark(
        modifier = modifier, outer = outer, inner = inner, strut = strut,
        alpha = alpha, stroke = stroke,
        phase = spin, innerPhase = counter, core = if (withCore) pulse else 0f
    )
}

/* ---------------- scaffolding ---------------- */

@Composable
fun TessScreen(
    title: String,
    subtitle: String? = null,
    showBack: Boolean = true,
    action: (@Composable RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF081120), T.Void), startY = 0f, endY = 900f)
            )
            .verticalScroll(rememberScrollState())
            // keeps text fields above the keyboard on every screen
            .imePadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(30.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showBack) {
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(T.Deep)
                        .border(1.dp, T.Edge, RoundedCornerShape(9.dp))
                        .clickable { (ctx as? Activity)?.finish() },
                    contentAlignment = Alignment.Center
                ) { Text("‹", color = T.Cyan, fontSize = 20.sp) }
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = T.Hi)
                subtitle?.let {
                    Text(it.uppercase(), fontSize = 10.sp, color = T.Low,
                        fontWeight = FontWeight.Medium, letterSpacing = 1.4.sp)
                }
            }
            UndoButton()
            action?.invoke(this)
        }
        Spacer(Modifier.height(18.dp))
        content()
        Spacer(Modifier.height(44.dp))
    }
}

@Composable
fun TCard(
    label: String? = null,
    accent: Color = T.Edge,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(T.Deep)
            .border(1.dp, accent.copy(alpha = .55f), RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        label?.let {
            Text(it.uppercase(), fontSize = 10.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(12.dp))
        }
        content()
    }
}

/** A big tappable tile that opens its own screen. */
@Composable
fun NavTile(
    title: String,
    detail: String,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(T.Deep)
            .border(1.dp, accent.copy(alpha = .4f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
        Spacer(Modifier.height(2.dp))
        Text(detail, fontSize = 11.sp, color = T.Mid, lineHeight = 14.sp)
    }
}

@Composable
fun StatChip(value: String, label: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(T.Deep)
            .border(1.dp, T.Edge, RoundedCornerShape(12.dp))
            .padding(vertical = 12.dp, horizontal = 12.dp)
    ) {
        // a six-figure number wrapped mid-digits before; it shrinks now instead
        Text(
            value,
            fontSize = when (value.length) {
                in 0..6 -> 22.sp
                7 -> 19.sp
                8 -> 17.sp
                9 -> 15.sp
                else -> 13.sp
            },
            fontWeight = FontWeight.Bold,
            color = accent,
            maxLines = 1,
            softWrap = false
        )
        Text(label.uppercase(), fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Medium, letterSpacing = 1.sp,
            maxLines = 1, softWrap = false)
    }
}

@Composable
fun PrimaryBtn(text: String, modifier: Modifier = Modifier, accent: Color = T.Cyan, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(11.dp),
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF051020)),
        modifier = modifier.fillMaxWidth().height(48.dp)
    ) { Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp) }
}

@Composable
fun GhostBtn(text: String, modifier: Modifier = Modifier, color: Color = T.Cyan, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(11.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .5f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
        modifier = modifier.fillMaxWidth().height(46.dp)
    ) { Text(text, fontSize = 14.sp) }
}

@Composable
fun Hint(text: String) {
    Text(text, fontSize = 11.sp, color = T.Low, lineHeight = 15.sp)
}

/**
 * One rule per kind of number, so a field can never quietly accept something its
 * parser will throw away. A whole-number field that took "30.5" and then saved
 * nothing is exactly the failure this prevents.
 */
fun cleanNumber(raw: String, decimal: Boolean, integer: Boolean, signed: Boolean): String {
    // stop at a decimal point rather than swallowing it: "30.5" is 30, not 305
    if (integer) return raw.substringBefore('.').filter { it.isDigit() }
    if (!decimal && !signed) return raw

    val negative = signed && raw.trimStart().startsWith("-")
    val kept = raw.filter { it.isDigit() || it == '.' }
    val i = kept.indexOf('.')
    val one = if (i < 0) kept else kept.substring(0, i + 1) + kept.substring(i + 1).replace(".", "")
    return if (negative) "-$one" else one
}

@Composable
fun DarkField(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    numeric: Boolean = false,     // decimal: money, rates, percentages
    integer: Boolean = false,     // whole numbers: days, counts, thresholds
    signed: Boolean = false,      // decimal that may be negative: coordinates
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw -> onChange(cleanNumber(raw, numeric, integer, signed)) },
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        shape = RoundedCornerShape(10.dp),
        keyboardOptions = KeyboardOptions(
            keyboardType = when {
                integer -> KeyboardType.Number
                numeric || signed -> KeyboardType.Decimal
                else -> KeyboardType.Text
            }
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = T.Hi, unfocusedTextColor = T.Hi,
            focusedBorderColor = T.Cyan, unfocusedBorderColor = T.Edge,
            focusedLabelColor = T.Cyan, unfocusedLabelColor = T.Low,
            cursorColor = T.Cyan,
            focusedContainerColor = T.Glow.copy(alpha = .5f),
            unfocusedContainerColor = T.Glow.copy(alpha = .3f)
        ),
        modifier = modifier
    )
}

/** A Double turned back into an editable string, without a trailing ".0" that
 *  a person never typed. */
fun fmtNum(v: Double): String {
    // to the cent first, so float dust (2.9999999, -0.0000001) never shows
    val r = Math.round(v * 100) / 100.0
    if (r == 0.0) return "0"
    if (r == r.toLong().toDouble()) return r.toLong().toString()
    return String.format(java.util.Locale.US, "%.2f", r).trimEnd('0').trimEnd('.')
}

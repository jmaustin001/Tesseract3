package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.onboarded(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java)); finish(); return
        }
        val want = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
        Scheduler.scheduleNextCheck(this)
        setContent { TessTheme { Dashboard() } }
    }

    fun requestBackground() {
        if (Build.VERSION.SDK_INT >= 29)
            perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }

    fun restartSetup() { startActivity(Intent(this, OnboardingActivity::class.java)); finish() }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val year = remember { Store.year() }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) { tick++ }

    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)
    val days = remember(tick) { Store.days(ctx, year) }
    val n = remember(tick) { Store.stateDays(ctx, counted, year) }
    val homeN = remember(tick) { Store.stateDays(ctx, home, year) }
    val offN = remember(tick) { Store.offStationDays(ctx, year) }
    val untagged = remember(tick) { Store.untaggedOutDays(ctx, year) }
    val gaps = remember(tick) { Store.gapDays(ctx, year) }
    val projected = remember(tick) { Store.projectedStateDays(ctx, counted, year) }
    val limit = Store.limit(ctx)
    val soft1 = Store.soft1(ctx); val soft2 = Store.soft2(ctx); val hard = Store.hard(ctx)

    val stage = when {
        n >= limit -> 4; n >= hard -> 3; n >= soft2 -> 2; n >= soft1 -> 1; else -> 0
    }
    val accent = when (stage) { 0 -> T.Cyan; 1, 2 -> T.Gold; else -> T.Danger }

    TessScreen(
        title = "TESSERACT",
        subtitle = "residency log · $year",
        showBack = false,
        action = {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                    .background(T.Deep).border(1.dp, T.Edge, RoundedCornerShape(10.dp))
                    .clickable { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = T.Mid, fontSize = 17.sp) }
        }
    ) {
        /* ---- hero ---- */
        Box(
            Modifier.fillMaxWidth().height(196.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0C1930), Color(0xFF071120))))
                .border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(18.dp))
        ) {
            TesseractMark(
                modifier = Modifier.size(190.dp).align(Alignment.CenterEnd).offset(x = 52.dp),
                outer = accent, inner = accent, strut = accent, alpha = .13f, stroke = 2.4f
            )
            Column(Modifier.padding(18.dp).align(Alignment.CenterStart)) {
                Text("DAYS IN ${counted.uppercase()}", fontSize = 10.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$n", fontSize = 62.sp, fontWeight = FontWeight.Bold,
                        color = T.Hi, letterSpacing = (-2).sp)
                    Text(" / $limit", fontSize = 18.sp, color = T.Mid,
                        modifier = Modifier.padding(bottom = 12.dp))
                }
                Spacer(Modifier.height(10.dp))
                StageBar(n, soft1, soft2, hard, limit, accent)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (n < limit) "${limit - n} days of room left" else "${n - limit} days past the line",
                    fontSize = 12.sp, color = if (stage >= 3) T.Danger else T.Mid
                )
                if (projected >= 0) Text(
                    "pace projects $projected by year end",
                    fontSize = 11.sp, color = if (projected > limit) T.Danger else T.Low
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("$homeN", "$home days", T.Teal, Modifier.weight(1f))
            StatChip("$offN", "off station", T.Violet, Modifier.weight(1f))
            StatChip("${days.size}", "logged", T.Cyan, Modifier.weight(1f))
        }

        /* ---- today ---- */
        Spacer(Modifier.height(10.dp))
        val today = remember(tick) { Store.days(ctx, year).firstOrNull { it.date == Store.today() } }
        TCard(label = "today", accent = T.Cyan) {
            if (today == null) {
                Text("No fix yet today.", fontSize = 15.sp, color = T.Hi)
                Spacer(Modifier.height(3.dp))
                Hint("Next automatic check at ${Store.checkHours(ctx).firstOrNull { it > java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) } ?: Store.checkHours(ctx).firstOrNull() ?: 0}:00.")
            } else {
                Text(today.states.joinToString(", "), fontSize = 19.sp,
                    fontWeight = FontWeight.SemiBold, color = T.Hi)
                Spacer(Modifier.height(2.dp))
                Text(today.status.ifBlank { "not categorised" }, fontSize = 13.sp,
                    color = if (today.status.isBlank()) T.Gold else T.Mid)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryBtn("Check now", Modifier.weight(1f)) { Scheduler.checkNow(ctx); tick++ }
                GhostBtn("Categorise", Modifier.weight(1f)) {
                    ctx.startActivity(Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", Store.today())
                        .putExtra("summary", "Set today's category.")
                        .putExtra("guess", Status.DUTY))
                }
            }
        }

        /* ---- anything demanding attention ---- */
        if (untagged.isNotEmpty() || gaps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            TCard(label = "needs you", accent = T.Gold) {
                if (untagged.isNotEmpty())
                    AlertRow("${untagged.size} day${if (untagged.size == 1) "" else "s"} without a category",
                        "Off station and unlabelled", T.Gold) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
                if (untagged.isNotEmpty() && gaps.isNotEmpty()) Spacer(Modifier.height(10.dp))
                if (gaps.isNotEmpty())
                    AlertRow("${gaps.size} day${if (gaps.size == 1) "" else "s"} with no data",
                        "Gaps weaken the whole log", T.Danger) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
            }
        }

        /* ---- navigation ---- */
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Year view", "Every day as one picture", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, YearActivity::class.java))
            }
            NavTile("Datums", "${Store.datums(ctx).size} reference points", T.Teal, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, DatumsActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Reports", "CSV, email, backup", T.Violet, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, ReportsActivity::class.java))
            }
            NavTile("Settings", "States, schedule, warnings", T.Cyan, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
            }
        }

        Spacer(Modifier.height(16.dp))
        Hint("Physical presence is what counts — any part of a day in $counted is a $counted day. " +
                "A record-keeping aid, not tax advice.")
    }
}

/** Progress with the three warning stages marked on it. */
@Composable
private fun StageBar(n: Int, s1: Int, s2: Int, hard: Int, limit: Int, accent: Color) {
    Box(
        Modifier.fillMaxWidth(.62f).height(7.dp)
            .clip(RoundedCornerShape(4.dp)).background(Color(0xFF16243A))
    ) {
        Box(
            Modifier.fillMaxWidth((n.toFloat() / limit).coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = .6f), accent)))
        )
        listOf(s1, s2, hard).forEach { mark ->
            Box(
                Modifier.fillMaxWidth((mark.toFloat() / limit).coerceIn(0f, 1f))
                    .fillMaxHeight(), contentAlignment = Alignment.CenterEnd
            ) { Box(Modifier.width(1.5.dp).fillMaxHeight().background(T.Void.copy(alpha = .85f))) }
        }
    }
}

@Composable
private fun AlertRow(title: String, detail: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = T.Hi)
            Text(detail, fontSize = 11.sp, color = T.Low)
        }
        Text("›", color = T.Mid, fontSize = 19.sp)
    }
}

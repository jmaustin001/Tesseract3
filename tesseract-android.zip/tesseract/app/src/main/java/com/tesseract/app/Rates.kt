package com.tesseract.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Per diem rates change every 1 October, and a stale rate produces a number
 * that looks right and is not.
 *
 * This reads a small JSON file from the same repository the app updates from —
 * no scraping, no API key. A page layout change cannot silently corrupt it,
 * because there is no page. If the fetch fails, the built-in rates stay and the
 * app says how old they are rather than pretending.
 */
object Rates {

    private const val CACHE = "ratesCache"
    private const val FETCHED = "ratesFetchedAt"

    data class Table(
        val fiscalYear: Int,
        val expires: String,
        val source: String,
        val tiers: List<Perdiem.Tier>
    )

    /** What shipped with this build. */
    val builtIn = Table(
        fiscalYear = 2026,
        expires = "2026-09-30",
        source = "built into the app",
        tiers = Perdiem.TIERS
    )

    fun current(ctx: Context): Table {
        val raw = Store.prefString(ctx, CACHE, "")
        if (raw.isBlank()) return builtIn
        return try { parse(JSONObject(raw)) } catch (e: Exception) { builtIn }
    }

    fun isExpired(ctx: Context): Boolean = Store.today() > current(ctx).expires

    /** Days until the table goes stale — negative once it has. */
    fun daysLeft(ctx: Context): Int {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return try {
            val e = fmt.parse(current(ctx).expires)!!.time
            val n = fmt.parse(Store.today())!!.time
            ((e - n) / 86_400_000L).toInt()
        } catch (ex: Exception) { 0 }
    }

    fun lastFetched(ctx: Context): String = Store.prefString(ctx, FETCHED, "never")

    suspend fun fetch(ctx: Context): Result<Table> = withContext(Dispatchers.IO) {
        val repo = Store.updateRepo(ctx)
        if (repo.isBlank()) return@withContext Result.failure(Exception("No repository set."))
        try {
            val conn = (URL("https://raw.githubusercontent.com/$repo/main/rates.json")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000; readTimeout = 12000
            }
            if (conn.responseCode != 200)
                return@withContext Result.failure(Exception("Rates file not found (${conn.responseCode})."))
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val table = parse(JSONObject(text))     // parse before caching, so bad data never lands
            Store.setPrefString(ctx, CACHE, text)
            Store.setPrefString(ctx, FETCHED, Store.today())
            Result.success(table)
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun parse(o: JSONObject): Table {
        val arr = o.getJSONArray("tiers")
        val tiers = (0 until arr.length()).map {
            val t = arr.getJSONObject(it)
            Perdiem.Tier(
                t.getInt("total"), t.getInt("breakfast"), t.getInt("lunch"),
                t.getInt("dinner"), t.optInt("incidental", 5)
            )
        }
        require(tiers.isNotEmpty()) { "rates file has no tiers" }
        return Table(
            o.optInt("fiscalYear", 0),
            o.optString("expires", "2099-12-31"),
            o.optString("source", "fetched"),
            tiers
        )
    }
}

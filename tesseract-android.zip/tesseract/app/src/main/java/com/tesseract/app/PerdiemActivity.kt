package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class PerdiemActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { PerdiemScreen() } }
    }
}

private fun money(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

@Composable
private fun PerdiemScreen() {
    val ctx = LocalContext.current
    var year by remember { mutableIntStateOf(Store.year()) }
    val today = Store.today()
    var tick by remember { mutableIntStateOf(0) }
    var ratesTick by remember { mutableIntStateOf(0) }
    var locTick by remember { mutableIntStateOf(0) }
    val tiers = remember(ratesTick) { Rates.current(ctx).tiers }
    val trips = remember(tick) { TdyTrips.all(ctx) }
    val priced = remember(tick, ratesTick) { trips.associate { it.id to TdyTrips.price(it, tiers) } }
    // each trip against the day log: workdays, the salary on them, and where it was earned
    val pay = remember(tick, year) {
        val days = Store.days(ctx).associateBy { it.date }
        trips.associate { it.id to TdyTrips.salary(ctx, it, year, days) }
    }
    val counted = Store.countedState(ctx)

    // the take-home figures: M&IE only, never lodging
    val ytd = priced.values.sumOf { it.inYear(year, today) }
    val ytdDays = priced.values.sumOf { it.daysInYear(year, today) }
    val planned = priced.values.sumOf { it.inYear(year) }
    val salary = remember(tick, year) { Workdays.blendedAnnualSalary(ctx, year) }
    var marginal by remember { mutableStateOf(Store.prefString(ctx, "tdyMarginal", "29.65")) }
    val mr = ((marginal.toDoubleOrNull() ?: 0.0) / 100.0).coerceIn(0.0, 0.95)

    var editing by remember { mutableStateOf<TdyTrip?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    TessScreen("TDY per diem", "M&IE · tax-free take-home") {

        /* ---- the headline: tax-free M&IE so far this year ---- */
        TCard("tax-free M&IE · $year", T.Gold) {
            Text(money(ytd), fontSize = 38.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text("year to date · $ytdDays day${if (ytdDays == 1) "" else "s"} through today",
                fontSize = 12.sp, color = T.Mid)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip(money(planned), "all trips this year", T.Gold, Modifier.weight(1f))
                StatChip("${trips.count { (priced[it.id]?.daysInYear(year) ?: 0) > 0 }}",
                    "trips this year", T.Gold, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Hint("M&IE paid under an accountable plan is not wages: it is not on your W-2 " +
                    "and no tax comes out of it, so every dollar is take-home whatever you " +
                    "spend on food. Lodging is reimbursed against the receipt and is never " +
                    "counted here.")
        }

        /* ---- alongside the salary ---- */
        Spacer(Modifier.height(10.dp))
        TCard("with your salary", T.Teal) {
            if (salary <= 0.0) {
                Hint("Add your SF-50s on the Pay screen to see this next to your salary.")
            } else {
                Line3("Annual salary, from your SF-50s", money(salary))
                Line3("+ tax-free M&IE, year to date", money(ytd))
                HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 6.dp))
                Line3("Salary plus M&IE so far", money(salary + ytd), bold = true)
                if (planned > ytd) Line3("… with every trip this year", money(salary + planned))
            }
            Spacer(Modifier.height(12.dp))
            DarkField(marginal, "Your combined marginal rate %", Modifier.fillMaxWidth(), numeric = true) {
                marginal = it; Store.setPrefString(ctx, "tdyMarginal", it)
            }
            Spacer(Modifier.height(8.dp))
            if (mr < 0.95 && ytd > 0) {
                val gross = ytd / (1 - mr)
                Line3("Taxable pay it would take to net the same", money(gross))
                Line3("Tax it avoids", money(gross - ytd))
            }
            Spacer(Modifier.height(6.dp))
            Hint("29.65% is the 22% federal bracket plus 7.65% Social Security and Medicare, " +
                    "with no Florida income tax. Use 31.65 for the 24% bracket. A tax-free " +
                    "dollar is worth more than a salary dollar by exactly this much.")
        }

        /* ---- the running TDY log, oldest first, with a running M&IE total ---- */
        Spacer(Modifier.height(10.dp))
        val yearTrips = trips.filter { (priced[it.id]?.daysInYear(year) ?: 0) > 0 }.sortedBy { it.start }
        TCard("TDY log · $year", T.Cyan) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { year -= 1 }) { Text("◀ ${year - 1}", color = T.Mid, fontSize = 12.sp) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { year += 1 }) { Text("${year + 1} ▶", color = T.Mid, fontSize = 12.sp) }
            }
            if (yearTrips.isEmpty() && editing == null) {
                Hint("No trips in $year. Add each one once: where, the dates, the state, and the " +
                        "M&IE and lodging off the GSA table. Tie it to a datum and the log fills the " +
                        "dates and checks them.")
            } else {
                Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                    Text("TRIP", fontSize = 9.sp, color = T.Low, modifier = Modifier.weight(1f))
                    Text("M&IE", fontSize = 9.sp, color = T.Low, modifier = Modifier.width(84.dp))
                    Text("RUNNING", fontSize = 9.sp, color = T.Low, modifier = Modifier.width(92.dp))
                }
            }
            var running = 0.0
            yearTrips.forEach { t ->
                val p = priced[t.id] ?: return@forEach
                val s = pay[t.id]
                val earned = p.inYear(year, today)
                val isPlanned = t.start > today
                running += earned
                val open = editing?.id == t.id
                Column(Modifier.fillMaxWidth().clickable {
                        editing = if (open) null else t; confirmDelete = false
                    }.padding(vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.place + (if (t.state.isNotBlank()) " · " + t.state else ""),
                                fontSize = 14.sp, color = T.Hi, fontWeight = FontWeight.SemiBold)
                            Text(PayPeriods.span(t.start, t.end) + " · ${p.days} days · " +
                                    money(t.mie.toDoubleOrNull() ?: 0.0) + "/day" +
                                    (if (t.end >= today && t.start <= today) " · in progress" else "") +
                                    (if (isPlanned) " · planned" else ""),
                                fontSize = 11.sp, color = T.Low)
                        }
                        Text(money(if (isPlanned) p.inYear(year) else earned), fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPlanned) T.Low else T.Gold, modifier = Modifier.width(84.dp))
                        Text(if (isPlanned) "—" else money(running), fontSize = 13.sp,
                            color = T.Hi, modifier = Modifier.width(92.dp))
                    }
                    if (s != null && s.workdays > 0) {
                        Text("${s.workdays} workday${if (s.workdays == 1) "" else "s"} · " +
                                money(s.pay) + " salary" +
                                (if (s.notCounted > 0) " · ${s.notCounted} earned outside $counted" else "") +
                                (if (s.countedInLog > 0) " · ${s.countedInLog} still earned in $counted in the log" else "") +
                                (if (s.unlogged > 0 && !isPlanned) " · ${s.unlogged} not in the log" else ""),
                            fontSize = 10.sp,
                            color = if (s.countedInLog > 0 || (s.unlogged > 0 && !isPlanned)) T.Gold else T.Teal)
                    }
                }
                HorizontalDivider(color = T.Edge)
            }
            if (yearTrips.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text("Earned so far in $year", fontSize = 13.sp, color = T.Mid,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(money(running), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = T.Gold)
                }
            }
            Spacer(Modifier.height(10.dp))
            if (editing == null) {
                PrimaryBtn("Add a trip", accent = T.Cyan) {
                    editing = TdyTrip(TdyTrips.newId(), "", "", today, today, "", "",
                        "0", "0", "0", false, "", "")
                    confirmDelete = false
                }
            }
        }

        /* ---- what TDY did to the counted state's share of the salary ---- */
        val wd = yearTrips.sumOf { pay[it.id]?.workdays ?: 0 }
        if (wd > 0) {
            Spacer(Modifier.height(10.dp))
            val wdPay = yearTrips.sumOf { pay[it.id]?.pay ?: 0.0 }
            val out = yearTrips.sumOf { pay[it.id]?.notCounted ?: 0 }
            val outPay = yearTrips.sumOf { pay[it.id]?.notCountedPay ?: 0.0 }
            val stillIn = yearTrips.sumOf { pay[it.id]?.countedInLog ?: 0 }
            TCard("TDY and $counted · $year", T.Danger) {
                Line3("Workdays on TDY", "$wd")
                Line3("Salary on those workdays", money(wdPay))
                Line3("… earned outside $counted, per the log", "$out days · " + money(outPay), bold = true)
                Spacer(Modifier.height(6.dp))
                Hint("Salary on a TDY day is paid at the same SF-50 rate, but it is earned where " +
                        "the work was done — so a TDY day in Florida is a workday $counted cannot " +
                        "tax. These days come out of the $counted share on the Form 763 working " +
                        "automatically, because the log already places each one.")
                if (stillIn > 0) {
                    Spacer(Modifier.height(6.dp))
                    Text("$stillIn TDY workday${if (stillIn == 1) " is" else "s are"} still earned in " +
                            "$counted in the log. If you were away, open the trip and use " +
                            "Put these days in the log, or fix the day's earning state.",
                        fontSize = 11.sp, color = T.Gold)
                }
            }
        }

        editing?.let { draft ->
            Spacer(Modifier.height(10.dp))
            TripEditor(
                draft = draft,
                isNew = trips.none { it.id == draft.id },
                tiers = tiers,
                confirmDelete = confirmDelete,
                onChange = { editing = it },
                onSave = { TdyTrips.upsert(ctx, it); editing = null; tick++ },
                onDelete = {
                    if (!confirmDelete) confirmDelete = true
                    else { TdyTrips.delete(ctx, draft.id); editing = null; confirmDelete = false; tick++ }
                },
                onCancel = { editing = null; confirmDelete = false },
                onLogChanged = { tick++ }
            )
        }

        Spacer(Modifier.height(10.dp))
        EstimateCard(year, ytd, onSaveAsTrip = { t -> editing = t; confirmDelete = false })

        Spacer(Modifier.height(10.dp))
        LocalityCard(locTick, editing?.start?.drop(5)?.take(2)?.toIntOrNull()
                ?: java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1,
            null,
            onMonth = { },
            onPick = { l ->
                // a saved destination fills the trip being edited
                editing?.let { e ->
                    val mon = e.start.drop(5).take(2).toIntOrNull() ?: 1
                    editing = e.copy(place = e.place.ifBlank { l?.name ?: "" },
                        mie = l?.let { fmtNum(it.mie) } ?: e.mie,
                        lodging = l?.let { fmtNum(it.lodgingFor(mon)) } ?: e.lodging)
                }
            },
            onChanged = { locTick++ })

        Spacer(Modifier.height(10.dp))
        RatesBanner(ratesTick) { ratesTick++ }

        Spacer(Modifier.height(10.dp))
        TCard("before you rely on this", T.Danger) {
            Hint("A planning estimate; your travel office settles the voucher against the " +
                    "JTR. Per diem stops being tax-free if a TDY is expected to last more than a " +
                    "year — then it is wages. TDY to the area where you live and commute from " +
                    "home generally pays no lodging, and M&IE may not be payable either; " +
                    "check with your approving official before counting on it.")
        }
    }
}

@Composable
private fun TripEditor(
    draft: TdyTrip,
    isNew: Boolean,
    tiers: List<Perdiem.Tier>,
    confirmDelete: Boolean,
    onChange: (TdyTrip) -> Unit,
    onSave: (TdyTrip) -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
    onLogChanged: () -> Unit
) {
    val ctx = LocalContext.current
    val datums = remember { Store.datums(ctx) }
    val datumStates = remember { Earnings.datumStates(ctx) }
    var msg by remember(draft.id) { mutableStateOf("") }
    var sureMark by remember(draft.id) { mutableStateOf(false) }
    var markTick by remember(draft.id) { mutableIntStateOf(0) }
    val p = TdyTrips.price(draft, tiers)
    val meals = TdyTrips.mealsFor(draft.mie.toDoubleOrNull() ?: 0.0, tiers)
    val datum = datums.firstOrNull { it.name == draft.datum }
    val problem = TdyTrips.problem(draft)

    TCard(if (isNew) "new trip" else "edit trip", T.Gold) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(draft.place, "Where — city, base, installation", Modifier.weight(2.2f)) {
                onChange(draft.copy(place = it))
            }
            DarkField(draft.state, "State", Modifier.weight(1f)) {
                onChange(draft.copy(state = it.uppercase().take(3)))
            }
        }
        if (datums.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("TIE IT TO A DATUM (OPTIONAL)", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (listOf("") + datums.map { it.name }).forEach { n ->
                    val on = draft.datum == n
                    Box(Modifier.clip(RoundedCornerShape(8.dp))
                        .background(if (on) T.Gold.copy(alpha = .18f) else T.Glow)
                        .border(1.dp, if (on) T.Gold else T.Edge, RoundedCornerShape(8.dp))
                        .clickable {
                            onChange(draft.copy(datum = n, place = draft.place.ifBlank { n },
                                state = draft.state.ifBlank { datumStates[n] ?: "" }))
                        }
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                    ) { Text(n.ifBlank { "None" }, fontSize = 12.sp, color = if (on) T.Gold else T.Mid) }
                }
            }
            if (datum?.role == Datum.RESIDENCE) {
                Spacer(Modifier.height(6.dp))
                Text("That is your residence. TDY where you live and commute from home " +
                        "generally pays no lodging, and M&IE may not be payable — confirm " +
                        "with your approving official.", fontSize = 11.sp, color = T.Danger)
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(draft.start, "Travel out (YYYY-MM-DD)", Modifier.weight(1f)) {
                onChange(draft.copy(start = it))
            }
            DarkField(draft.end, "Travel back", Modifier.weight(1f)) { onChange(draft.copy(end = it)) }
        }
        Spacer(Modifier.height(8.dp))
        GhostBtn("Fill the dates from the log", color = T.Cyan) {
            val run = TdyTrips.lastRunAt(ctx, draft.datum)
            if (run == null) msg = "Nothing in the log at that datum or categorized TDY yet."
            else { onChange(draft.copy(start = run.first, end = run.second)); msg = "Filled: ${run.first} to ${run.second}." }
        }
        val checked = TdyTrips.logCheck(ctx, draft)
        if (p.days > 0) {
            Spacer(Modifier.height(4.dp))
            Text(
                if (draft.datum.isBlank() && checked == 0) "${p.days} days. Not tied to a datum."
                else "${p.days} days — the log has $checked of them at ${draft.datum.ifBlank { "a TDY location" }} or categorized TDY.",
                fontSize = 11.sp, color = if (checked in 1 until p.days) T.Gold else T.Low)
        }
        if (msg.isNotBlank()) Text(msg, fontSize = 11.sp, color = T.Teal)

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(draft.mie, "M&IE per day", Modifier.weight(1f), numeric = true) {
                onChange(draft.copy(mie = it))
            }
            DarkField(draft.lodging, "Lodging per night", Modifier.weight(1f), numeric = true) {
                onChange(draft.copy(lodging = it))
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tiers.forEach { t ->
                Box(Modifier.clip(RoundedCornerShape(8.dp)).background(T.Glow)
                    .border(1.dp, T.Edge, RoundedCornerShape(8.dp))
                    .clickable { onChange(draft.copy(mie = fmtNum(t.total))) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                ) { Text(t.label, fontSize = 12.sp, color = T.Mid) }
            }
        }
        Spacer(Modifier.height(4.dp))
        Hint("Read both off the GSA table for the destination and the fiscal year of the " +
                "trip. The chips are quick fills for M&IE from the built-in tier list.")

        Spacer(Modifier.height(12.dp))
        Text("GOVERNMENT MEALS PROVIDED", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(draft.breakfasts, "Breakfasts", Modifier.weight(1f), integer = true) { onChange(draft.copy(breakfasts = it)) }
            DarkField(draft.lunches, "Lunches", Modifier.weight(1f), integer = true) { onChange(draft.copy(lunches = it)) }
            DarkField(draft.dinners, "Dinners", Modifier.weight(1f), integer = true) { onChange(draft.copy(dinners = it)) }
        }
        Spacer(Modifier.height(4.dp))
        Text("At this rate: breakfast ${money(meals.b)} · lunch ${money(meals.l)} · dinner ${money(meals.d)}. " +
                "A hotel's free breakfast doesn't count.", fontSize = 11.sp, color = T.Low)

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Long-term flat rate authorized", fontSize = 13.sp, color = T.Hi)
                Text("75% from 31 days, 55% from 181 — only if on your orders",
                    fontSize = 10.sp, color = T.Low)
            }
            Switch(checked = draft.longTerm, onCheckedChange = { onChange(draft.copy(longTerm = it)) })
        }

        Spacer(Modifier.height(12.dp))
        DarkField(draft.note, "Note — orders number, purpose", Modifier.fillMaxWidth()) {
            onChange(draft.copy(note = it))
        }

        // the trip's own breakdown, live
        if (p.days > 0 && (draft.mie.toDoubleOrNull() ?: 0.0) > 0) {
            Spacer(Modifier.height(14.dp))
            Line("${p.fullDays} full day${if (p.fullDays == 1) "" else "s"} at ${money(p.rate)}",
                money(p.fullDays * p.rate))
            Line("${p.travelDays} travel day${if (p.travelDays == 1) "" else "s"} at 75%",
                money(p.travelDays * p.rate * Perdiem.FIRST_LAST))
            if (p.flat < 1.0) Line("Long-term flat rate", "${(p.flat * 100).toInt()}% of ${money(draft.mie.toDoubleOrNull() ?: 0.0)}")
            if (p.deductions > 0) Line("Meals provided", "− " + money(p.deductions), true)
            HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 6.dp))
            Line("Tax-free M&IE", money(p.net), bold = true)
            if (p.lodgingCap > 0) {
                Spacer(Modifier.height(4.dp))
                Text("Lodging: up to ${money(p.lodgingCap)} over ${p.nights} night${if (p.nights == 1) "" else "s"}, " +
                        "reimbursed against the receipt — not take-home.",
                    fontSize = 11.sp, color = T.Low)
            }
        }

        // put the trip into the day log, for a saved trip only
        if (!isNew && problem == null) {
            val preview = remember(draft, markTick) { TdyTrips.markInLog(ctx, draft, dryRun = true) }
            Spacer(Modifier.height(14.dp))
            Text("THE DAY LOG", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(4.dp))
            if (preview.categorize + preview.add == 0) {
                Text(if (preview.conflicts > 0) "${preview.conflicts} day(s) in this trip already carry another category — open them in the year view to change."
                     else "Every day of this trip so far is in the log as TDY.",
                    fontSize = 11.sp, color = if (preview.conflicts > 0) T.Gold else T.Teal)
            } else {
                Text(listOfNotNull(
                        if (preview.categorize > 0) "${preview.categorize} logged day(s) get the TDY category" else null,
                        if (preview.add > 0) "${preview.add} day(s) with no entry are added by hand at ${draft.state}" +
                            (if (draft.datum.isNotBlank()) ", ${draft.datum}" else "") else null,
                        if (preview.conflicts > 0) "${preview.conflicts} with another category are left alone" else null,
                        if (preview.future > 0) "${preview.future} future day(s) wait" else null
                    ).joinToString("; ") + ".", fontSize = 11.sp, color = T.Mid)
                Spacer(Modifier.height(6.dp))
                GhostBtn(if (sureMark) "Tap again to update the log" else "Put these days in the log",
                    color = T.Cyan) {
                    if (!sureMark) { sureMark = true; return@GhostBtn }
                    val r = TdyTrips.markInLog(ctx, draft, dryRun = false)
                    msg = "Log updated: ${r.categorize} categorized, ${r.add} added."
                    sureMark = false
                    markTick++
                    onLogChanged()
                }
            }
            if (draft.state.isBlank()) {
                Text("Add the state to fill days with no entry.", fontSize = 11.sp, color = T.Low)
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryBtn(problem ?: "Save trip", Modifier.weight(1f),
                accent = if (problem == null) T.Gold else T.Edge) {
                if (problem == null) onSave(draft)
            }
            GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { onCancel() }
        }
        if (!isNew) {
            Spacer(Modifier.height(8.dp))
            GhostBtn(if (confirmDelete) "Tap again to delete this trip" else "Delete trip",
                color = T.Danger) { onDelete() }
        }
    }
}

/**
 * Try a trip, or a pattern for the rest of the year, without saving anything.
 * What you type is remembered between visits so a forecast can be revisited,
 * but none of it touches the log or the trip list until you save it as a trip.
 */
@Composable
private fun EstimateCard(year: Int, ytd: Double, onSaveAsTrip: (TdyTrip) -> Unit) {
    val ctx = LocalContext.current
    fun pref(k: String, d: String) = Store.prefString(ctx, k, d)
    var mode by remember { mutableStateOf(pref("estMode", "trip")) }
    val counted = Store.countedState(ctx)
    val today = Store.today()

    // what a workday is worth, and the counted state's tax on it
    val dailyPay = remember { Workdays.dailyRateFor(ctx, today, year) }
    val effRate = remember {
        val basis = Store.totalIncome(ctx).let { if (it > 0) it else Workdays.blendedAnnualSalary(ctx, year) }
        VaTax.effectiveRate(basis, Store.filingJoint(ctx), Store.exemptions(ctx), year)
    }
    val stateNow = remember { Store.stateDays(ctx, counted, year) }
    val limit = Store.limit(ctx)

    TCard("estimate · nothing saved", T.Violet) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("trip" to "One trip", "year" to "Rest of the year").forEach { (k, label) ->
                val on = mode == k
                Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (on) T.Violet.copy(alpha = .2f) else T.Glow)
                    .border(1.dp, if (on) T.Violet else T.Edge, RoundedCornerShape(9.dp))
                    .clickable { mode = k; Store.setPrefString(ctx, "estMode", k) }
                    .padding(vertical = 11.dp), contentAlignment = Alignment.Center
                ) { Text(label, fontSize = 13.sp, color = if (on) T.Violet else T.Mid) }
            }
        }
        Spacer(Modifier.height(12.dp))

        if (mode == "trip") {
            var place by remember { mutableStateOf(pref("estPlace", "")) }
            var state by remember { mutableStateOf(pref("estState", "")) }
            var start by remember { mutableStateOf(pref("estStart", today)) }
            var end by remember { mutableStateOf(pref("estEnd", today)) }
            var mie by remember { mutableStateOf(pref("estMie", "")) }
            var lodging by remember { mutableStateOf(pref("estLodging", "")) }
            val ok = Regex("\\d{4}-\\d{2}-\\d{2}").let { it.matches(start) && it.matches(end) } && end >= start
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(place, "Where", Modifier.weight(2.2f)) { place = it; Store.setPrefString(ctx, "estPlace", it) }
                DarkField(state, "State", Modifier.weight(1f)) {
                    state = it.uppercase().take(3); Store.setPrefString(ctx, "estState", state)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(start, "Out (YYYY-MM-DD)", Modifier.weight(1f)) { start = it; Store.setPrefString(ctx, "estStart", it) }
                DarkField(end, "Back", Modifier.weight(1f)) { end = it; Store.setPrefString(ctx, "estEnd", it) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(mie, "M&IE per day", Modifier.weight(1f), numeric = true) { mie = it; Store.setPrefString(ctx, "estMie", it) }
                DarkField(lodging, "Lodging per night", Modifier.weight(1f), numeric = true) { lodging = it; Store.setPrefString(ctx, "estLodging", it) }
            }
            if (ok && (mie.toDoubleOrNull() ?: 0.0) > 0) {
                val p = TdyTrips.price(start, end, mie.toDouble(), lodging.toDoubleOrNull() ?: 0.0,
                    0.0, 0.0, 0.0, 0, 0, 0, false)
                val wd = Workdays.scheduledWorkdaysBetween(ctx, start, nextDay(end))
                val moved = state.isNotBlank() && state != counted
                Spacer(Modifier.height(12.dp))
                Text(money(p.net), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = T.Gold)
                Text("tax-free M&IE · ${p.days} days (${p.fullDays} full, ${p.travelDays} at 75%)",
                    fontSize = 12.sp, color = T.Mid)
                Spacer(Modifier.height(8.dp))
                Line3("This year with it", money(ytd + p.inYear(year)))
                if (p.lodgingCap > 0) Line3("Lodging ceiling, against receipts", money(p.lodgingCap))
                Line3("Workdays on the trip", "$wd")
                if (moved && wd > 0) {
                    Line3("Salary earned in $state, not $counted", money(wd * dailyPay))
                    Line3("$counted tax that takes off", money(wd * dailyPay * effRate), bold = true)
                    Line3("$counted days avoided", "${p.days}")
                } else if (state == counted) {
                    Text("A trip inside $counted keeps its days and its pay in $counted.",
                        fontSize = 11.sp, color = T.Low)
                }
                Spacer(Modifier.height(10.dp))
                GhostBtn("Save this as a planned trip", color = T.Gold) {
                    onSaveAsTrip(TdyTrip(TdyTrips.newId(), place, "", start, end, mie, lodging,
                        "0", "0", "0", false, "planned from an estimate", state))
                }
            } else {
                Hint("Type the dates and the M&IE rate to see the trip priced.")
            }
        } else {
            var perMonth by remember { mutableStateOf(pref("estPerMonth", "2")) }
            var days by remember { mutableStateOf(pref("estDays", "5")) }
            var work by remember { mutableStateOf(pref("estWork", "4")) }
            var mie by remember { mutableStateOf(pref("estPMie", "68")) }
            var state by remember { mutableStateOf(pref("estPState", Store.homeState(ctx))) }
            val left = remember { daysToYearEnd(today) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(perMonth, "Trips a month", Modifier.weight(1f), numeric = true) { perMonth = it; Store.setPrefString(ctx, "estPerMonth", it) }
                DarkField(days, "Days each", Modifier.weight(1f), integer = true) { days = it; Store.setPrefString(ctx, "estDays", it) }
                DarkField(work, "Workdays each", Modifier.weight(1f), integer = true) { work = it; Store.setPrefString(ctx, "estWork", it) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(mie, "M&IE per day", Modifier.weight(1f), numeric = true) { mie = it; Store.setPrefString(ctx, "estPMie", it) }
                DarkField(state, "Usual TDY state", Modifier.weight(1f)) {
                    state = it.uppercase().take(3); Store.setPrefString(ctx, "estPState", state)
                }
            }
            val f = TdyTrips.pattern(left, perMonth.toDoubleOrNull() ?: 0.0, days.toIntOrNull() ?: 0,
                work.toIntOrNull() ?: 0, mie.toDoubleOrNull() ?: 0.0, dailyPay,
                if (state != counted) effRate else 0.0, stateNow)
            Spacer(Modifier.height(12.dp))
            Text(money(f.mie), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text("more tax-free M&IE by 31 Dec · about " + String.format(Locale.US, "%.1f", f.trips) +
                    " trips in the $left days left", fontSize = 12.sp, color = T.Mid)
            Spacer(Modifier.height(8.dp))
            Line3("$year M&IE: so far + forecast", money(ytd + f.mie), bold = true)
            if (state != counted) {
                Line3("Workdays moved out of $counted", String.format(Locale.US, "%.1f", f.workdays))
                Line3("Salary earned outside $counted", money(f.salary))
                Line3("$counted tax that takes off", money(f.stateTax))
            }
            Line3("$counted days so far", "$stateNow")
            Line3("$counted days by 31 Dec, at most", String.format(Locale.US, "%.0f", f.stateDaysAtMost) + " of $limit",
                bold = true)
            Spacer(Modifier.height(6.dp))
            Hint("\"At most\" assumes every day not away on TDY is spent in $counted — weekends " +
                    "home in Florida only bring it down. Salary uses today's SF-50 rate; tax uses your " +
                    "effective $counted rate of " + String.format(Locale.US, "%.2f%%", effRate * 100) + ".")
        }
    }
}

private fun nextDay(d: String): String = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val c = java.util.Calendar.getInstance().apply { time = f.parse(d)!! }
    c.add(java.util.Calendar.DAY_OF_YEAR, 1); f.format(c.time)
} catch (e: Exception) { d }

/** Days after today through 31 December. */
private fun daysToYearEnd(today: String): Int = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val a = f.parse(today)!!.time
    val b = f.parse(today.take(4) + "-12-31")!!.time
    Math.round((b - a) / 86_400_000.0).toInt()
} catch (e: Exception) { 0 }

@Composable
private fun Line3(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold, color = T.Hi)
    }
}

@Composable
private fun Line(label: String, value: String, minus: Boolean = false, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (minus) T.Danger else T.Hi)
    }
}

@Composable
private fun RatesBanner(tick: Int, onRefreshed: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }

    val table = remember(tick) { Rates.current(ctx) }
    val left = remember(tick) { Rates.daysLeft(ctx) }
    val expired = left < 0

    TCard("rates in use", if (expired) T.Danger else if (left < 45) T.Gold else T.Edge) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("FY${table.fiscalYear}", fontSize = 16.sp,
                    fontWeight = FontWeight.Bold, color = T.Hi)
                Text(
                    when {
                        expired -> "Expired ${-left} days ago on ${table.expires}"
                        left < 45 -> "Expires in $left days, on ${table.expires}"
                        else -> "Good until ${table.expires}"
                    },
                    fontSize = 11.sp,
                    color = if (expired) T.Danger else if (left < 45) T.Gold else T.Low
                )
            }
            TextButton(onClick = {
                if (!busy) {
                    busy = true; msg = ""
                    scope.launch {
                        Rates.fetch(ctx).fold(
                            onSuccess = {
                                msg = "Updated to FY${it.fiscalYear}."; bad = false; onRefreshed()
                            },
                            onFailure = { msg = it.message ?: "Could not fetch."; bad = true }
                        )
                        busy = false
                    }
                }
            }) { Text(if (busy) "…" else "Check", fontSize = 12.sp, color = T.Cyan) }
        }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 11.sp, color = if (bad) T.Danger else T.Teal)
        }

        if (expired) {
            Spacer(Modifier.height(10.dp))
            Hint("GSA republishes every 1 October. Tap Check to pull the new table, or type " +
                    "a rate by hand. The buttons below are last year's numbers until one or " +
                    "the other happens.")
        } else {
            Spacer(Modifier.height(8.dp))
            Hint("Source: ${table.source}. Last checked ${Rates.lastFetched(ctx)}. " +
                    "Rates are read from a small file rather than scraped from a web page, " +
                    "so a site redesign cannot quietly feed this the wrong number.")
        }
    }
}

private val MONTHS = listOf("Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec")

@Composable
private fun LocalityCard(
    tick: Int,
    month: Int,
    active: Locality?,
    onMonth: (Int) -> Unit,
    onPick: (Locality?) -> Unit,
    onChanged: () -> Unit
) {
    val ctx = LocalContext.current
    val saved = remember(tick) { Localities.all(ctx) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newMie by remember { mutableStateOf("") }
    var newLodging by remember { mutableStateOf("") }
    var seasonal by remember { mutableStateOf(false) }
    var monthly by remember { mutableStateOf(List(12) { "" }) }

    TCard("destination", if (active != null) T.Teal else T.Gold) {
        if (active == null) {
            Hint("Rates are per locality and lodging moves month by month. Look a place up " +
                    "once on GSA, save it here, and every trip after is one tap. Nothing is " +
                    "guessed — the numbers are the ones you read off the official table.")
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(active.name, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Hi)
                    Text("M&IE ${money(active.mie.toDouble())} · lodging " +
                            "${money(active.lodgingFor(month).toDouble())} in ${MONTHS[month - 1]}" +
                            if (active.seasonal) " · seasonal" else "",
                        fontSize = 11.sp, color = T.Mid)
                }
                TextButton(onClick = { onPick(null) }) {
                    Text("Clear", fontSize = 12.sp, color = T.Mid)
                }
            }
        }

        if (saved.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            saved.forEach { l ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { onPick(l) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (active?.id == l.id) T.Teal else T.Edge))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(l.name, fontSize = 14.sp, color = T.Hi)
                        Text("FY${l.fiscalYear} · ${money(l.rateFor(month).toDouble())} in ${MONTHS[month - 1]}",
                            fontSize = 10.sp, color = T.Low)
                    }
                    TextButton(onClick = { Localities.delete(ctx, l.id); onChanged() }) {
                        Text("Remove", fontSize = 11.sp, color = T.Low)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("MONTH IN QUARTERS", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            MONTHS.forEachIndexed { i, m ->
                val on = month == i + 1
                Box(
                    Modifier.clip(RoundedCornerShape(7.dp))
                        .background(if (on) T.Teal.copy(alpha = .20f) else T.Glow)
                        .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(7.dp))
                        .clickable { onMonth(i + 1) }
                        .padding(horizontal = 11.dp, vertical = 8.dp)
                ) { Text(m, fontSize = 11.sp, color = if (on) T.Teal else T.Mid) }
            }
        }

        Spacer(Modifier.height(14.dp))
        if (!adding) {
            GhostBtn("Add a destination", color = T.Gold) { adding = true }
        } else {
            DarkField(query, "City, state or ZIP", Modifier.fillMaxWidth()) { query = it }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Look it up on GSA", color = T.Cyan) {
                val fy = Rates.current(ctx).fiscalYear.let { if (it > 0) it else 2026 }
                ctx.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse(Localities.gsaUrl(query, fy)))
                )
            }
            Spacer(Modifier.height(6.dp))
            Hint("Opens the official table. Read off M&IE and the lodging for the month you " +
                    "will be there, then type them below.")

            Spacer(Modifier.height(12.dp))
            DarkField(newName, "Name it", Modifier.fillMaxWidth()) { newName = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(newMie, "M&IE", Modifier.weight(1f), numeric = true) { newMie = it }
                DarkField(newLodging, "Lodging", Modifier.weight(1f), numeric = true) {
                    newLodging = it
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lodging changes by month", fontSize = 13.sp, color = T.Hi)
                    Text("True for the DC area and most resort towns",
                        fontSize = 10.sp, color = T.Low)
                }
                Switch(checked = seasonal, onCheckedChange = { seasonal = it })
            }
            if (seasonal) {
                Spacer(Modifier.height(10.dp))
                MONTHS.chunked(3).forEachIndexed { row, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        chunk.forEachIndexed { col, m ->
                            val idx = row * 3 + col
                            DarkField(monthly[idx], m, Modifier.weight(1f), numeric = true) { v ->
                                monthly = monthly.toMutableList().also { it[idx] = v }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Hint("Any month left blank falls back to the single lodging figure above.")
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryBtn("Save destination", Modifier.weight(1f), accent = T.Teal) {
                    val base = newLodging.toDoubleOrNull() ?: 0.0
                    val list = if (!seasonal) List(12) { base }
                    else (0..11).map { monthly[it].toDoubleOrNull() ?: base }
                    val lodgingOk = seasonal || (newLodging.toDoubleOrNull() ?: 0.0) > 0.0
                    if (newName.isNotBlank() && (newMie.toDoubleOrNull() ?: 0.0) > 0.0 && lodgingOk) {
                        val l = Locality(
                            Localities.newId(), newName.trim(),
                            newMie.toDoubleOrNull() ?: 68.0, list,
                            Rates.current(ctx).fiscalYear, Store.today()
                        )
                        Localities.upsert(ctx, l)
                        onPick(l); onChanged()
                        adding = false
                        newName = ""; newMie = ""; newLodging = ""
                        seasonal = false; monthly = List(12) { "" }
                    }
                }
                GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { adding = false }
            }
            if ((newLodging.toDoubleOrNull() ?: 0.0) <= 0.0 && !seasonal) {
                Spacer(Modifier.height(8.dp))
                Text("Lodging is needed as well as M&IE — TQSE runs off both, and a " +
                        "destination saved without it computes lodging as zero.",
                    fontSize = 12.sp, color = T.Danger)
            }
            Spacer(Modifier.height(8.dp))
            Hint("Saved against FY${Rates.current(ctx).fiscalYear}. When the fiscal year " +
                    "turns over the card will still show the year it was entered, so a stale " +
                    "figure is visible rather than silent.")
        }
    }
}

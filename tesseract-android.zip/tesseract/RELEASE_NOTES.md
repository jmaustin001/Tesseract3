1.31.3 — Needs review only lists days that still need you.

A day was flagged when it was worked but no GPS fix landed between 07:00 and
15:00, even if it was a single-state day or you had already set it by hand.
That check only matters on a travel day, where the duty-hours fix decides which
state earned the pay. Now a day is flagged only for one of three reasons, and
the reason is shown under the category in the log:

- no category
- a fix couldn't be matched to a state (set where you were)
- a travel day with no fix in duty hours (set which state earned it, or mark it
  Worked / Day off)

Anything you set by hand on the day clears the matching reason. The same rule
drives the year-view warning and the "How solid" count on the allocation screen.

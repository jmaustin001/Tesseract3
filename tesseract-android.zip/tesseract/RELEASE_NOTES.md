Lodging tax has its own box, and it is paid outside the ceiling.

The stay now takes a room rate and a nightly tax separately. Under the 2024
rule that redefined TQSE, lodging tax is a separately reimbursable
miscellaneous expense rather than part of the lodging cost — so the room rate
is what counts against the cap and the tax is reimbursed on top of it.

Folding the two together would have been quietly expensive. A $180 room with
$24 tax entered as $204 uses up ceiling you never spent on the room; entered
correctly it is $5,400 of lodging plus $720 of tax, both reimbursed, and the
cap untouched by the tax.

The same rule went the other way on laundry and dry cleaning, which are inside
the daily M&IE allowance and not claimed separately. Noted on the screen.

The tax is still relocation money, so it is wages like the rest and carried
into the WTA and RITA figures.

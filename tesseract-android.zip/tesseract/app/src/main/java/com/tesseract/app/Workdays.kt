package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Residency and income are two different questions.
 *
 * The 183-day test counts days you were PRESENT. A nonresident income
 * allocation counts days you WORKED and where. A Saturday in Virginia counts
 * toward residency and earns nothing; a Tuesday TDY in Texas earns Texas-side
 * wages while adding nothing to the Virginia presence count.
 */
object Workdays {

    /** US federal holidays, with the Saturday/Sunday observed shift applied. */
    fun federalHolidays(year: Int): Set<String> {
        val out = HashSet<String>()
        fun add(c: Calendar) { out.add(key(c)) }

        // fixed dates, observed on the nearest weekday
        listOf(1 to 1, 6 to 19, 7 to 4, 11 to 11, 12 to 25).forEach { (m, d) ->
            val c = cal(year, m, d)
            when (c.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SATURDAY -> c.add(Calendar.DAY_OF_YEAR, -1)
                Calendar.SUNDAY -> c.add(Calendar.DAY_OF_YEAR, 1)
            }
            add(c)
        }
        add(nth(year, 1, Calendar.MONDAY, 3))    // MLK
        add(nth(year, 2, Calendar.MONDAY, 3))    // Presidents
        add(last(year, 5, Calendar.MONDAY))      // Memorial
        add(nth(year, 9, Calendar.MONDAY, 1))    // Labor
        add(nth(year, 10, Calendar.MONDAY, 2))   // Columbus
        add(nth(year, 11, Calendar.THURSDAY, 4)) // Thanksgiving
        return out
    }

    fun isHoliday(date: String): Boolean {
        val y = date.take(4).toIntOrNull() ?: return false
        return date in federalHolidays(y)
    }

    fun isWeekend(date: String): Boolean {
        val c = parse(date) ?: return false
        val d = c.get(Calendar.DAY_OF_WEEK)
        return d == Calendar.SATURDAY || d == Calendar.SUNDAY
    }

    /**
     * Did this day earn money? Any manual override wins outright — that is what
     * makes a Maxiflex or gliding schedule workable, where a Wednesday off is
     * normal and no rule could predict it.
     */
    fun earned(ctx: Context, d: DaySummary): Boolean {
        when (Store.workOverride(ctx, d.date)) {
            Store.WORKED -> return true
            Store.OFF -> return false
        }
        if (isWeekend(d.date)) return false
        if (isHoliday(d.date)) return false
        if (Status.dutyStatus(d.status) == "Leave") return false
        return true
    }

    /** Why the app decided what it decided, in plain words. */
    fun reason(ctx: Context, d: DaySummary): String = when {
        Store.workOverride(ctx, d.date) == Store.WORKED -> "marked as worked"
        Store.workOverride(ctx, d.date) == Store.OFF -> "marked as a day off"
        isWeekend(d.date) -> "weekend"
        isHoliday(d.date) -> "federal holiday"
        Status.dutyStatus(d.status) == "Leave" -> "on leave"
        else -> "regular workday"
    }

    /** Flags a day whose income state was guessed from fixes outside duty hours. */
    fun incomeIsSolid(d: DaySummary) = d.fixDuringDuty

    private fun cal(y: Int, m: Int, d: Int): Calendar =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d) }

    private fun nth(y: Int, month: Int, dow: Int, n: Int): Calendar =
        cal(y, month, 1).apply {
            var count = 0
            while (true) {
                if (get(Calendar.DAY_OF_WEEK) == dow) { count++; if (count == n) break }
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

    private fun last(y: Int, month: Int, dow: Int): Calendar =
        cal(y, month, 1).apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            while (get(Calendar.DAY_OF_WEEK) != dow) add(Calendar.DAY_OF_YEAR, -1)
        }

    private fun key(c: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)

    private fun parse(date: String): Calendar? = try {
        Calendar.getInstance().apply {
            time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
        }
    } catch (e: Exception) { null }
}

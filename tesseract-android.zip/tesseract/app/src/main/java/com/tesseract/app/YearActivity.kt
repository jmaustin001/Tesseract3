package com.tesseract.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val Ink = T.Hi
private val Paper = T.Void
private val CardBg = T.Deep
private val Gold = T.Gold
private val Teal = T.Teal
private val Gray = T.Low
private val Empty = Color(0xFF16243A)
private val Muted = T.Mid

// One color per category, for the "by category" view.
// Six hues spaced around the wheel. Neighbouring categories are the ones most
// easily confused, so no two sit near each other: amber, teal, lime, blue,
// violet, magenta.
private val CustomColor = Color(0xFFFF4FA3)   // hot magenta - nothing else is close
private val PpMark = Color(0xFF5AB0FF)        // pay period start
private val CatColors = mapOf(
    Status.DUTY        to Color(0xFFE0A93B),  // amber
    Status.LEAVE_RES   to Color(0xFF2FBF9B),  // teal
    Status.TDY_RES     to Color(0xFF9EDB3C),  // lime
    Status.TDY_OTHER   to Color(0xFF4DA3FF),  // blue
    Status.LEAVE_OTHER to Color(0xFFA07BE0)   // violet
)
private val Uncategorized = Color(0xFF3A4C63)

private val MONTHS = listOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")

/** The whole year as one picture: twelve rows, one square per day. */
class YearActivity : ComponentActivity() {
    var resumeTick by androidx.compose.runtime.mutableIntStateOf(0)

    override fun onResume() { super.onResume(); resumeTick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { YearScreen() } }
    }
}

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
private fun YearScreen() {
    val ctx = LocalContext.current
    var year by remember { mutableIntStateOf(Store.year()) }
    var tick by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<String?>(null) }
    // 0 = by state and income, 1 = by category
    var mode by remember { mutableIntStateOf(0) }
    val byCategory = mode == 1

    // pinch state for the grid
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }

    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)
    val resumed = (ctx as? YearActivity)?.resumeTick ?: 0
    val byDate = remember(tick, year, resumed) { Store.days(ctx, year).associateBy { it.date } }
    val today = Store.today()

    val countedN = byDate.values.count { counted in it.states }
    val homeN = byDate.values.count { home in it.states && counted !in it.states }
    val otherN = byDate.size - countedN - homeN
    val limit = Store.limit(ctx)

    Column(
        Modifier.fillMaxSize().background(Paper).verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("The year so far", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                Text("$year · $countedN days in $counted of $limit", fontSize = 13.sp, color = Muted)
            }
            TextButton(onClick = { year-- }) { Text("‹", fontSize = 22.sp) }
            TextButton(onClick = { year++ }) { Text("›", fontSize = 22.sp) }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 },
                label = { Text("State and \$", fontSize = 12.sp) }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == 1, onClick = { mode = 1 },
                label = { Text("Category", fontSize = 12.sp) }, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))
        Surface(color = CardBg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clipToBounds()
                        // Each square is clickable, and a child that handles pointer
                        // input eats the pinch before the container ever sees it. So
                        // this watches the Initial pass and only claims the gesture
                        // once two fingers are down — taps still reach the squares.
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false,
                                    pass = PointerEventPass.Initial)
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    if (event.changes.size >= 2) {
                                        zoom = (zoom * event.calculateZoom()).coerceIn(1f, 5f)
                                        if (zoom > 1f) {
                                            val pan = event.calculatePan()
                                            panX += pan.x
                                            panY += pan.y
                                        } else { panX = 0f; panY = 0f }
                                        event.changes.forEach { it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                ) {
                  Column(
                    Modifier.graphicsLayer {
                        scaleX = zoom; scaleY = zoom
                        translationX = panX; translationY = panY
                        transformOrigin = TransformOrigin(0.5f, 0.5f)
                    }
                  ) {
                (0..11).forEach { m ->
                    val dim = Calendar.getInstance().apply {
                        set(Calendar.YEAR, year); set(Calendar.MONTH, m)
                    }.getActualMaximum(Calendar.DAY_OF_MONTH)

                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(MONTHS[m], fontSize = 10.sp, color = Muted,
                            modifier = Modifier.width(26.dp))
                        Row(
                            Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            (1..31).forEach { d ->
                                if (d > dim) {
                                    Box(Modifier.weight(1f).aspectRatio(1f))
                                } else {
                                    val key = "%04d-%02d-%02d".format(year, m + 1, d)
                                    val e = byDate[key]
                                    val earns = e != null && Workdays.earned(ctx, e)
                                    val c = when {
                                        e == null -> Empty
                                        byCategory -> CatColors[e.status]
                                            ?: if (Status.isCustom(e.status)) CustomColor
                                               else Uncategorized
                                        counted in e.states -> Gold
                                        home in e.states -> Teal
                                        else -> Gray
                                    }
                                    // A travel day touches two states, and the count credits
                                    // both, because presence for any part of a day counts.
                                    // So the square is halved rather than picking a winner.
                                    val second: Color? = when {
                                        e == null || byCategory -> null
                                        !Store.isSplit(e) -> null
                                        counted in e.states && home in e.states -> Teal
                                        counted in e.states || home in e.states -> Gray
                                        else -> null
                                    }
                                    Box(
                                        Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            // background WITHOUT clip: a clip here trims
                                            // the $ glyph away, because the text is taller
                                            // than a ten-pixel square
                                            .background(c, RoundedCornerShape(2.dp))
                                            .then(
                                                if (key == today)
                                                    // thin enough not to eat the glyph
                                                    Modifier.border(0.8.dp, Ink, RoundedCornerShape(2.dp))
                                                else Modifier
                                            )
                                            .clickable { picked = key },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        // pay period start: a bar down the left edge,
                                        // clear of the $ and of the travel split
                                        if (PayPeriods.isStart(ctx, key)) {
                                            Box(Modifier.align(Alignment.CenterStart)
                                                .fillMaxHeight().width(2.dp)
                                                .background(PpMark))
                                        }

                                        // the split goes down first so the $ sits on top
                                        // of it rather than under
                                        if (second != null) Canvas(Modifier.matchParentSize()) {
                                            drawPath(
                                                Path().apply {
                                                    moveTo(size.width, 0f)
                                                    lineTo(size.width, size.height)
                                                    lineTo(0f, size.height)
                                                    close()
                                                },
                                                second
                                            )
                                        }
                                        if (earns) Text(
                                            "$",
                                            // font padding and the default line box
                                            // both sit the glyph low in a square this
                                            // small, so both are switched off
                                            style = TextStyle(
                                                fontSize = 8.sp,
                                                lineHeight = 8.sp,
                                                fontWeight = FontWeight.Black,
                                                color = Color(0xFF06121F),
                                                textAlign = TextAlign.Center,
                                                platformStyle = PlatformTextStyle(
                                                    includeFontPadding = false
                                                ),
                                                lineHeightStyle = LineHeightStyle(
                                                    alignment = LineHeightStyle.Alignment.Center,
                                                    trim = LineHeightStyle.Trim.Both
                                                )
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                  }
                }
                if (zoom > 1f) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${"%.1f".format(zoom)}x · two fingers to pan",
                            fontSize = 11.sp, color = Muted, modifier = Modifier.weight(1f))
                        TextButton(onClick = { zoom = 1f; panX = 0f; panY = 0f }) {
                            Text("Reset", fontSize = 12.sp, color = T.Cyan)
                        }
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text("Pinch with two fingers to zoom in", fontSize = 10.sp, color = Muted)
                }

                Spacer(Modifier.height(12.dp))
                if (byCategory) CategoryLegend() else FlowLegend(counted, home)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (byCategory)
                        "Color shows what you were doing. Tap any square to see or change it."
                    else
                        "Color shows which state the day counted in — the thing the limit " +
                                "turns on. Tap any square to see or change it.",
                    fontSize = 11.sp, color = Muted
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tally(counted, countedN, Gold, Modifier.weight(1f))
            Tally(home, homeN, Teal, Modifier.weight(1f))
            Tally("Elsewhere", otherN, Gray, Modifier.weight(1f))
            Tally("Travel", byDate.values.count { Store.isSplit(it) }, T.Ice, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tally("$counted earned", byDate.values.count {
                Workdays.earned(ctx, it) && Store.incomeStateOf(ctx, it) == counted }, Gold, Modifier.weight(1f))
            Tally("$home earned", byDate.values.count {
                Workdays.earned(ctx, it) && Store.incomeStateOf(ctx, it) == home }, Teal, Modifier.weight(1f))
            Tally("Elsewhere earned", byDate.values.count {
                Workdays.earned(ctx, it) && Store.incomeStateOf(ctx, it) != counted &&
                    Store.incomeStateOf(ctx, it) != home },
                T.Violet, Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))
        ReconstructCard { tick++ }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { (ctx as? ComponentActivity)?.finish() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Back to dashboard") }
        Spacer(Modifier.height(36.dp))
    }

    picked?.let { date ->
        DayDialog(ctx, date, byDate[date], onDismiss = { picked = null; tick++ })
    }
}

@Composable
private fun DayDialog(ctx: Context, date: String, day: DaySummary?, onDismiss: () -> Unit) {
    AlertDialog(
        containerColor = T.Deep,
        titleContentColor = T.Hi,
        textContentColor = T.Mid,
        onDismissRequest = onDismiss,
        title = { Text(date, fontSize = 18.sp) },
        text = {
            Column {
                if (day == null) {
                    Text("No entry on this day. Fill it from a datum — it will be flagged " +
                            "as entered by hand.", fontSize = 13.sp, color = Muted)
                } else {
                    Text("${day.states.joinToString(", ")} · ${day.status.ifBlank { "no category" }}",
                        fontSize = 15.sp, color = Ink)
                    if (day.note.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(day.note, fontSize = 12.sp, color = Muted)
                    }
                    Spacer(Modifier.height(4.dp))
                    if (day.reconstructed) {
                        Text("Reconstructed from your schedule — no GPS fix behind this day",
                            fontSize = 12.sp, color = T.Violet)
                    } else {
                        Text("${day.sampleCount} fixes on record", fontSize = 12.sp, color = Muted)
                    }
                    PayPeriods.startOf(ctx, day.date)?.let { st ->
                        Spacer(Modifier.height(4.dp))
                        Text(PayPeriods.label(ctx, st) +
                                (if (PayPeriods.isStart(ctx, day.date)) " — first day" else ""),
                            fontSize = 12.sp, color = PpMark)
                    }
                    if (Store.hasUnresolved(day)) {
                        Spacer(Modifier.height(6.dp))
                        Text("One or more fixes could not be resolved to a state — usually " +
                                "no network at the time. The coordinates are still recorded. " +
                                "Settings has a button to resolve them once you are back on wifi.",
                            fontSize = 11.sp, color = Gold)
                    }

                    Spacer(Modifier.height(12.dp))
                    val earned = Workdays.earned(ctx, day)
                    Text(
                        if (earned) "Earned in ${Store.incomeStateOf(ctx, day).ifBlank { "?" }} — ${Workdays.reason(ctx, day)}"
                        else "No income — ${Workdays.reason(ctx, day)}",
                        fontSize = 13.sp, color = if (earned) Gold else Muted
                    )
                    if (Store.weakIncome(ctx, day)) {
                        Spacer(Modifier.height(4.dp))
                        Text("A travel day with no fix during duty hours, so the earning " +
                                "state is a guess from the rest of the day. Set it if that is wrong.",
                            fontSize = 11.sp, color = T.Gold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val cur = Store.workOverride(ctx, day.date)
                        listOf(null to "Auto", Store.WORKED to "Worked", Store.OFF to "Day off")
                            .forEach { (v, label) ->
                                val on = cur == v
                                TextButton(onClick = {
                                    Store.setWorkOverride(ctx, day.date, v); onDismiss()
                                }) {
                                    Text(label, fontSize = 12.sp,
                                        color = if (on) Gold else Muted,
                                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                    }
                    if (Store.isSplit(day)) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Travel day. Fixes landed in ${day.states.joinToString(" and ")}, " +
                                    "so this day counts as a present day in every one of them — " +
                                    "that is how physical-presence tests work, and it is the " +
                                    "conservative reading.",
                            fontSize = 12.sp, color = T.Ice
                        )
                    }
                }

                if (day == null) {
                    Spacer(Modifier.height(12.dp))
                    Store.datums(ctx).forEach { z ->
                        OutlinedButton(
                            onClick = {
                                val st = when (z.role) {
                                    Datum.RESIDENCE -> Store.homeState(ctx)
                                    else -> Store.countedState(ctx)
                                }
                                Store.addManualDay(ctx, date, st, z)
                                Store.setStatus(ctx, date, Status.guessFor(z.role))
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        ) { Text(z.name, fontSize = 13.sp) }
                    }
                }
            }
        },
        confirmButton = {
            if (day != null) TextButton(onClick = {
                ctx.startActivity(
                    Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", date)
                        .putExtra("summary", day.states.joinToString(", "))
                        .putExtra("guess", day.status.ifBlank { Status.DUTY })
                )
                onDismiss()
            }) { Text("Change category") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun CategoryLegend() {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Key("Duty", CatColors[Status.DUTY]!!, Modifier.weight(1f))
            Key("Leave Res", CatColors[Status.LEAVE_RES]!!, Modifier.weight(1f))
            Key("TDY Res", CatColors[Status.TDY_RES]!!, Modifier.weight(1f))
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth()) {
            Key("TDY Other", CatColors[Status.TDY_OTHER]!!, Modifier.weight(1f))
            Key("Leave Other", CatColors[Status.LEAVE_OTHER]!!, Modifier.weight(1f))
            Key("Custom", CustomColor, Modifier.weight(1f))
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Key("No category", Uncategorized, Modifier.weight(1f))
            Key("No entry", Empty, Modifier.weight(1f))
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(11.dp).clip(RoundedCornerShape(2.dp)).background(Gold),
                    contentAlignment = Alignment.Center) {
                    Text("$", fontSize = 7.sp, color = Color(0xFF06121F),
                        fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(6.dp))
                Text("earned", fontSize = 11.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun FlowLegend(counted: String, home: String) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Key(counted, Gold); Key(home, Teal); Key("Elsewhere", Gray); Key("No entry", Empty)
        }
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SplitKey(Gold, Teal)
            Spacer(Modifier.width(6.dp))
            Text("Travel day — in both states, counted in both",
                fontSize = 11.sp, color = Muted)
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(11.dp).clip(RoundedCornerShape(2.dp)).background(Gold),
                contentAlignment = Alignment.Center) {
                Text("$", fontSize = 7.sp, color = Color(0xFF06121F), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(6.dp))
            Text("\$ marks a day that earned wages", fontSize = 11.sp, color = Muted)
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(11.dp).clip(RoundedCornerShape(2.dp)).background(Empty)) {
                Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().width(2.dp)
                    .background(PpMark))
            }
            Spacer(Modifier.width(6.dp))
            Text("Left edge marks the first day of a pay period", fontSize = 11.sp, color = Muted)
        }
    }
}

/** A miniature of the halved square, so the legend shows the thing itself. */
@Composable
private fun SplitKey(a: Color, b: Color) {
    Box(Modifier.size(11.dp).clip(RoundedCornerShape(2.dp)).background(a)) {
        Canvas(Modifier.matchParentSize()) {
            drawPath(
                Path().apply {
                    moveTo(size.width, 0f); lineTo(size.width, size.height)
                    lineTo(0f, size.height); close()
                }, b
            )
        }
    }
}

@Composable
private fun Key(label: String, c: Color, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(c, RoundedCornerShape(2.dp)))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable
private fun Tally(label: String, n: Int, c: Color, modifier: Modifier) {
    Surface(color = CardBg, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text("$n", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = c)
            Text(label, fontSize = 11.sp, color = Muted)
        }
    }
}

package com.tesseract.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Nudges you on payday, then sets the next one. */
object PayScheduler {

    fun schedule(ctx: Context) {
        if (!Pay.remindersOn(ctx)) return
        val due = Pay.nextDue(ctx) ?: return
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(due)!! } catch (e: Exception) { return }
            set(Calendar.HOUR_OF_DAY, 18)
            set(Calendar.MINUTE, 0)
        }
        if (cal.timeInMillis < System.currentTimeMillis())
            cal.add(Calendar.DAY_OF_YEAR, Pay.everyDays(ctx))

        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, intent(ctx))
    }

    fun cancel(ctx: Context) =
        ctx.getSystemService(AlarmManager::class.java).cancel(intent(ctx))

    private fun intent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 300, Intent(ctx, PayReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class PayReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifier.payReminder(ctx)
        PayScheduler.schedule(ctx)
    }
}

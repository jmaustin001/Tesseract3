package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Turns the day log into the numbers a nonresident wage allocation needs.
 *
 * The method is the working-day ratio: wages earned in the state over wages
 * earned everywhere, measured in days worked. It is the usual approach, but it
 * is not the only one, and which one applies is a question for a CPA. Nothing
 * here fills in a tax form — it produces a worksheet showing every figure and
 * how it was reached, so someone qualified can check the reasoning rather than
 * trust a number.
 */
object Allocation {

    data class Result(
        val year: Int,
        val state: String,
        val stateWorkdays: Int,
        val totalWorkdays: Int,
        val ratio: Double,
        val gross: Double,
        val stateWages: Double,
        val dailyRate: Double,
        val hourlyRate: Double,
        // the parts that weaken the figure, surfaced rather than buried
        val gapDays: Int,
        val uncategorized: Int,
        val weakIncomeDays: Int,
        val manualOverrides: Int
    )

    fun compute(ctx: Context, year: Int): Result {
        val state = Store.countedState(ctx)
        val days = Store.days(ctx, year)

        val total = days.count { Workdays.earned(ctx, it) }
        val inState = days.count { Workdays.earned(ctx, it) && it.primaryState == state }
        val ratio = if (total > 0) inState.toDouble() / total else 0.0

        val gross = Store.grossWages(ctx)
        val daily = if (total > 0) gross / total else 0.0
        val hourly = if (Store.hoursPerDay(ctx) > 0) daily / Store.hoursPerDay(ctx) else 0.0

        return Result(
            year = year,
            state = state,
            stateWorkdays = inState,
            totalWorkdays = total,
            ratio = ratio,
            gross = gross,
            stateWages = gross * ratio,
            dailyRate = daily,
            hourlyRate = hourly,
            gapDays = Store.gapDays(ctx, year).size,
            uncategorized = days.count { it.status.isBlank() },
            weakIncomeDays = days.count { Workdays.earned(ctx, it) && !it.fixDuringDuty },
            manualOverrides = days.count { Store.workOverride(ctx, it.date) != null }
        )
    }

    private fun money(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

    /** A plain-text worksheet. Readable by a person, not a form to be filed. */
    fun worksheet(ctx: Context, r: Result): String = buildString {
        val name = States.fullName(r.state)
        appendLine("NONRESIDENT WAGE ALLOCATION WORKSHEET")
        appendLine("$name — tax year ${r.year}")
        appendLine("Prepared ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())} from a")
        appendLine("contemporaneous GPS day log. Not tax advice, and not a tax form.")
        appendLine()

        appendLine("METHOD")
        appendLine("  Working-day ratio. Wages are allocated to $name in the same")
        appendLine("  proportion as days worked there to days worked everywhere.")
        appendLine("  A day counts as worked unless it was a non-duty weekday, a")
        appendLine("  federal holiday, a scheduled regular day off, a day categorized")
        appendLine("  as leave, or a day marked off by hand. A worked day is assigned")
        appendLine("  to the state recorded during duty hours.")
        appendLine()

        appendLine("DAYS")
        appendLine("  Days worked in $name         ${r.stateWorkdays}")
        appendLine("  Days worked everywhere            ${r.totalWorkdays}")
        appendLine("  Ratio                             ${String.format(Locale.US, "%.6f", r.ratio)}")
        appendLine("                                    (${String.format(Locale.US, "%.2f", r.ratio * 100)}%)")
        appendLine()

        appendLine("WAGES")
        if (r.gross <= 0) {
            appendLine("  No gross wage figure has been entered, so no allocation")
            appendLine("  is shown. Enter the W-2 amount in the app to complete this.")
        } else {
            appendLine("  Gross wages for the year          ${money(r.gross)}")
            appendLine("  Allocated to $name           ${money(r.stateWages)}")
            appendLine("  Implied daily rate                ${money(r.dailyRate)}")
            appendLine("  Implied hourly rate               ${money(r.hourlyRate)}")
            appendLine("    (at ${Store.hoursPerDay(ctx)} hours per duty day)")
        }
        appendLine()

        appendLine("RESIDENCY, SEPARATELY")
        appendLine("  Days present in $name        ${Store.stateDays(ctx, r.state, r.year)}")
        appendLine("  of a ${Store.limit(ctx)}-day threshold")
        appendLine("  Presence and income are different tests. A weekend in $name")
        appendLine("  counts toward presence and earns nothing.")
        appendLine()

        appendLine("HOW SOLID THIS IS")
        appendLine("  Days with no location data        ${r.gapDays}")
        appendLine("  Days never categorized            ${r.uncategorized}")
        appendLine("  Worked days with no fix during")
        appendLine("    duty hours                      ${r.weakIncomeDays}")
        appendLine("  Days set by hand rather than rule ${r.manualOverrides}")
        if (r.gapDays > 0 || r.uncategorized > 0) {
            appendLine()
            appendLine("  Resolve the above before relying on these figures. Every")
            appendLine("  unexplained gap is a day an examiner can assign as they like.")
        }
        appendLine()
        appendLine("Underlying day-by-day and fix-by-fix records export separately")
        appendLine("from the same app and should accompany this worksheet.")
    }

    fun writeFile(ctx: Context, r: Result): java.io.File {
        val dir = java.io.File(ctx.filesDir, "reports").apply { mkdirs() }
        return java.io.File(dir, "allocation-${r.state.lowercase()}-${r.year}.txt")
            .apply { writeText(worksheet(ctx, r)) }
    }
}

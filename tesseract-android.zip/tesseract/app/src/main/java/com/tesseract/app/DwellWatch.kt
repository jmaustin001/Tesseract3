package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Notices when you have settled somewhere the app does not know about.
 *
 * Passing through a place is not worth a notification — airports, highways and
 * hotel stopovers would fire constantly. Staying put is different. A run of
 * off-station fixes clustered in one area and spanning at least twelve hours
 * means somewhere real, and probably somewhere worth a datum.
 */
object DwellWatch {

    data class Dwell(val lat: Double, val lon: Double, val hours: Int, val state: String)

    /** The settled place, or null when the recent fixes do not qualify. */
    fun detect(ctx: Context): Dwell? {
        val hoursNeeded = Store.dwellHours(ctx)
        if (hoursNeeded <= 0) return null
        val radius = Store.dwellRadius(ctx)

        val window = System.currentTimeMillis() - (hoursNeeded * 2L + 12L) * 3_600_000L
        val recent = Store.samples(ctx)
            .filter { it.timestamp >= window && !it.manual }
            .sortedBy { it.timestamp }
        if (recent.size < 2) return null

        // walk backwards from the newest fix while the fixes stay off-station
        // and stay near each other
        val newest = recent.last()
        if (newest.zoneId != Zones.OUT_ID) return null

        var first = newest
        for (s in recent.reversed()) {
            if (s.zoneId != Zones.OUT_ID) break
            if (Zones.milesBetween(s.lat, s.lon, newest.lat, newest.lon) > radius) break
            first = s
        }

        val spanHours = ((newest.timestamp - first.timestamp) / 3_600_000L).toInt()
        if (spanHours < hoursNeeded) return null

        // centre of the run, so a datum built from it sits in the middle
        val run = recent.filter { it.timestamp >= first.timestamp && it.zoneId == Zones.OUT_ID }
        val lat = run.map { it.lat }.average()
        val lon = run.map { it.lon }.average()

        if (isSuppressed(ctx, lat, lon, radius)) return null
        if (alreadyAsked(ctx, lat, lon, radius)) return null

        return Dwell(round5(lat), round5(lon), spanHours, newest.state)
    }

    // ---------- places you have told it to stop asking about ----------

    private fun list(ctx: Context, key: String): List<Pair<Double, Double>> {
        val a = JSONArray(Store.prefString(ctx, key, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it); o.getDouble("lat") to o.getDouble("lon")
        }
    }

    private fun add(ctx: Context, key: String, lat: Double, lon: Double) {
        val a = JSONArray(Store.prefString(ctx, key, "[]"))
        a.put(JSONObject().apply { put("lat", lat); put("lon", lon) })
        // keep it from growing without bound
        val trimmed = JSONArray()
        val start = maxOf(0, a.length() - 40)
        for (i in start until a.length()) trimmed.put(a.get(i))
        Store.setPrefString(ctx, key, trimmed.toString())
    }

    fun suppress(ctx: Context, lat: Double, lon: Double) = add(ctx, "dwellIgnored", lat, lon)
    fun markAsked(ctx: Context, lat: Double, lon: Double) = add(ctx, "dwellAsked", lat, lon)

    fun clearSuppressed(ctx: Context) {
        Store.setPrefString(ctx, "dwellIgnored", "[]")
        Store.setPrefString(ctx, "dwellAsked", "[]")
    }

    fun suppressedCount(ctx: Context) = list(ctx, "dwellIgnored").size

    private fun isSuppressed(ctx: Context, lat: Double, lon: Double, radius: Double) =
        list(ctx, "dwellIgnored").any { Zones.milesBetween(lat, lon, it.first, it.second) <= radius }

    private fun alreadyAsked(ctx: Context, lat: Double, lon: Double, radius: Double) =
        list(ctx, "dwellAsked").any { Zones.milesBetween(lat, lon, it.first, it.second) <= radius }

    private fun round5(v: Double) = String.format(java.util.Locale.US, "%.5f", v).toDouble()
}

package com.tesseract.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

/**
 * The day log answers one question. Domicile is argued on a different set of
 * facts entirely, and those live in filing cabinets rather than on a phone.
 * This is a place to record which ones are in hand.
 */
class DomicileActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { DomicileScreen() } }
    }
}

private data class Item(val id: String, val label: String, val why: String)

private val ITEMS = listOf(
    Item("homestead", "Homestead exemption on the home state property",
        "A formal declaration to a government that a property is your permanent residence. Among the strongest single facts available."),
    Item("voter", "Voter registration in the home state",
        "Where you vote is where you say you belong."),
    Item("license", "Driver's license in the home state", "Cheap to maintain, conspicuous if missing."),
    Item("vehicles", "Vehicles titled and registered in the home state", ""),
    Item("insurance", "Vehicle and home insurance at the home address", ""),
    Item("banking", "Banking and brokerage at the home address", ""),
    Item("medical", "Doctors, dentist and specialists in the home state",
        "Routine care follows where life actually is."),
    Item("legal", "Will, trust and estate documents executed in the home state",
        "These recite domicile explicitly."),
    Item("spouse", "Spouse living and working in the home state",
        "Hard to argue you left a state your family did not."),
    Item("school", "Children enrolled in home state schools",
        "Also protects in-state tuition later, which runs on its own rules."),
    Item("noLease", "No lease, deed or utilities in the work state",
        "Weakens the abode argument without defeating it. Regular access to a place can still count."),
    Item("noVoterWork", "Not registered to vote or licensed in the work state", ""),
    Item("mail", "Mail, statements and subscriptions at the home address", ""),
    Item("religious", "Church, gym, clubs and memberships at home", "Small facts, and they accumulate."),
    Item("returns", "Federal returns filed with the home address", "")
)

private const val KEY = "domicileChecklist"

@Composable
private fun DomicileScreen() {
    val ctx = LocalContext.current
    val resumed = (ctx as? DomicileActivity)?.resumeTick ?: 0
    var tick by remember { mutableIntStateOf(0) }

    val state = remember(tick, resumed) {
        JSONObject(Store.prefString(ctx, KEY, "{}"))
    }
    fun checked(id: String) = state.optBoolean(id, false)
    fun toggle(id: String) {
        state.put(id, !checked(id))
        Store.setPrefString(ctx, KEY, state.toString())
        tick++
    }

    val done = ITEMS.count { checked(it.id) }

    TessScreen("Domicile evidence", "$done of ${ITEMS.size} in hand") {

        TCard("why this is separate", T.Violet) {
            Hint("The day count defends against statutory residency — a pure arithmetic " +
                    "test. Domicile is argued on where your life actually is, and no GPS " +
                    "log settles it. These are the facts that do. None of them live on " +
                    "this phone, so this is only a record of what you have.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("checklist") {
            ITEMS.forEachIndexed { i, item ->
                Row(
                    Modifier.fillMaxWidth().clickable { toggle(item.id) }
                        .padding(vertical = 9.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    val on = checked(item.id)
                    Box(
                        Modifier.padding(top = 2.dp).size(18.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (on) T.Teal else T.Glow)
                            .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(5.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (on) Text("✓", fontSize = 11.sp, color = androidx.compose.ui.graphics.Color(0xFF051020),
                            fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.label, fontSize = 14.sp,
                            color = if (on) T.Hi else T.Mid,
                            fontWeight = if (on) FontWeight.Medium else FontWeight.Normal)
                        if (item.why.isNotBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(item.why, fontSize = 11.sp, color = T.Low, lineHeight = 14.sp)
                        }
                    }
                }
                if (i < ITEMS.lastIndex) HorizontalDivider(color = T.Edge.copy(alpha = .4f))
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("share it", T.Cyan) {
            PrimaryBtn("Share the checklist") {
                val sb = StringBuilder("DOMICILE EVIDENCE CHECKLIST\n")
                sb.appendLine("Home state: ${States.fullName(Store.homeState(ctx))}")
                sb.appendLine("Work state: ${States.fullName(Store.countedState(ctx))}")
                sb.appendLine("As of ${Store.today()} — $done of ${ITEMS.size} in hand")
                sb.appendLine()
                ITEMS.forEach {
                    sb.appendLine("[${if (checked(it.id)) "x" else " "}] ${it.label}")
                }
                sb.appendLine()
                sb.appendLine("A record of documents held, not the documents themselves.")
                val f = File(File(ctx.filesDir, "reports").apply { mkdirs() }, "domicile-checklist.txt")
                f.writeText(sb.toString())
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                ctx.startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Domicile evidence checklist")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share checklist"))
            }
        }
    }
}

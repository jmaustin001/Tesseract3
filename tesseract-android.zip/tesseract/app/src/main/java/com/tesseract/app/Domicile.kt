package com.tesseract.app

import android.content.Context
import org.json.JSONObject

/** The facts a GPS log cannot prove, and a record of which are in hand. */
object Domicile {

    data class Item(val id: String, val label: String, val why: String)

    const val KEY = "domicileChecklist"

    val ITEMS = listOf(
        Item("homestead", "Homestead exemption on the home state property",
            "A formal declaration to a government that a property is your permanent residence. Among the strongest single facts available."),
        Item("voter", "Voter registration in the home state",
            "Where you vote is where you say you belong."),
        Item("license", "Driver's license in the home state",
            "Cheap to maintain, conspicuous if missing."),
        Item("vehicles", "Vehicles titled and registered in the home state", ""),
        Item("insurance", "Vehicle and home insurance at the home address", ""),
        Item("banking", "Banking and brokerage at the home address", ""),
        Item("medical", "Doctors, dentist and specialists in the home state",
            "Routine care follows where life actually is."),
        Item("legal", "Will, trust and estate documents executed in the home state",
            "These recite domicile explicitly."),
        Item("spouse", "Spouse living and working in the home state",
            "Hard to argue you left a state your family did not."),
        Item("school", "Children enrolled in home state schools",
            "Also protects in-state tuition later, which runs on its own rules."),
        Item("noLease", "No lease, deed or utilities in the work state",
            "Weakens the abode argument without defeating it. Regular access to a place can still count."),
        Item("noVoterWork", "Not registered to vote or licensed in the work state", ""),
        Item("mail", "Mail, statements and subscriptions at the home address", ""),
        Item("religious", "Church, gym, clubs and memberships at home",
            "Small facts, and they accumulate."),
        Item("returns", "Federal returns filed with the home address", "")
    )

    fun state(ctx: Context): JSONObject = JSONObject(Store.prefString(ctx, KEY, "{}"))

    fun isChecked(ctx: Context, id: String) = state(ctx).optBoolean(id, false)

    fun toggle(ctx: Context, id: String) {
        val o = state(ctx)
        o.put(id, !o.optBoolean(id, false))
        Store.setPrefString(ctx, KEY, o.toString())
    }

    fun heldCount(ctx: Context) = ITEMS.count { isChecked(ctx, it.id) }

    fun text(ctx: Context): String = buildString {
        val o = state(ctx)
        appendLine("DOMICILE EVIDENCE CHECKLIST")
        appendLine("Home state: ${States.fullName(Store.homeState(ctx))}")
        appendLine("Work state: ${States.fullName(Store.countedState(ctx))}")
        appendLine("As of ${Store.today()} — ${heldCount(ctx)} of ${ITEMS.size} in hand")
        appendLine()
        ITEMS.forEach { appendLine("[${if (o.optBoolean(it.id, false)) "x" else " "}] ${it.label}") }
        appendLine()
        appendLine("A record of documents held, not the documents themselves.")
        appendLine("The day log defends against statutory residency, which is arithmetic.")
        appendLine("These defend domicile, which is argued on where life actually is.")
    }

    fun writeFile(ctx: Context): java.io.File {
        val dir = java.io.File(ctx.filesDir, "reports").apply { mkdirs() }
        return java.io.File(dir, "domicile-checklist.txt").apply { writeText(text(ctx)) }
    }
}

package com.tesseract.app

import android.content.Context
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A datum is a fixed reference point with a radius. Everything the app records is an
 * offset from one. Any number of them, each named and moveable, so a PCS is an edit
 * rather than a rebuild.
 */
data class Datum(
    val id: String,
    val name: String,
    val lat: Double,
    val lon: Double,
    val radiusMiles: Double,
    val role: String
) {
    companion object {
        const val RESIDENCE = "residence"
        const val DUTY = "duty"
        const val OTHER = "other"

        val roles = listOf(RESIDENCE, DUTY, OTHER)

        fun roleLabel(role: String) = when (role) {
            RESIDENCE -> "Residence"
            DUTY -> "Duty station"
            else -> "Other tracked place"
        }
    }
}

object Zones {
    const val OUT_ID = "out"
    const val OUT_NAME = "Off station"

    /** Nearest datum containing the point, or null when the fix is outside them all. */
    fun classify(ctx: Context, lat: Double, lon: Double): Datum? =
        Store.datums(ctx)
            .map { it to milesFrom(it, lat, lon) }
            .filter { it.second <= it.first.radiusMiles }
            .minByOrNull { it.second }
            ?.first

    fun firstWithRole(ctx: Context, role: String) =
        Store.datums(ctx).firstOrNull { it.role == role }

    fun milesFrom(d: Datum, lat: Double, lon: Double) = milesBetween(lat, lon, d.lat, d.lon)

    fun milesBetween(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 3958.7614
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
}

/** State list for the counted-state and home-state pickers. */
object States {
    private val names = mapOf(
        "AL" to "Alabama", "AK" to "Alaska", "AZ" to "Arizona", "AR" to "Arkansas",
        "CA" to "California", "CO" to "Colorado", "CT" to "Connecticut", "DE" to "Delaware",
        "DC" to "District of Columbia", "FL" to "Florida", "GA" to "Georgia", "HI" to "Hawaii",
        "ID" to "Idaho", "IL" to "Illinois", "IN" to "Indiana", "IA" to "Iowa",
        "KS" to "Kansas", "KY" to "Kentucky", "LA" to "Louisiana", "ME" to "Maine",
        "MD" to "Maryland", "MA" to "Massachusetts", "MI" to "Michigan", "MN" to "Minnesota",
        "MS" to "Mississippi", "MO" to "Missouri", "MT" to "Montana", "NE" to "Nebraska",
        "NV" to "Nevada", "NH" to "New Hampshire", "NJ" to "New Jersey", "NM" to "New Mexico",
        "NY" to "New York", "NC" to "North Carolina", "ND" to "North Dakota", "OH" to "Ohio",
        "OK" to "Oklahoma", "OR" to "Oregon", "PA" to "Pennsylvania", "RI" to "Rhode Island",
        "SC" to "South Carolina", "SD" to "South Dakota", "TN" to "Tennessee", "TX" to "Texas",
        "UT" to "Utah", "VT" to "Vermont", "VA" to "Virginia", "WA" to "Washington",
        "WV" to "West Virginia", "WI" to "Wisconsin", "WY" to "Wyoming",
        "PR" to "Puerto Rico", "GU" to "Guam", "VI" to "U.S. Virgin Islands"
    )

    val all = names.keys.sorted()

    fun fullName(abbr: String) = names[abbr] ?: abbr

    /**
     * Turns a geocoded address into a code the log can count on.
     *
     * US addresses become the two-letter state. Everywhere else becomes the
     * three-letter ISO country code - DEU, JPN, KOR - which can never collide
     * with a US state. This matters: taking the first two letters of a foreign
     * region name would read "Valencia" as VA and invent Virginia days.
     */
    fun forAddress(adminArea: String?, countryCode: String?): String {
        val cc = countryCode?.uppercase()
        if (cc != null && cc != "US") {
            return try {
                java.util.Locale("", cc).isO3Country.ifBlank { cc }
            } catch (e: Exception) { cc }
        }
        return abbreviate(adminArea ?: "?")
    }

    fun isForeign(code: String) = code.length == 3

    /** Reverse geocoding returns full names; the log stores abbreviations. */
    fun abbreviate(full: String): String {
        if (full == "?") return "?"
        if (full.length == 2 && names.containsKey(full.uppercase())) return full.uppercase()
        names.entries.firstOrNull { it.value.equals(full, ignoreCase = true) }?.let { return it.key }
        if (full.contains("Columbia", true) || full.contains("D.C.", true)) return "DC"
        return full.take(2).uppercase()
    }
}

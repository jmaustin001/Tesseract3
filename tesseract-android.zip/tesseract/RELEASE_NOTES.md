Build fix: the saved-categories block used Alignment without the file importing
it. Compile error, nothing more.

Everything from 1.21.0 is here — categories you name are kept and reappear on
the categorize screen, Settings can add and remove them, and the lodging tax
line finally shows in the TQSE summary rather than only being counted in the
total.

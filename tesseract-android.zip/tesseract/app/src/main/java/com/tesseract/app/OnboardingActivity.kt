package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.util.Locale

/**
 * First run, and again after a reset. Walks through the two datums that matter, the
 * states being counted, and the warning stages — then hands over to the dashboard.
 */
class OnboardingActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { Wizard() } }
    }

    fun askPermissions() {
        val want = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
    }

    fun askBackground() {
        if (Build.VERSION.SDK_INT >= 29)
            perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }

    fun finishSetup() {
        Store.setOnboarded(this, true)
        Scheduler.scheduleNextCheck(this)
        Scheduler.scheduleMonthlyReport(this)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}

private val Ink = T.Cyan
private val Paper = T.Void
private val Muted = T.Mid
private val Teal = T.Teal

@Composable
private fun Wizard() {
    val act = androidx.compose.ui.platform.LocalContext.current as OnboardingActivity
    var step by remember { mutableIntStateOf(0) }

    // residence
    var resName by remember { mutableStateOf("") }
    var resLat by remember { mutableStateOf("") }
    var resLon by remember { mutableStateOf("") }
    var resRad by remember { mutableStateOf("50") }

    // duty
    var dutyName by remember { mutableStateOf("") }
    var dutyLat by remember { mutableStateOf("") }
    var dutyLon by remember { mutableStateOf("") }
    var dutyRad by remember { mutableStateOf("20") }

    var counted by remember { mutableStateOf("VA") }
    var home by remember { mutableStateOf("FL") }
    var s1 by remember { mutableStateOf("125") }
    var s2 by remember { mutableStateOf("150") }
    var hard by remember { mutableStateOf("175") }
    var limit by remember { mutableStateOf("183") }

    Column(
        Modifier.fillMaxSize().background(Paper).verticalScroll(rememberScrollState()).padding(22.dp)
    ) {
        Spacer(Modifier.height(36.dp))
        Text("Step ${step + 1} of 5", fontSize = 12.sp, color = Muted)
        Spacer(Modifier.height(6.dp))

        when (step) {
            0 -> {
                Head("Tesseract")
                Body(
                    "Four position checks a day, each one measured against reference points " +
                            "you define. Days in the state you are watching get counted; days " +
                            "outside your datums get a prompt asking what they were.\n\n" +
                            "Setup takes about two minutes. Nothing leaves the phone unless you " +
                            "email a report yourself."
                )
                Spacer(Modifier.height(20.dp))
                Primary("Allow location and notifications") { act.askPermissions() }
                Spacer(Modifier.height(8.dp))
                Body(
                    "Pick \"While using the app\" for now if you like — the next screens need " +
                            "it to read your position. Always-on comes at the end."
                )
            }

            1 -> {
                Head("Your residence")
                Body(
                    "The place you are trying to prove you kept. Days here are your domicile " +
                            "evidence, so the circle should cover the area you actually live in — " +
                            "not just the driveway."
                )
                Spacer(Modifier.height(16.dp))
                Field("Name it", resName, { resName = it }, "Oviedo residence")
                CoordRow(resLat, resLon, { resLat = it }, { resLon = it }) {
                    act.here { la, lo ->
                        resLat = fmt(la); resLon = fmt(lo)
                    }
                }
                Radius(resRad) { resRad = it }
                Body("50 miles is a sensible default for a home area. Stand at the address and tap Use my position for an exact center.")
            }

            2 -> {
                Head("Your duty station")
                Body(
                    "Where the job puts you. This is the one the day limit is really about."
                )
                Spacer(Modifier.height(16.dp))
                Field("Name it", dutyName, { dutyName = it }, "Crystal City")
                CoordRow(dutyLat, dutyLon, { dutyLat = it }, { dutyLon = it }) {
                    act.here { la, lo -> dutyLat = fmt(la); dutyLon = fmt(lo) }
                }
                Radius(dutyRad) { dutyRad = it }
                Body(
                    "Keep this one tight. A wide circle around a duty station near a state line " +
                            "will label days that belong to a neighboring state — the count itself " +
                            "always uses the real state of each fix, but the labels get muddy."
                )
            }

            3 -> {
                Head("Which state is on the clock")
                Body("Change these when you PCS and the counter follows.")
                Spacer(Modifier.height(16.dp))
                StatePicker("State you are counting days in", counted) { counted = it }
                Spacer(Modifier.height(12.dp))
                StatePicker("State you claim as home", home) { home = it }
                Spacer(Modifier.height(16.dp))
                Body(
                    "Both get tallied. Proving you kept ${States.fullName(home)} is a different " +
                            "job from proving you stayed under the limit in ${States.fullName(counted)}, " +
                            "and an auditor may ask about either."
                )
            }

            4 -> {
                Head("Warning stages")
                Body("Two soft checkpoints, one hard warning, and the statutory line.")
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Num("Soft 1", s1, Modifier.weight(1f)) { s1 = it }
                    Num("Soft 2", s2, Modifier.weight(1f)) { s2 = it }
                    Num("Hard", hard, Modifier.weight(1f)) { hard = it }
                    Num("Limit", limit, Modifier.weight(1f)) { limit = it }
                }
                Spacer(Modifier.height(16.dp))
                Primary("Allow location all the time") { act.askBackground() }
                Spacer(Modifier.height(8.dp))
                Body(
                    "Without always-on permission the checks only run while the app is open, " +
                            "which defeats the point. Pick \"Allow all the time\" on the system screen."
                )
            }
        }

        Spacer(Modifier.height(26.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (step > 0) OutlinedButton(onClick = { step-- }, modifier = Modifier.weight(1f)) {
                Text("Back")
            }
            Button(
                onClick = {
                    if (step < 4) { step++; return@Button }
                    val ctx = act
                    val ds = mutableListOf<Datum>()
                    resLat.toDoubleOrNull()?.let { la ->
                        resLon.toDoubleOrNull()?.let { lo ->
                            ds += Datum(Store.newDatumId(), resName.ifBlank { "Residence" },
                                la, lo, resRad.toDoubleOrNull() ?: 50.0, Datum.RESIDENCE)
                        }
                    }
                    dutyLat.toDoubleOrNull()?.let { la ->
                        dutyLon.toDoubleOrNull()?.let { lo ->
                            ds += Datum(Store.newDatumId() + "b", dutyName.ifBlank { "Duty station" },
                                la, lo, dutyRad.toDoubleOrNull() ?: 20.0, Datum.DUTY)
                        }
                    }
                    if (ds.isNotEmpty()) Store.saveDatums(ctx, ds)
                    Store.setCountedState(ctx, counted)
                    Store.setHomeState(ctx, home)
                    s1.toIntOrNull()?.let { Store.setSoft1(ctx, it) }
                    s2.toIntOrNull()?.let { Store.setSoft2(ctx, it) }
                    hard.toIntOrNull()?.let { Store.setHard(ctx, it) }
                    limit.toIntOrNull()?.let { Store.setLimit(ctx, it) }
                    act.finishSetup()
                },
                colors = ButtonDefaults.buttonColors(containerColor = T.Cyan, contentColor = Color(0xFF051020)),
                modifier = Modifier.weight(2f)
            ) { Text(if (step < 4) "Next" else "Start logging") }
        }

        if (step in 1..2) {
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = { step++ }, modifier = Modifier.fillMaxWidth()) {
                Text("Skip — add this later", fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

private fun fmt(v: Double) = String.format(Locale.US, "%.5f", v)

@Composable private fun Head(t: String) =
    Text(t, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = T.Hi)

@Composable private fun Body(t: String) {
    Spacer(Modifier.height(8.dp))
    Text(t, fontSize = 14.sp, color = Muted, lineHeight = 20.sp)
}

@Composable private fun Primary(t: String, onClick: () -> Unit) =
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = T.Cyan, contentColor = Color(0xFF051020)),
        modifier = Modifier.fillMaxWidth()) { Text(t) }

@Composable
private fun Field(label: String, v: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = v, onValueChange = onChange,
        label = { Text(label) }, placeholder = { Text(hint) },
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun CoordRow(
    lat: String, lon: String,
    onLat: (String) -> Unit, onLon: (String) -> Unit, onHere: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(lat, onLat, label = { Text("Latitude") }, singleLine = true,
            modifier = Modifier.weight(1f))
        OutlinedTextField(lon, onLon, label = { Text("Longitude") }, singleLine = true,
            modifier = Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    OutlinedButton(onClick = onHere, modifier = Modifier.fillMaxWidth()) {
        Text("Use my position")
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun Radius(v: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = v, onValueChange = { onChange(it.filter { c -> c.isDigit() }) },
        label = { Text("Radius (miles)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun Num(label: String, v: String, modifier: Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = v, onValueChange = { onChange(it.filter { c -> c.isDigit() }) },
        label = { Text(label, fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true, modifier = modifier
    )
}

@Composable
fun StatePicker(label: String, selected: String, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(label, fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(6.dp))
        Surface(
            color = T.Deep, shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth(), onClick = { open = true }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${States.fullName(selected)} ($selected)",
                    fontSize = 16.sp, color = T.Hi, modifier = Modifier.weight(1f))
                Text("Change", fontSize = 13.sp, color = Teal)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            States.all.forEach { s ->
                DropdownMenuItem(
                    text = { Text("${States.fullName(s)} ($s)") },
                    onClick = { onPick(s); open = false }
                )
            }
        }
    }
}

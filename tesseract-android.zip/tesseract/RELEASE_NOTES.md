You can now correct which state a day counted in.

Category, whether a day earned, and which state earned it were all overridable.
The one that was not is the one that drives the 183-day count — presence. A
reverse lookup can fail, or resolve to the wrong side of a line, and there was
no way to say so.

The categorize screen now has Auto, the counted state, the home state, or both,
with the automatic answer shown next to it. Correcting presence also corrects
which state earned the day. The CSV records whether each day's states were
geocoded or set by hand, because a log that cannot distinguish the two is worth
less than one that can.

Also: a note in Settings that a VPN cannot move your position — that comes from
satellites, wifi and cell towers, none of which care how traffic is routed —
but it can break the state lookup, which is a common reason for fixes arriving
unresolved.

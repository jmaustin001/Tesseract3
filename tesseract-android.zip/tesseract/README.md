# Tesseract — residency logger (Android)

Four location checks a day, a labelled record of every day off station, and a CSV
trail you can email to a CPA.

The name is the shape of the data: a tesseract is the four-dimensional cube, and
every fix this app takes is three axes of space plus one of time. The icon is the
standard projection — a cube inside a cube, joined corner to corner, with the six
struts between them standing in for the fourth axis.

## Build

Open this folder in Android Studio, accept the Gradle wrapper prompt, then
`Build > Build Bundle(s) / APK(s) > Build APK(s)`. Output lands in
`app/build/outputs/apk/debug/app-debug.apk`. Copy to the phone, allow install from
unknown sources, done.

## First run

The app opens into a five-step setup instead of a dashboard:

1. **What it does**, and the location/notification permission grant.
2. **Your residence** — name it, set the centre (Use my position, or type coordinates),
   set the radius. Default 50 miles.
3. **Your duty station** — same three fields. Default 20 miles.
4. **Which state is on the clock** — the state you are counting days in, and the state
   you claim as home. Both are full pickers.
5. **Warning stages** — 125 / 150 / 175 / 183, all editable, plus the always-on
   location grant.

Either location step can be skipped and added later from the dashboard.

**Run setup again** lives at the bottom of the dashboard under Tracking health. It
offers to keep your logged days or erase everything — changing where you live should
not destroy the evidence of where you were.

## After first launch — the three that matter

1. **Location: Allow all the time.** Android grants "while using" first. Use the
   button on the dashboard, then pick "Allow all the time" in the system screen.
2. **Battery: Unrestricted.** The dashboard shows a red flag if it is not. A
   throttled job means missing days.
3. **Notifications: allowed.** This is how off-station prompts and limit warnings reach you.

## What it does

**Fixed-time checks.** Default 00:00, 06:00, 12:00 and 18:00 — four fixes a day.
Editable on the dashboard as a list of hours. AlarmManager schedules each one and
sets the next, so it survives reboots. "Check now" takes an extra fix on demand.

**Daily category prompt.** Every day gets one prompt, never more, with five options:

| Category | Duty status | Place |
|---|---|---|
| Duty Station | Duty | Duty station |
| Leave Residence | Leave | Residence |
| TDY Residence | TDY | Residence |
| TDY Other | TDY | Other |
| Leave Other | Leave | Other |

The five stay fixed no matter how many datums you have, because they key off the
datum's *role* rather than its name. A fix at any residence-role datum guesses Leave
Residence; one at any duty-role datum guesses Duty Station; anything outside them all
guesses TDY Other. Rename Oviedo to Colorado Springs and the categories still work.

Timing is adaptive. If a fix lands off station, the prompt fires immediately — that is
when you know what the trip is. Otherwise it waits until the evening check (default
18:00) so an ordinary duty day does not interrupt your breakfast.

Android shows at most three notification buttons, so the two likeliest sit on the
notification itself — the GPS guess and its most common alternative — and tapping the
body opens the full five-way picker with a note field for orders numbers. Days you
skip collect on the dashboard under "Days that need a label."

**Datums, plural and editable.** A datum is a named reference point with a role
(residence, duty station, or other tracked place) and a radius. Add as many as you
like — a second residence, a detail site, a parents' address. Each one can be renamed,
moved, resized, re-roled or deleted from the dashboard.

Renaming or moving a datum never rewrites history: every fix stores the datum name and
role it had at the moment it was taken, so last year's log still reads the way it did
last year.

**The counted state is a setting, not a constant.** Pick the state you are counting
days in and the state you claim as home. Every total, warning, notification and CSV
header follows. Change it when you PCS and the warning stages reset so the new state
starts clean.

**Three-stage warnings.** Soft at 125, soft at 150, hard at 175 — all editable on the
dashboard. Each stage fires once per calendar year, not once per check. The progress
bar still measures against 183, because the hard warning deliberately sits eight days
short of the statutory line so you have room to react.

## Backup

**Save a backup** writes one JSON file containing every fix, every day label, every
datum and every setting, through the system file picker — so send it to Drive,
Dropbox or wherever, not to the phone's own storage. A backup living on the device it
backs up is not a backup.

Two ways back in:

- **Merge** adds only what is missing. A day label already on this phone is never
  overwritten by the backup, so restoring an old file cannot undo recent work.
  Fixes are deduplicated on timestamp and coordinates. Settings are left alone —
  a restore should not silently change which state you are counting.
- **Replace** wipes the log, labels and datums first, then restores everything
  including settings. This is the new-phone path, not the oops path.

The monthly report email carries the backup as a third attachment alongside the two
CSVs. If you send those reports, off-device backup happens on its own and you never
have to remember it.

## The other things it does that you did not ask for

- **Missing-day detection.** Days between your first entry and today with no fix at
  all are listed, and land in the CSV marked NO DATA. Unexplained gaps are where a
  day-count log falls apart in an audit, so the app surfaces them while you can still
  remember where you were. One tap fills a gap as VA or FL.
- **Year-end projection.** Your current pace extrapolated to 365 days, so you see a
  problem in March instead of November.
- **Time zone on every fix.** Recorded per sample. Day boundaries move when you
  travel, and a log that cannot show which clock it used is arguable.
- **Manual entries flagged as manual.** Backfilled days are marked in the CSV rather
  than blended in with GPS fixes. Anything else looks like padding.
- **Both counts, not just Virginia.** Florida days are tallied too, because proving
  you kept Florida is a different job from proving you avoided Virginia.
- **Category split into columns.** The by-day CSV carries the label plus separate
  `duty_status` and `place` columns, so the file sorts and filters without anyone
  parsing strings. The email body totals duty, TDY and leave days.
- **Report email lists its own problems.** Gap count and unlabelled-day count go in
  the body, so a report never goes out looking cleaner than the data behind it.

## Icons

`ic_launcher_foreground.xml` and `ic_launcher_background.xml` are vectors, so the
icon is resolution-independent — no PNG buckets to regenerate. Three variants ship:

- **Adaptive** — the standard launcher icon, blue wireframe on a deep gradient.
  Android crops the background to whatever shape the launcher uses.
- **Monochrome** — Android 13+ themed icons. The system tints it from the wallpaper,
  so it matches the rest of the home screen when themed icons are on.
- **Notification** — a flat white two-cube glyph. Android silhouettes status-bar icons
  to a single colour, so the fine struts are dropped and the strokes thickened; the
  detailed version would have turned into a smudge at 24dp.

`play_store_512.png` is included for a listing if the app ever goes on Play.

## Files

```
app/src/main/java/com/tesseract/app/
  MainActivity.kt    dashboard, datum editor, state pickers, schedule, health
  OnboardingActivity.kt  the five-step setup wizard
  Scheduler.kt       fixed-time alarms, check-now, monthly report, boot
  LocationWorker.kt  the fix, state resolution, off-station prompt, warnings
  StatusReceiver.kt  Leave / TDY notification buttons
  Notifier.kt        three channels: warnings, prompts, reports
  Store.kt           log, day rollups, tags, gaps, projection, settings
  Datum.kt           the datum model, radius maths, state table
  Reports.kt         CSVs and the email intent
  Backup.kt          full JSON export, merge and replace restore
```

## Where the count actually bites

You are a DoD civilian, so no SCRA shelter: a Virginia day counts whether orders,
TDY or leave put you there. Virginia's actual-residence test is physical presence
plus a place of abode in the state, and the category makes no difference to the
arithmetic.

What the categories buy you is the explanation. Domicile is argued on the whole
picture — where you keep your life, how much of the year you spend at the Florida
residence, whether time in Virginia looks compelled by the job or chosen. A log that
says "187 days in Virginia" is a problem. A log that says "187 days in Virginia, 141
of them duty, 22 TDY elsewhere, 61 days at the Florida residence" is an argument.

Still not tax advice. A CPA who handles multi-state federal employees is worth the
hour before your first full year closes.

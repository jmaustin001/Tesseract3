The Virginia tax estimate, checked against the state's own figures and
corrected where it had fallen behind.

The standard deduction was out of date. The app used $8,000 single and $16,000
joint; for tax years 2025 and 2026 it is $8,750 and $17,500. It is now keyed
by tax year, so stepping back to an earlier year uses that year's amount. The
higher figure is scheduled to end after 2026 and later years are not settled,
so the screen says when it is using a provisional amount.

The brackets were already right — 2% to $3,000, 3% to $5,000, 5% to $17,000,
5.75% above — and are now shown line by line, so you can see exactly how the
figure climbs.

The filing threshold is in: Form 763 is required once VAGI reaches $11,950,
or $23,900 filing jointly when both spouses have Virginia income. VAGI is
income from every source, not what was earned in Virginia — so a federal
salary clears it from the first Virginia workday.

The allocation percentage is now taken to one decimal place, as the form does.

The worksheet sent to a CPA carries all of this and matches the screen.

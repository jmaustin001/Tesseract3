Everything from the last round of thinking, built in.

ESTIMATED TAX. The allocation screen now estimates what is actually owed, the
way Form 763 works: tax computed as though you were a resident on all income,
then prorated by the share from the counted state. Rates are 2 / 3 / 5 / 5.75
percent, current for 2026. Enter household income, exemptions, filing status
and anything already withheld, and it shows the unpaid balance split across
the remaining quarterly estimates — the number that matters when nothing is
being withheld because your record says Florida.

WHICH STATE EARNED A DAY. Travel days are a convention, not a fact. The
categorize screen now lets you assign the income state by hand, and the CSV
records whether each day was set by a person or by the duty-hours fix.

DOMICILE EVIDENCE. A checklist of the facts a day log cannot prove — homestead,
voter registration, licenses, banking, doctors, where the family lives. Fifteen
items with a note on why each one carries weight, and a share button.

WAGE BASIS. The wage field asks for W-2 Box 1, not salary, because Virginia
begins from federal adjusted gross income and traditional TSP and FEHB are
already out of that figure.

The worksheet carries all of it, including a note that a place you have regular
access to can be an abode without a lease, a utility bill, or your name on
anything.

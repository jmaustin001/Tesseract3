package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Store.onboarded(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java)); finish(); return
        }
        val want = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
        Scheduler.scheduleNextCheck(this)
        setContent { TessTheme { Dashboard() } }
    }

    fun requestBackground() {
        if (Build.VERSION.SDK_INT >= 29)
            perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }

    /** Bumped on every resume so the dashboard re-reads the log after you have
     *  been off categorizing a day, editing a datum, or changing settings. */
    var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    fun restartSetup() { startActivity(Intent(this, OnboardingActivity::class.java)); finish() }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val year = remember { Store.year() }
    var tick by remember { mutableIntStateOf(0) }
    val resumed = (ctx as? MainActivity)?.resumeTick ?: 0
    val scope = rememberCoroutineScope()
    var fixing by remember { mutableStateOf(false) }
    var fixMsg by remember { mutableStateOf("") }
    var fixBad by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { tick++ }

    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)
    val days = remember(tick, resumed) { Store.days(ctx, year) }
    val n = remember(tick, resumed) { Store.stateDays(ctx, counted, year) }
    val homeN = remember(tick, resumed) { Store.stateDays(ctx, home, year) }
    val offN = remember(tick, resumed) { Store.offStationDays(ctx, year) }
    val untagged = remember(tick, resumed) { Store.untaggedOutDays(ctx, year) }
    val gaps = remember(tick, resumed) { Store.gapDays(ctx, year) }
    val projected = remember(tick, resumed) { Store.projectedStateDays(ctx, counted, year) }
    val limit = Store.limit(ctx)
    val soft1 = Store.soft1(ctx); val soft2 = Store.soft2(ctx); val hard = Store.hard(ctx)

    val stage = when {
        n >= limit -> 4; n >= hard -> 3; n >= soft2 -> 2; n >= soft1 -> 1; else -> 0
    }
    val accent = when (stage) { 0 -> T.Cyan; 1, 2 -> T.Gold; else -> T.Danger }

    TessScreen(
        title = "TESSERACT",
        subtitle = "residency log · $year",
        showBack = false,
        action = {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                    .background(T.Deep).border(1.dp, T.Edge, RoundedCornerShape(10.dp))
                    .clickable { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = T.Mid, fontSize = 17.sp) }
        }
    ) {
        /* ---- the last crash, if there was one ---- */
        var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
        crash?.let { text ->
            TCard("the app stopped last time", T.Danger) {
                Text(text.lines().take(8).joinToString("\n"), fontSize = 10.sp, color = T.Mid)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Copy details", Modifier.weight(1f), accent = T.Danger) {
                        val cm = ctx.getSystemService(android.content.ClipboardManager::class.java)
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("Tesseract crash", text))
                    }
                    GhostBtn("Dismiss", Modifier.weight(1f), color = T.Mid) {
                        CrashLog.clear(ctx); crash = null
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        /* ---- hero ---- */
        Box(
            // a minimum, not a fixed height: at a fixed 196dp every line added
            // below the first few was being drawn and then clipped away
            Modifier.fillMaxWidth().heightIn(min = 196.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF0C1930), Color(0xFF071120))))
                .border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(18.dp))
                .clickable { ctx.startActivity(Intent(ctx, AllocationActivity::class.java)) }
        ) {
            TesseractMarkLive(
                modifier = Modifier.size(190.dp).align(Alignment.CenterEnd).offset(x = 52.dp),
                outer = accent, inner = accent, strut = accent, alpha = .16f, stroke = 2.4f
            )
            Column(Modifier.padding(18.dp).align(Alignment.CenterStart)) {
                Text("${counted.uppercase()} · SO FAR", fontSize = 10.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(10.dp))

                val workedDays = remember(tick, resumed) { Store.earningDays(ctx, counted, year) }
                // every logged workday in the state, priced at the SF-50 rate in
                // effect on that date and summed — grows only as days are logged
                val earned = remember(tick, resumed) { Workdays.earningsAccrued(ctx, year, counted) }
                val basis = remember(tick, resumed) {
                    Store.totalIncome(ctx).let { if (it > 0) it
                        else Workdays.blendedAnnualSalary(ctx, year) }
                }
                val rate = remember(tick, resumed, basis) {
                    VaTax.effectiveRate(basis, Store.filingJoint(ctx), Store.exemptions(ctx), year)
                }
                val perDay = remember(tick, resumed) {
                    Workdays.dailyRateFor(ctx, Store.today(), year)
                }
                val money = { v: Double -> "$" + String.format(java.util.Locale.US, "%,.2f", v) }

                // 1 and 2: days there, days worked there
                Row(verticalAlignment = Alignment.Bottom) {
                    Column {
                        Text("$n", fontSize = 44.sp, fontWeight = FontWeight.Bold,
                            color = T.Hi, letterSpacing = (-1).sp)
                        Text("days in $counted", fontSize = 11.sp, color = T.Mid)
                    }
                    Spacer(Modifier.width(28.dp))
                    Column {
                        Text(fmtNum(workedDays), fontSize = 44.sp, fontWeight = FontWeight.Bold,
                            color = T.Hi, letterSpacing = (-1).sp)
                        Text("days worked there", fontSize = 11.sp, color = T.Mid)
                    }
                }
                // how many of those worked days were at the duty station itself
                val duty = remember(tick, resumed) { Earnings.compute(ctx, year) }
                if (duty.dutyWorked > 0.0) {
                    Spacer(Modifier.height(4.dp))
                    Text("${fmtNum(duty.dutyWorked)} of them at " + duty.dutyPlaces.joinToString(", "),
                        fontSize = 12.sp, color = T.Gold)
                }

                Spacer(Modifier.height(14.dp))
                if (earned > 0 || perDay > 0) {
                    // 3: what those worked days earned
                    Text(money(earned), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = T.Gold)
                    Text("earned on those days · " + money(perDay) + " a workday, from your SF-50",
                        fontSize = 11.sp, color = T.Low)

                    // 4: the tax those dollars carry
                    Spacer(Modifier.height(10.dp))
                    Text(money(earned * rate), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = T.Danger)
                    Text(String.format(java.util.Locale.US,
                            "%s tax on that · %.2f%% effective", counted, rate * 100),
                        fontSize = 11.sp, color = T.Low)
                } else {
                    Text("Enter your SF-50 salary under Pay to see what these days earned " +
                            "and what they owe.", fontSize = 11.sp, color = T.Low)
                }

                Spacer(Modifier.height(6.dp))
                Text("tap for the full Form 763 working", fontSize = 10.sp, color = T.Low)

                Spacer(Modifier.height(10.dp))
                StageBar(n, soft1, soft2, hard, limit, accent)
                Spacer(Modifier.height(10.dp))
                Text(
                    if (n < limit) "${limit - n} days of room left" else "${n - limit} days past the line",
                    fontSize = 12.sp, color = if (stage >= 3) T.Danger else T.Mid
                )
                val pcs = Store.pcsDate(ctx)
                if (pcs.isNotBlank() && Store.today() >= pcs) {
                    val sincePcs = Store.stateDaysFrom(ctx, counted, year, pcs)
                    Text("$sincePcs of those since the PCS on $pcs",
                        fontSize = 11.sp, color = T.Violet)
                }
                if (projected >= 0) Text(
                    "pace projects $projected by year end",
                    fontSize = 11.sp, color = if (projected > limit) T.Danger else T.Low
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("$homeN", "$home days", T.Teal, Modifier.weight(1f))
            StatChip("$offN", "off station", T.Violet, Modifier.weight(1f))
            StatChip("${days.size}", "days logged", T.Cyan, Modifier.weight(1f))
        }

        /* ---- today ---- */
        Spacer(Modifier.height(10.dp))
        val today = remember(tick, resumed) { Store.days(ctx, year).firstOrNull { it.date == Store.today() } }
        TCard(label = "today", accent = T.Cyan) {
            if (today == null) {
                Text("No fix yet today.", fontSize = 15.sp, color = T.Hi)
                Spacer(Modifier.height(3.dp))
                Hint("Next automatic check at ${Store.checkHours(ctx).firstOrNull { it > java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) } ?: Store.checkHours(ctx).firstOrNull() ?: 0}:00.")
            } else {
                Text(today.states.joinToString(", "), fontSize = 19.sp,
                    fontWeight = FontWeight.SemiBold, color = T.Hi)
                Spacer(Modifier.height(2.dp))
                Text(today.status.ifBlank { "not categorized" }, fontSize = 13.sp,
                    color = if (today.status.isBlank()) T.Gold else T.Mid)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryBtn(if (fixing) "Locating…" else "Log me now", Modifier.weight(1f)) {
                    if (fixing) return@PrimaryBtn
                    fixing = true; fixMsg = ""; fixBad = false
                    scope.launch {
                        val r = Fixer.capture(ctx, highAccuracy = true)
                        fixing = false
                        r.fold(
                            onSuccess = { fixMsg = "Logged — ${it.summary}"; tick++ },
                            onFailure = { fixMsg = it.message ?: "Could not get a fix."; fixBad = true }
                        )
                    }
                }
                GhostBtn("Categorize", Modifier.weight(1f)) {
                    ctx.startActivity(Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", Store.today())
                        .putExtra("summary", "Set today's category.")
                        .putExtra("guess", Status.DUTY))
                }
            }
            if (fixMsg.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(fixMsg, fontSize = 12.sp, color = if (fixBad) T.Danger else T.Teal)
            }
        }

        /* ---- the in-office requirement, this pay period ---- */
        val pp = remember(tick, resumed) { PayPeriods.current(ctx) }
        if (pp != null) {
            Spacer(Modifier.height(10.dp))
            val short = pp.officeDays < pp.required
            val covered = pp.verdict == PayPeriods.Verdict.EXEMPT
            TCard(pp.label.lowercase(), if (covered) T.Violet else if (short) T.Gold else T.Teal) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${pp.officeDays}", fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (covered) T.Violet else if (short) T.Gold else T.Teal)
                    Text(" of ${pp.required} days in the office", fontSize = 14.sp,
                        color = T.Mid, modifier = Modifier.padding(bottom = 6.dp))
                }
                if (pp.trumps.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(pp.trumps + " — " + pp.available + " of " + pp.workdays +
                            " workdays left to report", fontSize = 12.sp, color = T.Violet)
                }
                if (pp.verdict == PayPeriods.Verdict.EXEMPT) {
                    Spacer(Modifier.height(4.dp))
                    Text("Covered — orders and leave leave too few workdays to report " +
                            "${pp.required} times.", fontSize = 12.sp, color = T.Violet)
                }
                if (short && pp.verdict == PayPeriods.Verdict.IN_PROGRESS) {
                    Spacer(Modifier.height(6.dp))
                    Text("${pp.required - pp.officeDays} more before ${pp.end} to keep the " +
                            "locality", fontSize = 12.sp, color = T.Gold)
                }
            }
        }

        /* ---- anything demanding attention ---- */
        if (untagged.isNotEmpty() || gaps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            TCard(label = "needs you", accent = T.Gold) {
                if (untagged.isNotEmpty())
                    AlertRow("${untagged.size} day${if (untagged.size == 1) "" else "s"} without a category",
                        "Off station and unlabeled", T.Gold) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
                if (untagged.isNotEmpty() && gaps.isNotEmpty()) Spacer(Modifier.height(10.dp))
                if (gaps.isNotEmpty())
                    AlertRow("${gaps.size} day${if (gaps.size == 1) "" else "s"} with no data",
                        "Gaps weaken the whole log", T.Danger) {
                        ctx.startActivity(Intent(ctx, YearActivity::class.java))
                    }
            }
        }

        /* ---- navigation ---- */
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Year view", "Every day as one picture", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, YearActivity::class.java))
            }
            NavTile("Datums", Store.datums(ctx).size.let {
                "$it reference point${if (it == 1) "" else "s"}" }, T.Teal, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, DatumsActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Reports", "CSV, email, backup", T.Violet, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, ReportsActivity::class.java))
            }
            NavTile("The log", "Every day, filterable", T.Cyan, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, LogActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("TDY per diem", "M&IE, not taxable", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, PerdiemActivity::class.java))
            }
            NavTile("TQSE (LP)", "Lodgings plus · all taxable", T.Danger, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, TqseActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Pay", "LES year to date", T.Teal, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, PayActivity::class.java))
            }
            NavTile("Settings", "States, schedule, warnings", T.Cyan, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, SettingsActivity::class.java))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NavTile("Earnings by place", "State, datum, SF-50", T.Gold, Modifier.weight(1f)) {
                ctx.startActivity(Intent(ctx, EarningsActivity::class.java))
            }
        }

        Spacer(Modifier.height(16.dp))
        Hint("Physical presence is what counts — any part of a day in $counted is a $counted day. " +
                "A record-keeping aid, not tax advice.")
    }
}

/** Progress with the three warning stages marked on it. */
@Composable
private fun StageBar(n: Int, s1: Int, s2: Int, hard: Int, limit: Int, accent: Color) {
    Box(
        Modifier.fillMaxWidth(.62f).height(7.dp)
            .clip(RoundedCornerShape(4.dp)).background(Color(0xFF16243A))
    ) {
        Box(
            Modifier.fillMaxWidth((n.toFloat() / limit).coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(accent.copy(alpha = .6f), accent)))
        )
        listOf(s1, s2, hard).forEach { mark ->
            Box(
                Modifier.fillMaxWidth((mark.toFloat() / limit).coerceIn(0f, 1f))
                    .fillMaxHeight(), contentAlignment = Alignment.CenterEnd
            ) { Box(Modifier.width(1.5.dp).fillMaxHeight().background(T.Void.copy(alpha = .85f))) }
        }
    }
}

@Composable
private fun AlertRow(title: String, detail: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = T.Hi)
            Text(detail, fontSize = 11.sp, color = T.Low)
        }
        Text("›", color = T.Mid, fontSize = 19.sp)
    }
}

package com.tesseract.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.util.Locale

class AllocationActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { AllocationScreen() } }
    }
}

private fun money(v: Double) = "$" + String.format(Locale.US, "%,.0f", v)

@Composable
private fun AllocationScreen() {
    val ctx = LocalContext.current
    val resumed = (ctx as? AllocationActivity)?.resumeTick ?: 0
    var year by remember { mutableIntStateOf(Store.year()) }
    var gross by remember { mutableStateOf(Store.grossWages(ctx).let {
        if (it <= 0) "" else it.toInt().toString() }) }
    var hours by remember { mutableStateOf(Store.hoursPerDay(ctx).toString()) }
    var tick by remember { mutableIntStateOf(0) }

    val r = remember(tick, resumed, year) { Allocation.compute(ctx, year) }
    val name = States.fullName(r.state)

    TessScreen("Wage allocation", "$name · $year") {

        TCard("the ratio", T.Gold) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${r.stateWorkdays}", fontSize = 44.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Text(" / ${r.totalWorkdays}", fontSize = 20.sp, color = T.Mid,
                    modifier = Modifier.padding(bottom = 7.dp))
            }
            Text("days worked in ${r.state} out of days worked anywhere",
                fontSize = 12.sp, color = T.Mid)
            Spacer(Modifier.height(10.dp))
            Text(String.format(Locale.US, "%.2f%%", r.ratio * 100),
                fontSize = 26.sp, fontWeight = FontWeight.Bold, color = T.Hi)
        }

        Spacer(Modifier.height(10.dp))
        TCard("your pay", T.Teal) {
            DarkField(gross, "Gross wages for $year", Modifier.fillMaxWidth(), numeric = true) {
                gross = it
                Store.setGrossWages(ctx, it.toDoubleOrNull() ?: 0.0); tick++
            }
            Spacer(Modifier.height(8.dp))
            DarkField(hours, "Hours in a duty day", Modifier.fillMaxWidth()) {
                hours = it
                it.toDoubleOrNull()?.let { v -> Store.setHoursPerDay(ctx, v); tick++ }
            }
            Spacer(Modifier.height(8.dp))
            Hint("The W-2 figure. It stays on this phone like everything else.")
        }

        if (r.gross > 0) {
            Spacer(Modifier.height(10.dp))
            TCard("allocated to $name", T.Gold) {
                Text(money(r.stateWages), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Spacer(Modifier.height(4.dp))
                Text("of ${money(r.gross)} gross", fontSize = 13.sp, color = T.Mid)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip(money(r.dailyRate), "per duty day", T.Teal, Modifier.weight(1f))
                    StatChip(money(r.hourlyRate), "per hour", T.Teal, Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        val problems = r.gapDays + r.uncategorized
        TCard("how solid this is", if (problems > 0) T.Danger else T.Teal) {
            Line("Days with no location data", r.gapDays, r.gapDays > 0)
            Line("Days never categorized", r.uncategorized, r.uncategorized > 0)
            Line("Worked days with no fix in duty hours", r.weakIncomeDays, false)
            Line("Days set by hand rather than by rule", r.manualOverrides, false)
            Spacer(Modifier.height(10.dp))
            Hint(
                if (problems > 0)
                    "Clear these before relying on the figures. Every unexplained gap is a " +
                            "day an examiner is free to assign as they like."
                else "No gaps and nothing unlabeled. This is what a contemporaneous record " +
                        "is supposed to look like."
            )
        }

        Spacer(Modifier.height(10.dp))
        TCard("the worksheet", T.Violet) {
            Hint("A plain-language sheet showing every figure and how it was reached — " +
                    "the method, the day counts, the ratio, and the weak spots above. " +
                    "Built to be handed to a CPA, not filed.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Share the worksheet", accent = T.Violet) {
                val f = Allocation.writeFile(ctx, r)
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                ctx.startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "$name wage allocation $year")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share worksheet"))
            }
            Spacer(Modifier.height(8.dp))
            Hint("Send the day-by-day and fix-by-fix CSVs with it. The worksheet is the " +
                    "summary; those are the evidence.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("read it first", T.Edge) {
            Hint("The working-day ratio is the usual method, not the only one, and this " +
                    "app is not qualified to say which applies to you. Staying under the " +
                    "day threshold does not stop $name taxing wages you earned there — " +
                    "it keeps $name to those wages rather than all your income. If nothing " +
                    "is being withheld, that liability is accruing somewhere. Worth a CPA " +
                    "before a quarterly deadline rather than after the year closes.")
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostBtn("◀ ${year - 1}", Modifier.weight(1f), color = T.Mid) { year -= 1 }
            GhostBtn("${year + 1} ▶", Modifier.weight(1f), color = T.Mid) { year += 1 }
        }
    }
}

@Composable
private fun Line(label: String, n: Int, bad: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Hi, modifier = Modifier.weight(1f))
        Text("$n", fontSize = 15.sp, fontWeight = FontWeight.Bold,
            color = if (bad) T.Danger else T.Mid)
    }
}

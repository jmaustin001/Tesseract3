package com.tesseract.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { SettingsScreen() } }
    }
    fun restartSetup() { startActivity(Intent(this, OnboardingActivity::class.java)); finish() }
}

@Composable
private fun SettingsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }

    var hours by remember { mutableStateOf(Store.checkHours(ctx).joinToString(", ")) }
    var s1 by remember { mutableStateOf(Store.soft1(ctx).toString()) }
    var s2 by remember { mutableStateOf(Store.soft2(ctx).toString()) }
    var hard by remember { mutableStateOf(Store.hard(ctx).toString()) }
    var limit by remember { mutableStateOf(Store.limit(ctx).toString()) }
    var confirmReset by remember { mutableStateOf(false) }

    val next = remember(hours, tick) {
        SimpleDateFormat("EEE HH:mm", Locale.US).format(Date(Scheduler.nextCheckTime(ctx)))
    }
    val pm = ctx.getSystemService(PowerManager::class.java)
    val unrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)

    TessScreen("Settings", "states · schedule · warnings") {

        TCard("states", T.Gold) {
            StateRow("Counting days in", Store.countedState(ctx), T.Gold) {
                Store.setCountedState(ctx, it); tick++
            }
            Spacer(Modifier.height(14.dp))
            StateRow("Claimed home state", Store.homeState(ctx), T.Teal) {
                Store.setHomeState(ctx, it); tick++
            }
            Spacer(Modifier.height(12.dp))
            Hint("Change the counted state when you PCS and every total, warning and report " +
                    "follows it. The warning stages reset so the new state starts clean.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("schedule", T.Cyan) {
            DarkField(hours, "Check at these hours", Modifier.fillMaxWidth()) {
                hours = it
                val p = it.split(",").mapNotNull { h -> h.trim().toIntOrNull() }.filter { h -> h in 0..23 }
                if (p.isNotEmpty()) { Store.setCheckHours(ctx, p); Scheduler.scheduleNextCheck(ctx); tick++ }
            }
            Spacer(Modifier.height(8.dp))
            Hint("Next check: $next. Four a day is the default — more costs battery and buys " +
                    "nothing, since a day counts the same whether you were seen once or ten times.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Check now") { Scheduler.checkNow(ctx) }
        }

        Spacer(Modifier.height(10.dp))
        TCard("warning stages", T.Danger) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DarkField(s1, "Soft 1", Modifier.weight(1f), numeric = true) {
                    s1 = it; it.toIntOrNull()?.let { v -> Store.setSoft1(ctx, v) } }
                DarkField(s2, "Soft 2", Modifier.weight(1f), numeric = true) {
                    s2 = it; it.toIntOrNull()?.let { v -> Store.setSoft2(ctx, v) } }
                DarkField(hard, "Hard", Modifier.weight(1f), numeric = true) {
                    hard = it; it.toIntOrNull()?.let { v -> Store.setHard(ctx, v) } }
                DarkField(limit, "Limit", Modifier.weight(1f), numeric = true) {
                    limit = it; it.toIntOrNull()?.let { v -> Store.setLimit(ctx, v) } }
            }
            Spacer(Modifier.height(10.dp))
            Hint("Each stage fires once per calendar year. The hard warning sits short of the " +
                    "limit on purpose, so there is still room to change plans when it lands.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("tracking health", if (unrestricted) T.Teal else T.Danger) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Battery unrestricted", fontSize = 14.sp, color = T.Hi, modifier = Modifier.weight(1f))
                Text(if (unrestricted) "OK" else "NEEDS ATTENTION", fontSize = 11.sp,
                    fontWeight = FontWeight.Bold, color = if (unrestricted) T.Teal else T.Danger)
            }
            if (!unrestricted) {
                Spacer(Modifier.height(12.dp))
                PrimaryBtn("Exempt from battery optimisation", accent = T.Danger) {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${ctx.packageName}")))
                }
            }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Allow location all the time") {
                (ctx as? ComponentActivity)?.let { }
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${ctx.packageName}")))
            }
            Spacer(Modifier.height(12.dp))
            Hint("In app settings, turn OFF \"Pause app activity if unused\". Android hibernates " +
                    "apps it thinks you have abandoned and revokes their permissions — and this " +
                    "app is built to be opened rarely, which is exactly what trips it.")
            Spacer(Modifier.height(10.dp))
            Hint("Cost: four checks a day, about a second each, on the low-power network fix " +
                    "rather than the GPS chip. No background service, no wake locks. Asleep the " +
                    "rest of the time.")
        }

        Spacer(Modifier.height(10.dp))
        PcsCard()

        Spacer(Modifier.height(10.dp))
        TravelCard()

        Spacer(Modifier.height(10.dp))
        UpdateCard()

        Spacer(Modifier.height(10.dp))
        TCard("setup", T.Low) {
            if (!confirmReset) {
                GhostBtn("Run setup again", color = T.Mid) { confirmReset = true }
            } else {
                Hint("Setup walks through datums, states and thresholds again.")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Keep my log", Modifier.weight(1f)) {
                        Store.resetSetup(ctx, eraseLog = false)
                        (ctx as? SettingsActivity)?.restartSetup()
                    }
                    GhostBtn("Erase all", Modifier.weight(1f), color = T.Danger) {
                        Store.resetSetup(ctx, eraseLog = true)
                        (ctx as? SettingsActivity)?.restartSetup()
                    }
                }
                Spacer(Modifier.height(6.dp))
                GhostBtn("Cancel", color = T.Low) { confirmReset = false }
            }
        }
    }
}

@Composable
private fun StateRow(label: String, selected: String, accent: androidx.compose.ui.graphics.Color,
                     onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(label.uppercase(), fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
                .background(T.Glow).border(1.dp, accent.copy(alpha = .4f), RoundedCornerShape(11.dp))
                .clickable { open = true }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(selected, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = accent)
            Spacer(Modifier.width(10.dp))
            Text(States.fullName(selected), fontSize = 14.sp, color = T.Mid, modifier = Modifier.weight(1f))
            Text("▾", color = T.Mid, fontSize = 13.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false },
            modifier = Modifier.background(T.Deep)) {
            States.all.forEach { s ->
                DropdownMenuItem(
                    text = { Text("$s · ${States.fullName(s)}", color = T.Hi, fontSize = 14.sp) },
                    onClick = { onPick(s); open = false }
                )
            }
        }
    }
}

@Composable
private fun UpdateCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var repo by remember { mutableStateOf(Store.updateRepo(ctx)) }
    var state by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Updater.Release?>(null) }
    var history by remember { mutableStateOf<List<Updater.Release>>(emptyList()) }
    var showHistory by remember { mutableStateOf(false) }

    fun grab(rel: Updater.Release) {
        busy = true; state = ""; bad = false
        scope.launch {
            val d = Updater.download(ctx, rel)
            busy = false
            d.fold(
                onSuccess = { Updater.install(ctx, it) },
                onFailure = { state = it.message ?: "Download failed."; bad = true }
            )
        }
    }

    TCard("updates", if (found != null) T.Cyan else T.Edge) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Installed", fontSize = 14.sp, color = T.Hi)
                Text("Every build carries its own number, so you always know exactly " +
                        "what is running.", fontSize = 11.sp, color = T.Low, lineHeight = 14.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(BuildConfig.VERSION_NAME, fontSize = 17.sp,
                    fontWeight = FontWeight.Bold, color = T.Cyan)
                Text("build ${BuildConfig.VERSION_CODE}", fontSize = 10.sp, color = T.Low)
            }
        }

        Spacer(Modifier.height(14.dp))
        if (found == null) {
            PrimaryBtn(if (busy) "Checking…" else "Check for updates") {
                if (busy) return@PrimaryBtn
                busy = true; state = ""; bad = false
                scope.launch {
                    val r = Updater.check(ctx)
                    busy = false
                    r.fold(
                        onSuccess = { rel ->
                            if (rel == null) state = "You are on the latest build."
                            else found = rel
                        },
                        onFailure = { state = it.message ?: "Check failed."; bad = true }
                    )
                }
            }
        } else {
            val rel = found!!
            Text(rel.label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
            Text("published ${rel.published}", fontSize = 11.sp, color = T.Low)
            if (rel.notes.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Hint(rel.notes)
            }
            Spacer(Modifier.height(12.dp))
            PrimaryBtn(if (busy) "Downloading…" else "Download and install") { grab(rel) }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Not now", color = T.Low) { found = null }
        }

        if (state.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(state, fontSize = 12.sp, color = if (bad) T.Danger else T.Teal)
        }

        /* ---- rollback ---- */
        Spacer(Modifier.height(14.dp))
        if (!showHistory) {
            GhostBtn("Earlier builds", color = T.Mid) {
                showHistory = true
                scope.launch {
                    Updater.history(ctx).fold(
                        onSuccess = { history = it },
                        onFailure = { state = it.message ?: "Could not list builds."; bad = true }
                    )
                }
            }
        } else {
            Text("EARLIER BUILDS", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            if (history.isEmpty()) {
                Hint("Loading…")
            } else history.forEach { r ->
                val current = r.build == BuildConfig.VERSION_CODE
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.label, fontSize = 14.sp,
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                            color = if (current) T.Cyan else T.Hi)
                        Text(r.published, fontSize = 10.sp, color = T.Low)
                    }
                    if (current) Text("RUNNING", fontSize = 9.sp, color = T.Cyan,
                        fontWeight = FontWeight.Bold)
                    else TextButton(onClick = { grab(r) }) {
                        Text("Install", fontSize = 12.sp, color = T.Mid)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            GhostBtn("Hide", color = T.Low) { showHistory = false }
        }

        Spacer(Modifier.height(12.dp))
        Hint("Going back a build: Android will not install an older build over a newer one, " +
                "so a rollback means uninstalling first — which wipes your log. Save a backup " +
                "from the Reports screen before you do it, then restore after. Moving forward " +
                "never needs any of that; it installs straight over the top and keeps everything.")

        Spacer(Modifier.height(12.dp))
        DarkField(repo, "Update source (owner/repo)", Modifier.fillMaxWidth()) {
            repo = it; Store.setUpdateRepo(ctx, it)
        }
        Spacer(Modifier.height(8.dp))
        Hint("Reads the release listing from that public repository. Your log is never " +
                "uploaded — nothing leaves the phone but the request for a version number.")
    }
}

@Composable
private fun PcsCard() {
    val ctx = LocalContext.current
    var date by remember { mutableStateOf(Store.pcsDate(ctx)) }
    val valid = Regex("\\d{4}-\\d{2}-\\d{2}").matches(date)
    val today = Store.today()
    val year = Store.year()
    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)

    TCard("pcs", T.Violet) {
        DarkField(date, "PCS date (YYYY-MM-DD)", Modifier.fillMaxWidth()) {
            date = it
            if (it.isBlank() || Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) Store.setPcsDate(ctx, it)
        }

        if (valid) {
            Spacer(Modifier.height(12.dp))
            val before = Store.stateDaysBefore(ctx, counted, year, date)
            val after = Store.stateDaysFrom(ctx, counted, year, date)
            val homeBefore = Store.stateDaysBefore(ctx, home, year, date)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("$homeBefore", "$home · pre-PCS", T.Teal, Modifier.weight(1f))
                StatChip("$before", "$counted · pre-PCS", T.Low, Modifier.weight(1f))
                StatChip("$after", "$counted · post-PCS", T.Gold, Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))
            if (today < date) {
                val remaining = daysBetween(today, date)
                Text("$remaining days until the move", fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold, color = T.Hi)
                val possible = daysBetween(date, "$year-12-31") + 1
                Spacer(Modifier.height(6.dp))
                Hint("Moving on $date leaves at most $possible days in ${States.fullName(counted)} " +
                        "this calendar year — below the ${Store.limit(ctx)} limit even if you never " +
                        "leave. The year of the move is nearly always safe. The first full year is " +
                        "the one this log exists for.")
            } else {
                Hint("Reports now split either side of $date, so the partial year reads as a " +
                        "partial year instead of looking like a light one.")
            }
        } else {
            Spacer(Modifier.height(10.dp))
            Hint("Set the date the duty station changes. Counting stays per calendar year — " +
                    "that is how the law works — but every report splits before and after, so " +
                    "nobody reads a half-year at the new station as a full one.")
        }
    }
}

private fun daysBetween(a: String, b: String): Int = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    ((f.parse(b)!!.time - f.parse(a)!!.time) / 86_400_000L).toInt()
} catch (e: Exception) { 0 }

@Composable
private fun TravelCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val unresolved = remember(tick) { Store.unresolvedCount(ctx) }

    TCard("travel and TDY", if (unresolved > 0) T.Gold else T.Edge) {
        Hint("TDY anywhere works without setup: a fix outside every datum records the " +
                "state or country it landed in, prompts you to label the day, and gives you " +
                "a note field for the orders number. You only need a datum for places you " +
                "return to often enough to want counted separately.")

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Fixes with no location resolved", fontSize = 14.sp, color = T.Hi,
                modifier = Modifier.weight(1f))
            Text("$unresolved", fontSize = 16.sp, fontWeight = FontWeight.Bold,
                color = if (unresolved > 0) T.Gold else T.Teal)
        }
        Spacer(Modifier.height(6.dp))
        Hint("Overseas with data off, the coordinates still get logged but the country " +
                "cannot be looked up. Run this on wifi afterwards and they fill themselves in.")

        if (unresolved > 0) {
            Spacer(Modifier.height(12.dp))
            PrimaryBtn(if (busy) "Resolving…" else "Resolve $unresolved unknown", accent = T.Gold) {
                if (busy) return@PrimaryBtn
                busy = true; msg = ""
                scope.launch {
                    val n = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        Store.resolveUnknowns(ctx) { la, lo -> Fixer.resolveState(ctx, la, lo) }
                    }
                    busy = false; tick++
                    msg = if (n > 0) "Resolved $n." else "Still no answer — try again on wifi."
                }
            }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }

        Spacer(Modifier.height(12.dp))
        Hint("Foreign days are recorded as three-letter country codes — DEU, JPN, KOR — " +
                "which can never be mistaken for a US state. A two-letter scheme would read " +
                "Valencia as VA and invent Virginia days.")
    }
}

package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Biweekly pay periods, and whether each one meets the in-office requirement.
 *
 * To keep an official worksite — and with it the locality pay attached to it —
 * a teleworking employee must physically report there at least twice each
 * biweekly pay period on a regular and recurring basis. That is a per-period
 * test, so it has to be counted per period, not per year.
 */
object PayPeriods {

    fun anchor(c: Context): String = Store.prefString(c, "ppAnchor", "2026-09-20")
    fun setAnchor(c: Context, v: String) = Store.setPrefString(c, "ppAnchor", v)

    /**
     * A PP number you typed for the anchor period, to override the count.
     * 0 — the default — means the official count below is used. (A new key:
     * a number typed under the old month-style scheme is not carried over.)
     */
    fun anchorNumber(c: Context) = Store.prefInt(c, "ppAnchorNo2", 0)
    fun setAnchorNumber(c: Context, n: Int) = Store.setPrefInt(c, "ppAnchorNo2", n)

    fun required(c: Context) = Store.prefInt(c, "ppRequired", 2)
    fun setRequired(c: Context, n: Int) = Store.setPrefInt(c, "ppRequired", n.coerceAtLeast(0))

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun daysBetween(a: String, b: String): Long? = try {
        Math.round((fmt.parse(b)!!.time - fmt.parse(a)!!.time) / 86_400_000.0)
    } catch (e: Exception) { null }

    /** Period index relative to the anchor: 0 for the anchor period, negative before it. */
    fun indexOf(c: Context, date: String): Int? {
        val d = daysBetween(anchor(c), date) ?: return null
        return Math.floorDiv(d, 14L).toInt()
    }

    fun isStart(c: Context, date: String): Boolean {
        val d = daysBetween(anchor(c), date) ?: return false
        return Math.floorMod(d, 14L) == 0L
    }

    fun startOf(c: Context, date: String): String? {
        val i = indexOf(c, date) ?: return null
        val cal = Calendar.getInstance().apply { time = fmt.parse(anchor(c))!! }
        cal.add(Calendar.DAY_OF_YEAR, i * 14)
        return fmt.format(cal.time)
    }

    fun endOf(c: Context, start: String): String {
        val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
        cal.add(Calendar.DAY_OF_YEAR, 13)
        return fmt.format(cal.time)
    }

    /**
     * The official pay period number, as on the LES. Federal pay periods are
     * biweekly — 26 a year, 27 in some — and number from the first period
     * that starts in the calendar year (the leave year). With periods starting
     * 20 Sep 2026 that first period is 11 Jan 2026, so 20 Sep is PP 19 and
     * 4 Oct is PP 20. They are not two per month: every so often a month
     * holds the start of three.
     */
    fun number(c: Context, start: String): Int? {
        val typed = anchorNumber(c)
        val i = indexOf(c, start) ?: return null
        if (typed > 0) {
            val n = typed + i
            return if (n in 1..27) n else null
        }
        val year = start.take(4)
        val first = try {
            val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            // walk back a period at a time while the earlier start is still in this year
            while (true) {
                val prev = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -14) }
                if (fmt.format(prev.time).take(4) != year) break
                cal.time = prev.time
            }
            fmt.format(cal.time)
        } catch (e: Exception) { return null }
        val d = daysBetween(first, start) ?: return null
        return (d / 14).toInt() + 1
    }

    /** "PP 20 · Oct 4–17" */
    fun label(c: Context, start: String): String {
        val n = number(c, start)
        return (if (n != null) "PP $n · " else "PP · ") + span(start, endOf(c, start))
    }

    private val MON = listOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
    fun span(a: String, b: String): String {
        val ma = MON[a.substring(5, 7).toInt() - 1]; val mb = MON[b.substring(5, 7).toInt() - 1]
        val da = a.substring(8).trimStart('0'); val db = b.substring(8).trimStart('0')
        return if (ma == mb) "$ma $da–$db" else "$ma $da – $mb $db"
    }

    /**
     * A day you actually reported to the official worksite.
     *
     * Categorized Duty Station always counts. Categorized as anything else —
     * travel, TDY, leave, telework — never does, even if a fix happened to land
     * inside the duty datum: driving past the Pentagon on a PCS travel day is not
     * reporting to it. Only an uncategorized day falls back on the location, and
     * then only if it was a scheduled workday.
     */
    fun inOffice(ctx: Context, d: DaySummary): Boolean {
        if (d.status == Status.DUTY) return true
        if (d.status.isNotBlank()) return false
        return Datum.DUTY in d.roles && Workdays.earned(ctx, d)
    }

    private fun onLeaveOrTdy(d: DaySummary): Boolean {
        val s = Status.dutyStatus(d.status)
        return s == "Leave" || s == "TDY"
    }

    /**
     * MET: reported to the official worksite enough times.
     * EXEMPT: short, but orders or leave left fewer scheduled workdays than the
     *   requirement — a temporary situation (TDY, extended leave) is not a
     *   change of worksite. The agency makes that call; this marks it.
     * SHORT: short, with workdays available to report.
     * IN_PROGRESS: the period has not ended and can still be met.
     */
    enum class Verdict { MET, SHORT, EXEMPT, IN_PROGRESS }

    data class Period(
        val start: String,
        val end: String,
        val label: String,
        val officeDays: Int,
        val leaveOrTdyDays: Int,
        val required: Int,
        val verdict: Verdict,
        val tdyDays: Int = 0,          // scheduled workdays on orders
        val leaveDays: Int = 0,        // scheduled workdays on leave
        val workdays: Int = 0,         // scheduled workdays in the period
        val available: Int = 0         // workdays left once orders and leave are taken out
    ) {
        /** "On orders 3 days · leave 1 day", or blank. */
        val trumps: String get() = listOfNotNull(
            if (tdyDays > 0) "on orders $tdyDays day${if (tdyDays == 1) "" else "s"}" else null,
            if (leaveDays > 0) "leave $leaveDays day${if (leaveDays == 1) "" else "s"}" else null
        ).joinToString(" · ").replaceFirstChar { it.uppercase() }
    }

    /** Every period from the anchor forward through today, newest first. */
    fun periods(c: Context): List<Period> {
        val today = Store.today()
        val start0 = anchor(c)
        if (start0 > today) return emptyList()

        val days = Store.days(c).associateBy { it.date }
        val need = required(c)
        val out = mutableListOf<Period>()

        var start = start0
        var guard = 0
        while (start <= today && guard++ < 200) {
            val end = endOf(c, start)
            val span = mutableListOf<DaySummary>()
            val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            repeat(14) {
                days[fmt.format(cal.time)]?.let { span.add(it) }
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            val office = span.count { inOffice(c, it) }
            val away = span.count { onLeaveOrTdy(it) }
            // only scheduled workdays matter: a weekend on orders takes no office day away
            val sched = { d: DaySummary -> Workdays.earnedOn(c, d.date, "") }
            val tdy = span.count { Status.dutyStatus(it.status) == "TDY" && sched(it) }
            val leave = span.count { Status.dutyStatus(it.status) == "Leave" && sched(it) }
            val workdays = Workdays.scheduledWorkdaysBetween(c, start, nextStart(start))
            val available = (workdays - tdy - leave).coerceAtLeast(0)

            val verdict = when {
                office >= need -> Verdict.MET
                // orders and leave left too few workdays to report the required times
                available < need -> Verdict.EXEMPT
                end >= today -> Verdict.IN_PROGRESS
                else -> Verdict.SHORT
            }
            out.add(Period(start, end, label(c, start), office, away, need, verdict,
                tdy, leave, workdays, available))

            val next = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            next.add(Calendar.DAY_OF_YEAR, 14)
            start = fmt.format(next.time)
        }
        return out.reversed()
    }

    fun current(c: Context): Period? = periods(c).firstOrNull()

    private fun nextStart(start: String): String {
        val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
        cal.add(Calendar.DAY_OF_YEAR, 14)
        return fmt.format(cal.time)
    }
}

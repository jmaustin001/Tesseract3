package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * A few figures off each LES, stored as numbers rather than images.
 *
 * Every entry records year-to-date totals, not the amounts for that period.
 * That single choice makes a missed entry harmless: the next LES restates the
 * year, so the record catches itself up with no gap to fill and nothing to
 * reconstruct. Per-period amounts are derived by subtraction when they are
 * wanted, which is the opposite of the usual design and much more forgiving.
 */
data class PaySnapshot(
    val periodEnd: String,      // yyyy-MM-dd
    val ytdGross: Double,
    val ytdTaxable: Double,     // the Box 1 figure as it stands
    val ytdFederal: Double,
    val ytdState: Double,
    val stateCode: String,
    val note: String = "",
    // optional, off the same LES — default 0 so an older saved entry still parses
    val hourlyRate: Double = 0.0,
    val annualRate: Double = 0.0,      // the salary line on the LES itself
    val ytdPretax: Double = 0.0        // TSP, FEHB, FSA and the like, summed
)

object Pay {

    private const val KEY = "paySnapshots"

    fun all(ctx: Context): List<PaySnapshot> {
        val a = JSONArray(Store.prefString(ctx, KEY, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            PaySnapshot(
                o.optString("end"), o.optDouble("gross", 0.0), o.optDouble("taxable", 0.0),
                o.optDouble("fed", 0.0), o.optDouble("state", 0.0),
                o.optString("stateCode", ""), o.optString("note", ""),
                o.optDouble("hourly", 0.0), o.optDouble("annual", 0.0),
                o.optDouble("pretax", 0.0)
            )
        }.sortedBy { it.periodEnd }
    }

    fun save(ctx: Context, list: List<PaySnapshot>) {
        val a = JSONArray()
        list.sortedBy { it.periodEnd }.forEach { p ->
            a.put(JSONObject().apply {
                put("end", p.periodEnd); put("gross", p.ytdGross); put("taxable", p.ytdTaxable)
                put("fed", p.ytdFederal); put("state", p.ytdState)
                put("stateCode", p.stateCode); put("note", p.note)
                put("hourly", p.hourlyRate); put("annual", p.annualRate); put("pretax", p.ytdPretax)
            })
        }
        Store.setPrefString(ctx, KEY, a.toString())
    }

    /** One entry per period end; entering the same date twice replaces it. */
    fun upsert(ctx: Context, p: PaySnapshot) {
        val cur = all(ctx).filterNot { it.periodEnd == p.periodEnd }.toMutableList()
        cur.add(p)
        save(ctx, cur)
    }

    fun delete(ctx: Context, periodEnd: String) =
        save(ctx, all(ctx).filterNot { it.periodEnd == periodEnd })

    fun forYear(ctx: Context, year: Int) = all(ctx).filter { it.periodEnd.startsWith("$year-") }

    fun latest(ctx: Context, year: Int) = forYear(ctx, year).lastOrNull()

    /** What accrued between two entries, however many periods apart they are. */
    fun since(prev: PaySnapshot?, now: PaySnapshot) = PaySnapshot(
        periodEnd = now.periodEnd,
        ytdGross = now.ytdGross - (prev?.ytdGross ?: 0.0),
        ytdTaxable = now.ytdTaxable - (prev?.ytdTaxable ?: 0.0),
        ytdFederal = now.ytdFederal - (prev?.ytdFederal ?: 0.0),
        ytdState = now.ytdState - (prev?.ytdState ?: 0.0),
        stateCode = now.stateCode
    )

    data class Projection(
        val throughDate: String,
        val daysElapsed: Int,
        val fractionOfYear: Double,
        val projectedGross: Double,
        val projectedTaxable: Double,
        val projectedFederal: Double,
        val projectedState: Double,
        val periodsRecorded: Int,
        val periodsExpected: Int
    )

    /** Straight-line to year end from whatever the last entry says. */
    fun project(ctx: Context, year: Int, everyDays: Int = 14): Projection? {
        val last = latest(ctx, year) ?: return null
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val start = Calendar.getInstance().apply { clear(); set(year, 0, 1) }
        val end = try { fmt.parse(last.periodEnd)!! } catch (e: Exception) { return null }
        val days = ((end.time - start.timeInMillis) / 86_400_000L).toInt() + 1
        val yearDays = if (year % 4 == 0) 366 else 365
        val f = (days.toDouble() / yearDays).coerceIn(0.01, 1.0)

        return Projection(
            throughDate = last.periodEnd,
            daysElapsed = days,
            fractionOfYear = f,
            projectedGross = last.ytdGross / f,
            projectedTaxable = last.ytdTaxable / f,
            projectedFederal = last.ytdFederal / f,
            projectedState = last.ytdState / f,
            periodsRecorded = forYear(ctx, year).size,
            periodsExpected = (days / everyDays).coerceAtLeast(1)
        )
    }

    // ---------- the reminder schedule ----------

    fun anchor(ctx: Context): String = Store.prefString(ctx, "payAnchor", "")
    fun setAnchor(ctx: Context, d: String) = Store.setPrefString(ctx, "payAnchor", d)

    fun everyDays(ctx: Context) = Store.prefInt(ctx, "payEveryDays", 14)
    fun setEveryDays(ctx: Context, n: Int) = Store.setPrefInt(ctx, "payEveryDays", n.coerceAtLeast(1))

    fun remindersOn(ctx: Context) = Store.prefBool(ctx, "payRemind", false)
    fun setRemindersOn(ctx: Context, v: Boolean) = Store.setPrefBool(ctx, "payRemind", v)

    /** Next period end on or after today, counted from the anchor. */
    fun nextDue(ctx: Context): String? {
        val a = anchor(ctx)
        if (a.isBlank()) return null
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply {
            time = try { fmt.parse(a)!! } catch (e: Exception) { return null }
        }
        val today = Store.today()
        var guard = 0
        while (fmt.format(cal.time) < today && guard++ < 400) {
            cal.add(Calendar.DAY_OF_YEAR, everyDays(ctx))
        }
        return fmt.format(cal.time)
    }

    /** How many entries are missing since the anchor — informational, not an error. */
    fun missedCount(ctx: Context, year: Int): Int {
        val p = project(ctx, year, everyDays(ctx)) ?: return 0
        return (p.periodsExpected - p.periodsRecorded).coerceAtLeast(0)
    }
}

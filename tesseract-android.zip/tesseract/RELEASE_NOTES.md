Two telework categories now ship with the app rather than waiting to be typed:

  Residence — TS telework situational
  Residence — telework regular

They are ordinary saved categories, so rename or remove them like any other,
and they appear on the categorize screen in magenta beside the built-in five.

Why they matter: telework at the residence earns Florida-source wages and
dilutes the Virginia ratio. Leave at the residence earns nothing anywhere.
Same house, same GPS fix, opposite consequences — and no way to tell them
apart after the fact without a label.

A sixth day-category you name yourself — Telework, PCS travel, holiday,
whatever fits. Custom categories count and export like the built-in five.

"Log me now" on the dashboard takes a high-accuracy fix on command and tells
you what it recorded, rather than queueing a background check.

Travel days now render as a diagonally split square in the year grid, so a
DC-to-Orlando day shows both states at a glance instead of picking one.

The by-day CSV carries a pcs_phase column, so every row says whether it fell
before or after the move.

Salary history, per-period LES entry, and a breakdown of where the money was
earned.

SALARY HISTORY (Pay screen)
As many SF-50s as you have, each with its own effective date — replacing the
two fixed cards, which could only hold one raise. Each has pay plan and grade,
basic pay (20A), locality percent and dollars (20B), and adjusted basic pay
(20C), checked against each other before you save. A day is priced at the
SF-50 in effect on it, so a year with two raises is counted at three rates,
each only on the days it covered. The rate in effect today is marked. Your two
existing figures carry over; the older one has no date yet, and says so.

LES BY PAY PERIOD
The LES form now takes either the current-period column or the year-to-date
column. Enter a period and the app adds it to your last entry before that date
to keep the year-to-date record. Enter periods in order.

EARNINGS BY PLACE (new tile on the dashboard)
From logged days only, nothing projected:
  at your duty station in Virginia — days worked, pay per day, dollars earned,
    and the Virginia tax on them
  all of Virginia — every worked day Virginia can reach, the Form 763 figure
  by state — days present, days worked, dollars
  by place — each datum by name, with every worked day credited to one place
    so the column adds up to the year
  by SF-50 — the days and dollars each pay action covered, anywhere and in
    Virginia

VA · SO FAR on the dashboard now adds how many of your Virginia workdays were
at the duty station itself.

The day-by-day CSV gains three columns: where each day's pay was credited, the
SF-50 that priced it, and the day's pay.

Every dollar field in the app takes a decimal point — 29 of them, checked.

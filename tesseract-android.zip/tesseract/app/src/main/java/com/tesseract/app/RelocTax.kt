package com.tesseract.app

/**
 * Relocation money is taxable; travel money generally is not.
 *
 * Since 2018 every civilian PCS reimbursement — TQSE, house hunting, the
 * miscellaneous allowance, en route travel — is reported as wages. TDY per
 * diem under an accountable plan is not, which is why the two calculators
 * answer different questions.
 *
 * WTA is an advance against that tax, grossed up so the withholding does not
 * eat the reimbursement. RITA reconciles it the following year against what
 * you actually owed. Both are themselves taxable, which is why the arithmetic
 * divides rather than multiplies.
 */
object RelocTax {

    /** Federal supplemental withholding rate used for WTA. */
    const val SUPPLEMENTAL = 0.22

    data class Result(
        val taxable: Double,
        val wtaRate: Double,
        val wta: Double,
        val grossedUp: Double,
        val cmtr: Double,
        val trueGrossUp: Double,
        val ritaEstimate: Double,
        val netAfterTax: Double
    )

    /** x / (1 - x): what it takes to still have the original sum after tax. */
    fun grossUpFactor(rate: Double) = if (rate >= 1.0) 0.0 else rate / (1.0 - rate)

    fun compute(
        taxable: Double,
        federalMarginal: Double,
        stateMarginal: Double,
        localMarginal: Double = 0.0,
        wtaRate: Double = SUPPLEMENTAL
    ): Result {
        val wta = taxable * grossUpFactor(wtaRate)

        // the FTR combines the marginal rates, netting the federal deduction
        // for state tax rather than simply adding them
        val cmtr = (federalMarginal + stateMarginal * (1 - federalMarginal) +
                localMarginal * (1 - federalMarginal)).coerceIn(0.0, 0.95)

        val trueGrossUp = taxable * grossUpFactor(cmtr)
        val rita = trueGrossUp - wta

        return Result(
            taxable = taxable,
            wtaRate = wtaRate,
            wta = wta,
            grossedUp = taxable + wta,
            cmtr = cmtr,
            trueGrossUp = trueGrossUp,
            ritaEstimate = rita,
            netAfterTax = (taxable + wta) * (1 - cmtr)
        )
    }
}

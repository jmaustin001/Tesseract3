package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Biweekly pay periods, and whether each one meets the in-office requirement.
 *
 * To keep an official worksite — and with it the locality pay attached to it —
 * a teleworking employee must physically report there at least twice each
 * biweekly pay period on a regular and recurring basis. That is a per-period
 * test, so it has to be counted per period, not per year.
 */
object PayPeriods {

    fun anchor(c: Context): String = Store.prefString(c, "ppAnchor", "2026-09-20")
    fun setAnchor(c: Context, v: String) = Store.setPrefString(c, "ppAnchor", v)

    /** The PP number the anchor period carries. 0 means not set. */
    fun anchorNumber(c: Context) = Store.prefInt(c, "ppAnchorNumber", 0)
    fun setAnchorNumber(c: Context, n: Int) = Store.setPrefInt(c, "ppAnchorNumber", n)

    fun required(c: Context) = Store.prefInt(c, "ppRequired", 2)
    fun setRequired(c: Context, n: Int) = Store.setPrefInt(c, "ppRequired", n.coerceAtLeast(0))

    private val fmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun daysBetween(a: String, b: String): Long? = try {
        (fmt.parse(b)!!.time - fmt.parse(a)!!.time) / 86_400_000L
    } catch (e: Exception) { null }

    /** Period index relative to the anchor: 0 for the anchor period, negative before it. */
    fun indexOf(c: Context, date: String): Int? {
        val d = daysBetween(anchor(c), date) ?: return null
        return Math.floorDiv(d, 14L).toInt()
    }

    fun isStart(c: Context, date: String): Boolean {
        val d = daysBetween(anchor(c), date) ?: return false
        return Math.floorMod(d, 14L) == 0L
    }

    fun startOf(c: Context, date: String): String? {
        val i = indexOf(c, date) ?: return null
        val cal = Calendar.getInstance().apply { time = fmt.parse(anchor(c))!! }
        cal.add(Calendar.DAY_OF_YEAR, i * 14)
        return fmt.format(cal.time)
    }

    fun endOf(c: Context, start: String): String {
        val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
        cal.add(Calendar.DAY_OF_YEAR, 13)
        return fmt.format(cal.time)
    }

    /** "PP 20" when numbered, otherwise the start date. */
    fun label(c: Context, start: String): String {
        val n = anchorNumber(c)
        val i = indexOf(c, start) ?: return start
        if (n <= 0) return "PP from $start"
        // federal pay periods run 1..26 (27 in some years) and restart each January;
        // counting straight on from the anchor is right within the year it was set in
        val num = n + i
        return if (num in 1..27) "PP $num" else "PP from $start"
    }

    /**
     * A day you actually reported to the official worksite.
     *
     * Categorized Duty Station always counts. Categorized as anything else —
     * travel, TDY, leave, telework — never does, even if a fix happened to land
     * inside the duty datum: driving past the Pentagon on a PCS travel day is not
     * reporting to it. Only an uncategorized day falls back on the location, and
     * then only if it was a scheduled workday.
     */
    fun inOffice(ctx: Context, d: DaySummary): Boolean {
        if (d.status == Status.DUTY) return true
        if (d.status.isNotBlank()) return false
        return Datum.DUTY in d.roles && Workdays.earned(ctx, d)
    }

    private fun onLeaveOrTdy(d: DaySummary): Boolean {
        val s = Status.dutyStatus(d.status)
        return s == "Leave" || s == "TDY"
    }

    enum class Verdict { MET, SHORT, EXEMPT, IN_PROGRESS }

    data class Period(
        val start: String,
        val end: String,
        val label: String,
        val officeDays: Int,
        val leaveOrTdyDays: Int,
        val required: Int,
        val verdict: Verdict
    )

    /** Every period from the anchor forward through today, newest first. */
    fun periods(c: Context): List<Period> {
        val today = Store.today()
        val start0 = anchor(c)
        if (start0 > today) return emptyList()

        val days = Store.days(c).associateBy { it.date }
        val need = required(c)
        val out = mutableListOf<Period>()

        var start = start0
        var guard = 0
        while (start <= today && guard++ < 200) {
            val end = endOf(c, start)
            val span = mutableListOf<DaySummary>()
            val cal = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            repeat(14) {
                days[fmt.format(cal.time)]?.let { span.add(it) }
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            val office = span.count { inOffice(c, it) }
            val away = span.count { onLeaveOrTdy(it) }

            val verdict = when {
                office >= need -> Verdict.MET
                end >= today -> Verdict.IN_PROGRESS
                // most of the period away on leave or TDY: the regular-and-recurring
                // test is about the normal pattern, not a period you were not there
                away >= 5 -> Verdict.EXEMPT
                else -> Verdict.SHORT
            }
            out.add(Period(start, end, label(c, start), office, away, need, verdict))

            val next = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            next.add(Calendar.DAY_OF_YEAR, 14)
            start = fmt.format(next.time)
        }
        return out.reversed()
    }

    fun current(c: Context): Period? = periods(c).firstOrNull()
}

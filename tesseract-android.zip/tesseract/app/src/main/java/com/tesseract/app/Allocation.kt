package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Turns the day log into the numbers a nonresident wage allocation needs.
 *
 * The method is the working-day ratio: wages earned in the state over wages
 * earned everywhere, measured in days worked. It is the usual approach, but it
 * is not the only one, and which one applies is a question for a CPA. Nothing
 * here fills in a tax form — it produces a worksheet showing every figure and
 * how it was reached, so someone qualified can check the reasoning rather than
 * trust a number.
 */
object Allocation {

    data class Result(
        val year: Int,
        val state: String,
        val stateWorkdays: Int,
        val totalWorkdays: Int,
        val ratio: Double,
        val gross: Double,
        val ratioWages: Double,
        val directWages: Double,
        val directLabel: String,
        val stateWages: Double,
        val dailyRate: Double,
        val hourlyRate: Double,
        // the parts that weaken the figure, surfaced rather than buried
        val gapDays: Int,
        val uncategorized: Int,
        val weakIncomeDays: Int,
        val manualOverrides: Int
    )

    fun compute(ctx: Context, year: Int): Result {
        val state = Store.countedState(ctx)
        val days = Store.days(ctx, year)

        val total = days.count { Workdays.earned(ctx, it) }
        val inState = days.count { Workdays.earned(ctx, it) && Store.incomeStateOf(ctx, it) == state }
        val ratio = if (total > 0) inState.toDouble() / total else 0.0

        val gross = Store.grossWages(ctx)
        val daily = if (total > 0) gross / total else 0.0
        val hourly = if (Store.hoursPerDay(ctx) > 0) daily / Store.hoursPerDay(ctx) else 0.0

        val direct = Store.directWages(ctx)
        val ratioWages = gross * ratio

        return Result(
            year = year,
            state = state,
            stateWorkdays = inState,
            totalWorkdays = total,
            ratio = ratio,
            gross = gross,
            ratioWages = ratioWages,
            directWages = direct,
            directLabel = Store.directLabel(ctx),
            stateWages = ratioWages + direct,
            dailyRate = daily,
            hourlyRate = hourly,
            gapDays = Store.gapDays(ctx, year).size,
            uncategorized = days.count { it.status.isBlank() },
            weakIncomeDays = days.count { Workdays.earned(ctx, it) && !it.fixDuringDuty },
            manualOverrides = days.count { Store.workOverride(ctx, it.date) != null }
        )
    }

    private fun money(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

    /** A plain-text worksheet. Readable by a person, not a form to be filed. */
    fun worksheet(ctx: Context, r: Result): String = buildString {
        val name = States.fullName(r.state)
        appendLine("NONRESIDENT WAGE ALLOCATION WORKSHEET")
        appendLine("$name — tax year ${r.year}")
        appendLine("Prepared ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())} from a")
        appendLine("contemporaneous GPS day log. Not tax advice, and not a tax form.")
        appendLine()

        appendLine("WAGE BASIS")
        appendLine("  Two buckets, kept apart. Regular wages are allocated by the")
        appendLine("  working-day ratio below. Amounts a payer has already sourced")
        appendLine("  to the state — a relocation W-2 carrying a figure in Box 16 —")
        appendLine("  are added whole and never passed through the ratio, because")
        appendLine("  that decision was made when it was reported.")
        appendLine()
        appendLine("  Figures below use W-2 Box 1, federal taxable wages. Virginia")
        appendLine("  begins from federal adjusted gross income, so traditional TSP,")
        appendLine("  FEHB premium conversion, FSA and similar pre-tax items are")
        appendLine("  already excluded. Roth TSP is not. This worksheet does not")
        appendLine("  apply Virginia's standard deduction or exemptions — on Form 763")
        appendLine("  those are taken in full against total income and the resulting")
        appendLine("  tax is then prorated by the allocation percentage below.")
        appendLine()

        appendLine("METHOD")
        appendLine("  Working-day ratio. Wages are allocated to $name in the same")
        appendLine("  proportion as days worked there to days worked everywhere.")
        appendLine("  A day counts as worked unless it was a non-duty weekday, a")
        appendLine("  federal holiday, a scheduled regular day off, a day categorized")
        appendLine("  as leave, or a day marked off by hand. A worked day is assigned")
        appendLine("  to the state recorded during duty hours.")
        appendLine()

        appendLine("DAYS")
        appendLine("  Days worked in $name         ${r.stateWorkdays}")
        appendLine("  Days worked everywhere            ${r.totalWorkdays}")
        appendLine("  Ratio                             ${String.format(Locale.US, "%.6f", r.ratio)}")
        appendLine("                                    (${String.format(Locale.US, "%.2f", r.ratio * 100)}%)")
        appendLine()

        appendLine("WAGES")
        if (r.gross <= 0) {
            appendLine("  No wage figure has been entered, so no allocation is shown.")
            appendLine("  Enter W-2 Box 1 in the app to complete this.")
        } else {
            appendLine("  W-2 Box 1 wages, regular pay      ${money(r.gross)}")
            appendLine("  Allocated by working-day ratio    ${money(r.ratioWages)}")
            if (r.directWages > 0) {
                appendLine("  ${r.directLabel.padEnd(33)} ${money(r.directWages)}")
                appendLine("    already sourced by the payer, not run through the ratio")
            }
            appendLine("  Total $name wages            ${money(r.stateWages)}")
            appendLine("  Implied daily rate                ${money(r.dailyRate)}")
            appendLine("  Implied hourly rate               ${money(r.hourlyRate)}")
            appendLine("    (at ${Store.hoursPerDay(ctx)} hours per duty day)")
        }
        appendLine()

        val est = VaTax.estimate(
            // when no household figure is given, total must still include the
                // separately reported wages or the state share could exceed 100%
                totalIncome = Store.totalIncome(ctx)
                    .let { if (it > 0) it else r.gross + r.directWages },
            vaIncome = r.stateWages,
            relocationIncome = r.directWages,
            joint = Store.filingJoint(ctx),
            exemptions = Store.exemptions(ctx),
            withheld = Store.vaWithheld(ctx),
            monthsElapsed = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH)
        )
        if (r.gross > 0 && est.totalIncome > 0) {
            appendLine("ESTIMATED TAX — PLANNING ONLY")
            appendLine("  Form 763 computes tax as though you were a resident on all")
            appendLine("  income, then prorates it by the share from $name. This")
            appendLine("  follows that order. It ignores credits, itemised deductions,")
            appendLine("  additions and subtractions.")
            appendLine()
            appendLine("  Total income                      ${money(est.totalIncome)}")
            appendLine("  Standard deduction                ${money(est.deduction)}")
            appendLine("  Exemptions                        ${money(est.exemptionTotal)}")
            appendLine("  Taxable as a resident             ${money(est.taxableAsResident)}")
            appendLine("  Tax as a resident                 ${money(est.taxAsResident)}")
            appendLine("  Allocation percentage             ${String.format(Locale.US, "%.2f", est.allocationPct * 100)}%")
            appendLine("  Estimated $name tax          ${money(est.vaTax)}")
            appendLine("  Withheld so far                   ${money(est.withheld)}")
            appendLine("  Unpaid                            ${money(est.shortfall)}")
            if (est.taxOnRelocation > 0) {
                appendLine()
                appendLine("  Of that estimated tax:")
                appendLine("    on relocation wages             ${money(est.taxOnRelocation)}")
                appendLine("      RITA reimburses substantially all additional federal,")
                appendLine("      state and local tax caused by taxable relocation")
                appendLine("      benefits, so this is largely recoverable")
                appendLine("    on ordinary wages               ${money(est.taxYouBear)}")
                appendLine("      this is the part actually borne by the employee")
            }
            if (est.shortfall > 0) {
                appendLine("  Across ${est.quartersLeft} remaining estimate(s)   ${money(est.perQuarter)} each")
                appendLine()
                appendLine("  Virginia charges underpayment penalties on tax that should")
                appendLine("  have been paid quarterly. If nothing is being withheld,")
                appendLine("  this is accruing.")
            }
            appendLine()
        }

        appendLine("RESIDENCY, SEPARATELY")
        appendLine("  Days present in $name        ${Store.stateDays(ctx, r.state, r.year)}")
        appendLine("  of a ${Store.limit(ctx)}-day threshold")
        appendLine("  Presence and income are different tests. A weekend in $name")
        appendLine("  counts toward presence and earns nothing.")
        appendLine()
        appendLine("  Crossing the threshold while maintaining a place of abode in")
        appendLine("  $name makes you a statutory resident, and $name then")
        appendLine("  reaches all household income rather than the allocated share.")
        appendLine("  A place you have regular access to can be an abode without a")
        appendLine("  lease, a utility bill or your name on anything.")
        appendLine()

        appendLine("HOW SOLID THIS IS")
        appendLine("  Days with no location data        ${r.gapDays}")
        appendLine("  Days never categorized            ${r.uncategorized}")
        appendLine("  Worked days with no fix during")
        appendLine("    duty hours                      ${r.weakIncomeDays}")
        appendLine("  Days set by hand rather than rule ${r.manualOverrides}")
        if (r.gapDays > 0 || r.uncategorized > 0) {
            appendLine()
            appendLine("  Resolve the above before relying on these figures. Every")
            appendLine("  unexplained gap is a day an examiner can assign as they like.")
        }
        appendLine()
        appendLine("Underlying day-by-day and fix-by-fix records export separately")
        appendLine("from the same app and should accompany this worksheet.")
    }

    fun writeFile(ctx: Context, r: Result): java.io.File {
        val dir = java.io.File(ctx.filesDir, "reports").apply { mkdirs() }
        return java.io.File(dir, "allocation-${r.state.lowercase()}-${r.year}.txt")
            .apply { writeText(worksheet(ctx, r)) }
    }
}

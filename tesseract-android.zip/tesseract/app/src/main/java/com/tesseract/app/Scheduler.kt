package com.tesseract.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Fixes are taken at fixed clock times (default 00:00 / 06:00 / 12:00 / 18:00) via
 * AlarmManager. Four fixes a day instead of twenty-four: less battery, less data,
 * and a cleaner record. Each alarm reschedules the next one.
 */
object Scheduler {
    const val WORK_REPORT = "daycount_report"
    private const val ACTION_CHECK = "com.tesseract.app.CHECK"

    fun scheduleNextCheck(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val next = nextCheckTime(ctx)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, checkIntent(ctx))
    }

    fun nextCheckTime(ctx: Context): Long {
        val hours = Store.checkHours(ctx).ifEmpty { listOf(0, 6, 12, 18) }
        val now = Calendar.getInstance()
        for (h in hours) {
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.after(now)) return c.timeInMillis
        }
        return Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, hours.first()); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private fun checkIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 100, Intent(ctx, CheckAlarmReceiver::class.java).setAction(ACTION_CHECK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** "Check now" from the dashboard, outside the schedule. */
    fun checkNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueue(
            OneTimeWorkRequestBuilder<LocationWorker>().build()
        )
    }

    fun scheduleMonthlyReport(ctx: Context) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            add(Calendar.MONTH, 1); set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0)
        }
        val req = PeriodicWorkRequestBuilder<ReportWorker>(30, TimeUnit.DAYS)
            .setInitialDelay((next.timeInMillis - now.timeInMillis).coerceAtLeast(0), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork(WORK_REPORT, ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class CheckAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.checkNow(context)
        Scheduler.scheduleNextCheck(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Scheduler.scheduleNextCheck(context)
            Scheduler.scheduleMonthlyReport(context)
        }
    }
}

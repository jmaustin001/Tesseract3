package com.tesseract.app

import android.content.Context

/**
 * Where the money was earned. Every figure is built from logged days only —
 * nothing is projected — and each worked day is priced at the SF-50 in effect
 * on that date.
 *
 * A worked day is credited to exactly one place, so the place totals add up to
 * the year total: the duty-station datum if the day touched one, otherwise the
 * first named datum it touched, otherwise "elsewhere" in the state that earned it.
 */
object Earnings {

    data class Line(
        val label: String,
        val sub: String,
        val present: Int,
        val worked: Double,   // a day split by hours counts its share
        val dollars: Double
    ) {
        val perDay get() = if (worked > 0) dollars / worked else 0.0
    }

    data class Sf50Line(
        val record: SalaryRecord,
        val from: String,
        val toExclusive: String,
        val perDay: Double,
        val worked: Double,
        val dollars: Double,
        val stateWorked: Double,
        val stateDollars: Double
    )

    data class Report(
        val year: Int,
        val counted: String,
        val worked: Double,
        val dollars: Double,
        val byState: List<Line>,
        val byPlace: List<Line>,
        val dutyPlaces: List<String>,
        val dutyWorked: Double,
        val dutyDollars: Double,
        val stateWorked: Double,
        val stateDollars: Double,
        val bySf50: List<Sf50Line>,
        val taxRate: Double
    ) {
        val dutyTax get() = dutyDollars * taxRate
        val stateTax get() = stateDollars * taxRate
    }

    /**
     * The state each datum sits in, read from the fixes that landed inside it —
     * the state most of them resolved to. Reconstructed days fill in a datum no
     * real fix has reached yet.
     */
    fun datumStates(ctx: Context): Map<String, String> {
        val counts = mutableMapOf<String, MutableMap<String, Int>>()
        Store.samples(ctx).forEach { s ->
            if (s.zoneName == Zones.OUT_NAME || s.state.isBlank() || s.state == "?") return@forEach
            counts.getOrPut(s.zoneName) { mutableMapOf() }.let { m -> m[s.state] = (m[s.state] ?: 0) + 1 }
        }
        Reconstruct.all(ctx).values.forEach { r ->
            if (r.zone.isBlank() || r.state.isBlank() || counts.containsKey(r.zone)) return@forEach
            counts.getOrPut(r.zone) { mutableMapOf() }.let { m -> m[r.state] = (m[r.state] ?: 0) + 1 }
        }
        return counts.mapValues { (_, m) -> m.maxByOrNull { it.value }!!.key }
    }

    /**
     * The one place a worked day's pay is credited to. A datum only takes pay
     * earned in its own state — leaving the Florida residence on the morning you
     * start in Virginia is Virginia pay, and it is not credited to the residence.
     */
    fun placeOf(d: DaySummary, roles: Map<String, String>, incomeState: String,
                datumState: Map<String, String>): String {
        // a datum whose state is not known yet only takes the day's main state,
        // so a new datum never soaks up the District half of a split day
        fun fits(z: String) = datumState[z]?.let { it == incomeState }
            ?: (incomeState == d.primaryState)
        return d.zones.firstOrNull { roles[it] == Datum.DUTY && fits(it) }
            ?: d.zones.firstOrNull { it != Zones.OUT_NAME && roles.containsKey(it) && fits(it) }
            ?: "Elsewhere in $incomeState"
    }

    fun compute(ctx: Context, year: Int): Report {
        val counted = Store.countedState(ctx)
        val roles = Store.datums(ctx).associate { it.name to it.role }
        val dState = datumStates(ctx)
        val days = Store.days(ctx, year)
        val windows = Salaries.windows(ctx, year)
        // read once per report, not once per day — a year of days would otherwise
        // re-parse the salary history and recount the year's workdays each time
        val divisor = Workdays.scheduledWorkdays(ctx, year).coerceAtLeast(1)
        val recs = Salaries.all(ctx).filter { it.rate > 0 }
        fun payOn(date: String): Double {
            if (recs.isEmpty()) return 0.0
            val r = recs.lastOrNull { it.effective.isBlank() || it.effective <= date } ?: recs.first()
            return r.rate / divisor
        }

        class Acc { var present = 0; var worked = 0.0; var dollars = 0.0 }
        val states = linkedMapOf<String, Acc>()
        val places = linkedMapOf<String, Acc>()
        val sf = windows.map { doubleArrayOf(0.0, 0.0, 0.0, 0.0) } // worked, $, state worked, state $
        val dutyNames = linkedSetOf<String>()
        var worked = 0.0; var dollars = 0.0
        var dutyWorked = 0.0; var dutyDollars = 0.0
        var stWorked = 0.0; var stDollars = 0.0

        for (d in days) {
            Store.resolvedStates(d).forEach { states.getOrPut(it) { Acc() }.present++ }
            d.zones.filter { it != Zones.OUT_NAME && roles.containsKey(it) }
                .forEach { places.getOrPut(it) { Acc() }.present++ }

            if (!Workdays.earned(ctx, d)) continue
            val dayPay = payOn(d.date)
            val w = windows.indexOfFirst { d.date >= it.from && d.date < it.toExclusive }
            worked += 1.0; dollars += dayPay
            if (w >= 0) { sf[w][0] += 1.0; sf[w][1] += dayPay }

            // one share per state — the whole day unless you split it by hours
            for ((inc, share) in Store.incomeShares(ctx, d)) {
                val pay = dayPay * share
                states.getOrPut(inc) { Acc() }.let { it.worked += share; it.dollars += pay }
                val place = placeOf(d, roles, inc, dState)
                places.getOrPut(place) { Acc() }.let { it.worked += share; it.dollars += pay }

                if (inc == counted) {
                    stWorked += share; stDollars += pay
                    if (roles[place] == Datum.DUTY) {
                        dutyWorked += share; dutyDollars += pay; dutyNames.add(place)
                    }
                    if (w >= 0) { sf[w][2] += share; sf[w][3] += pay }
                }
            }
        }

        val basis = Store.totalIncome(ctx).let { if (it > 0) it else Workdays.blendedAnnualSalary(ctx, year) }
        val rate = VaTax.effectiveRate(basis, Store.filingJoint(ctx), Store.exemptions(ctx), year)

        return Report(
            year = year,
            counted = counted,
            worked = worked,
            dollars = dollars,
            byState = states.map { (k, a) -> Line(k, "", a.present, a.worked, a.dollars) }
                .sortedByDescending { it.dollars },
            // the label is where the place is, never where its last day was earned
            byPlace = places.map { (k, a) ->
                val where = dState[k] ?: if (k.startsWith("Elsewhere in ")) "" else "state unknown"
                val role = when (roles[k]) {
                    Datum.DUTY -> "duty station"; Datum.RESIDENCE -> "residence"; else -> ""
                }
                Line(k, listOf(where, role).filter { it.isNotBlank() }.joinToString(" · "),
                    a.present, a.worked, a.dollars)
            }.sortedByDescending { it.dollars },
            dutyPlaces = dutyNames.toList(),
            dutyWorked = dutyWorked,
            dutyDollars = dutyDollars,
            stateWorked = stWorked,
            stateDollars = stDollars,
            bySf50 = windows.mapIndexed { i, w ->
                Sf50Line(w.record, w.from, w.toExclusive, w.record.rate / divisor,
                    sf[i][0], sf[i][1], sf[i][2], sf[i][3])
            },
            taxRate = rate
        )
    }
}

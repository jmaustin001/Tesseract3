The SF-50 effective date now warns when it falls partway through the year.

A rate that started on 20 September is not what you earn in that year — the
months before it were at a different locality. Nothing multiplies this salary
out across a whole year for that reason. The dashboard works from your LES
year-to-date figures instead, which already carry both rates. From the first
full year at one rate, the two agree.

Everything in 1.24.0 is here: both daily rates shown side by side and
reconciled to the salary, cents where cents matter, and figures that shrink to
fit rather than wrapping mid-digit.

package com.tesseract.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The log on screen, so checking it never means emailing yourself. */
class LogActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { LogScreen() } }
    }
}

private enum class Filter(val label: String) {
    ALL("All"), EARNED("Earned"), COUNTED("In state"), PROBLEMS("Needs review")
}

@Composable
private fun LogScreen() {
    val ctx = LocalContext.current
    val year = Store.year()
    val resumed = (ctx as? LogActivity)?.resumeTick ?: 0
    var filter by remember { mutableStateOf(Filter.ALL) }
    var month by remember { mutableIntStateOf(0) }   // 0 = whole year

    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)
    val all = remember(resumed) { Store.days(ctx, year) }
    val gaps = remember(resumed) { Store.gapDays(ctx, year).toSet() }

    val rows = all.filter { d ->
        (month == 0 || d.date.substring(5, 7).toInt() == month) && when (filter) {
            Filter.ALL -> true
            Filter.EARNED -> Workdays.earned(ctx, d)
            Filter.COUNTED -> counted in d.states
            // a reconstructed day has no fixes by design, so it is not a problem
            Filter.PROBLEMS -> !d.reconstructed && (d.status.isBlank() ||
                    Store.hasUnresolved(d) ||
                    (Workdays.earned(ctx, d) && !d.fixDuringDuty))
        }
    }.reversed()

    TessScreen("The log", "$year · ${rows.size} days shown") {

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Filter.values().forEach { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text(f.label, fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(0 to "Year", 1 to "Jan", 2 to "Feb", 3 to "Mar", 4 to "Apr", 5 to "May",
                6 to "Jun", 7 to "Jul", 8 to "Aug", 9 to "Sep", 10 to "Oct", 11 to "Nov",
                12 to "Dec").forEach { (m, label) ->
                val on = month == m
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp))
                        .background(if (on) T.Cyan.copy(alpha = .18f) else T.Deep)
                        .border(1.dp, if (on) T.Cyan else T.Edge, RoundedCornerShape(8.dp))
                        .clickable { month = m }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) { Text(label, fontSize = 12.sp, color = if (on) T.Cyan else T.Mid) }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (gaps.isNotEmpty() && filter == Filter.PROBLEMS) {
            TCard("missing days", T.Danger) {
                Hint("${gaps.size} dates have no entry at all. Fill them from the year view.")
            }
            Spacer(Modifier.height(10.dp))
        }

        if (rows.isEmpty()) {
            TCard { Hint("Nothing matches that filter.") }
        } else {
            TCard {
                rows.forEach { d ->
                    LogRow(d, counted, home)
                    HorizontalDivider(color = T.Edge.copy(alpha = .5f))
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        GhostBtn("Share the CSV") {
            ctx.startActivity(Intent.createChooser(Reports.shareIntent(ctx, year), "Share log"))
        }
        Spacer(Modifier.height(8.dp))
        Hint("Tap any row to change its category or override whether it earned.")
    }
}

@Composable
private fun LogRow(d: DaySummary, counted: String, home: String) {
    val ctx = LocalContext.current
    val earned = Workdays.earned(ctx, d)
    val dot = when {
        counted in d.states -> T.Gold
        home in d.states -> T.Teal
        else -> T.Violet
    }

    Row(
        Modifier.fillMaxWidth()
            .clickable {
                ctx.startActivity(
                    Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", d.date)
                        .putExtra("summary", d.states.joinToString(", "))
                        .putExtra("guess", d.status.ifBlank { Status.DUTY })
                )
            }
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(dot))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d.date, fontSize = 13.sp, color = T.Hi, fontWeight = FontWeight.Medium)
                if (Store.isSplit(d)) {
                    Spacer(Modifier.width(6.dp))
                    Text("split", fontSize = 9.sp, color = T.Ice)
                }
            }
            Text(
                d.status.ifBlank { "no category" },
                fontSize = 11.sp,
                color = if (d.status.isBlank()) T.Gold else T.Mid
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(d.states.joinToString("/"), fontSize = 13.sp, color = T.Hi)
            Text(
                if (earned) "$ ${Store.incomeStateOf(ctx, d)}" else Workdays.reason(ctx, d),
                fontSize = 10.sp,
                color = if (earned) T.Gold else T.Low
            )
        }
    }
}

package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class PayActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { PayScreen() } }
    }
}

private fun usd(v: Double) = "$" + String.format(Locale.US, "%,.0f", v)
private fun usd2(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

@Composable
private fun PayScreen() {
    val ctx = LocalContext.current
    val year = Store.year()
    val resumed = (ctx as? PayActivity)?.resumeTick ?: 0
    var tick by remember { mutableIntStateOf(0) }

    val snaps = remember(tick, resumed) { Pay.forYear(ctx, year) }
    val latest = snaps.lastOrNull()
    val proj = remember(tick, resumed) { Pay.project(ctx, year, Pay.everyDays(ctx)) }
    val counted = Store.countedState(ctx)

    var adding by remember { mutableStateOf(snaps.isEmpty()) }
    var end by remember { mutableStateOf(Store.today()) }
    // a half-finished entry survives leaving the screen
    var gross by remember { mutableStateOf(Store.prefString(ctx, "payDraftGross", "")) }
    var taxable by remember { mutableStateOf(Store.prefString(ctx, "payDraftTaxable", "")) }
    var fed by remember { mutableStateOf(Store.prefString(ctx, "payDraftFed", "")) }
    var st by remember { mutableStateOf(Store.prefString(ctx, "payDraftState", "")) }
    var hourly by remember { mutableStateOf(Store.prefString(ctx, "payDraftHourly", "")) }
    var annualOnLes by remember { mutableStateOf(Store.prefString(ctx, "payDraftAnnual", "")) }
    var pretax by remember { mutableStateOf(Store.prefString(ctx, "payDraftPretax", "")) }
    var msg by remember { mutableStateOf("") }

    TessScreen("Pay", "year to date · $year") {

        SalaryCard { tick++ }
        Spacer(Modifier.height(10.dp))
        WageBaseCard(tick) { tick++ }
        Spacer(Modifier.height(10.dp))

        if (latest != null) {
            TCard("as of ${latest.periodEnd}", T.Gold) {
                Text(usd(latest.ytdTaxable), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Text("taxable wages year to date — the Box 1 figure so far",
                    fontSize = 12.sp, color = T.Mid)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip(usd(latest.ytdGross), "gross", T.Cyan, Modifier.weight(1f))
                    StatChip(usd(latest.ytdFederal), "federal", T.Teal, Modifier.weight(1f))
                    StatChip(usd(latest.ytdState), "$counted held", 
                        if (latest.ytdState > 0) T.Teal else T.Danger, Modifier.weight(1f))
                }
                if (latest.ytdState <= 0.0) {
                    Spacer(Modifier.height(12.dp))
                    Text("Nothing withheld for $counted.", fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Danger)
                    Spacer(Modifier.height(4.dp))
                    Hint("Expected while your record says Florida — but the liability is " +
                            "accruing anyway, and $counted wants it quarterly. This is the " +
                            "figure to watch the day after a PCS, because if it never starts " +
                            "you need estimated payments rather than a surprise in April.")
                }
            }
        }

        if (proj != null) {
            Spacer(Modifier.height(10.dp))
            TCard("where the year lands", T.Cyan) {
                Hint("Straight-line from ${proj.throughDate}, ${proj.daysElapsed} days in. " +
                        "Early in the year this swings a lot; by autumn it is close.")
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text("Taxable wages", fontSize = 13.sp, color = T.Mid,
                        modifier = Modifier.weight(1f))
                    Text(usd(proj.projectedTaxable), fontSize = 15.sp,
                        fontWeight = FontWeight.Bold, color = T.Hi)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text("Federal withheld", fontSize = 13.sp, color = T.Mid,
                        modifier = Modifier.weight(1f))
                    Text(usd(proj.projectedFederal), fontSize = 14.sp, color = T.Hi)
                }
                Spacer(Modifier.height(12.dp))
                PrimaryBtn("Use $" + String.format(Locale.US, "%,.0f", proj.projectedTaxable) +
                        " as the wage base") {
                    Store.setGrossWages(ctx, proj.projectedTaxable)
                    tick++
                    msg = "Allocation screen updated."
                }
                Spacer(Modifier.height(6.dp))
                Hint("Feeds the wage allocation directly, so you stop typing it in twice. " +
                        "Swap it for the real Box 1 once the W-2 arrives.")
            }
        }

        if (snaps.isNotEmpty() && Pay.missedCount(ctx, year) > 0) {
            Spacer(Modifier.height(10.dp))
            TCard("missed entries", T.Edge) {
                Text("${Pay.missedCount(ctx, year)} period" +
                        "${if (Pay.missedCount(ctx, year) == 1) "" else "s"} not entered",
                    fontSize = 14.sp, color = T.Hi)
                Spacer(Modifier.height(6.dp))
                Hint("Nothing is lost. Every LES restates the year to date, so the next " +
                        "entry you make carries the full total and the record catches itself " +
                        "up. There is no gap to go back and fill.")
            }
        }

        Spacer(Modifier.height(10.dp))
        if (!adding) {
            PrimaryBtn("Add an LES") { adding = true; end = Pay.nextDue(ctx) ?: Store.today() }
        } else {
            TCard("from the LES", T.Teal) {
                Hint("Four figures off the year-to-date column. Nothing is stored but the " +
                        "numbers — no screenshot, no document, nothing with your name on it.")
                Spacer(Modifier.height(14.dp))
                DarkField(end, "Period ending (YYYY-MM-DD)", Modifier.fillMaxWidth()) { end = it }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(gross, "YTD gross", Modifier.weight(1f), numeric = true) { gross = it; Store.setPrefString(ctx, "payDraftGross", it) }
                    DarkField(taxable, "YTD taxable", Modifier.weight(1f), numeric = true) {
                        taxable = it; Store.setPrefString(ctx, "payDraftTaxable", it)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(fed, "YTD federal tax", Modifier.weight(1f), numeric = true) {
                        fed = it; Store.setPrefString(ctx, "payDraftFed", it)
                    }
                    DarkField(st, "YTD $counted tax", Modifier.weight(1f), numeric = true) {
                        st = it; Store.setPrefString(ctx, "payDraftState", it)
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("ALSO ON THE LES, IF SHOWN", fontSize = 9.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(hourly, "Hourly rate", Modifier.weight(1f), numeric = true) {
                        hourly = it; Store.setPrefString(ctx, "payDraftHourly", it)
                    }
                    DarkField(annualOnLes, "Annual salary", Modifier.weight(1f), numeric = true) {
                        annualOnLes = it; Store.setPrefString(ctx, "payDraftAnnual", it)
                    }
                }
                Spacer(Modifier.height(8.dp))
                DarkField(pretax, "YTD pre-tax deductions — TSP, FEHB, FSA and similar",
                    Modifier.fillMaxWidth(), numeric = true) {
                    pretax = it; Store.setPrefString(ctx, "payDraftPretax", it)
                }
                val g = gross.toDoubleOrNull(); val t = taxable.toDoubleOrNull()
                val pt = pretax.toDoubleOrNull()
                if (g != null && t != null && pt != null && pt > 0) {
                    val impliedPretax = g - t
                    val off = kotlin.math.abs(impliedPretax - pt)
                    if (off > 1.0) {
                        Spacer(Modifier.height(8.dp))
                        Text("Gross minus taxable implies " + usd2(impliedPretax) +
                                " of pre-tax deductions; you entered " + usd2(pt) + ".",
                            fontSize = 11.sp, color = T.Gold)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Hint("None of these three change the tax figures — Box 1 taxable wages is " +
                        "still what drives the allocation. They are here so the LES is fully " +
                        "on record, and so a mismatch between gross, taxable and what you " +
                        "expect to see deducted shows up rather than going unnoticed.")

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Save", Modifier.weight(1f), accent = T.Teal) {
                        if (taxable.toDoubleOrNull() != null) {
                            Pay.upsert(ctx, PaySnapshot(
                                periodEnd = end.trim(),
                                ytdGross = gross.toDoubleOrNull() ?: 0.0,
                                ytdTaxable = taxable.toDoubleOrNull() ?: 0.0,
                                ytdFederal = fed.toDoubleOrNull() ?: 0.0,
                                ytdState = st.toDoubleOrNull() ?: 0.0,
                                stateCode = counted,
                                hourlyRate = hourly.toDoubleOrNull() ?: 0.0,
                                annualRate = annualOnLes.toDoubleOrNull() ?: 0.0,
                                ytdPretax = pretax.toDoubleOrNull() ?: 0.0
                            ))
                            adding = false; tick++
                            gross = ""; taxable = ""; fed = ""; st = ""
                            hourly = ""; annualOnLes = ""; pretax = ""
                            listOf("payDraftGross", "payDraftTaxable", "payDraftFed",
                                "payDraftState", "payDraftHourly", "payDraftAnnual",
                                "payDraftPretax").forEach { Store.setPrefString(ctx, it, "") }
                            msg = "Saved."
                        } else msg = "YTD taxable is the one figure that is needed."
                    }
                    GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { adding = false }
                }
            }
        }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }

        if (snaps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            TCard("the record") {
                snaps.reversed().forEachIndexed { i, p ->
                    val prev = snaps.getOrNull(snaps.size - i - 2)
                    val d = Pay.since(prev, p)
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.periodEnd, fontSize = 13.sp,
                                fontWeight = FontWeight.Medium, color = T.Hi)
                            Text("since last: ${usd2(d.ytdTaxable)} taxable" +
                                    (if (p.hourlyRate > 0) " · ${usd2(p.hourlyRate)}/hr" else "") +
                                    (if (p.ytdPretax > 0) " · ${usd(p.ytdPretax)} pre-tax" else ""),
                                fontSize = 10.sp, color = T.Low)
                        }
                        Text(usd(p.ytdTaxable), fontSize = 14.sp, color = T.Hi)
                        TextButton(onClick = { Pay.delete(ctx, p.periodEnd); tick++ }) {
                            Text("×", fontSize = 16.sp, color = T.Low)
                        }
                    }
                    HorizontalDivider(color = T.Edge.copy(alpha = .4f))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        PayReminderCard { tick++ }
    }
}

@Composable
private fun PayReminderCard(changed: () -> Unit) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Pay.remindersOn(ctx)) }
    var anchor by remember { mutableStateOf(Pay.anchor(ctx)) }
    var every by remember { mutableStateOf(Pay.everyDays(ctx).toString()) }

    TCard("reminders", T.Violet) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Remind me each payday", fontSize = 14.sp, color = T.Hi)
                Text(Pay.nextDue(ctx)?.let { "Next on $it" } ?: "Set a payday below",
                    fontSize = 11.sp, color = T.Low)
            }
            Switch(checked = on, onCheckedChange = {
                on = it; Pay.setRemindersOn(ctx, it)
                if (it) PayScheduler.schedule(ctx) else PayScheduler.cancel(ctx)
                changed()
            })
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(anchor, "A payday (YYYY-MM-DD)", Modifier.weight(2f)) {
                anchor = it
                if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) {
                    Pay.setAnchor(ctx, it)
                    if (on) PayScheduler.schedule(ctx)
                    changed()
                }
            }
            DarkField(every, "Every N days", Modifier.weight(1f), integer = true) {
                every = it
                it.toIntOrNull()?.let { n -> Pay.setEveryDays(ctx, n); changed() }
            }
        }
        Spacer(Modifier.height(8.dp))
        Hint("Any one payday sets the pattern; the rest are counted from it. Miss one and " +
                "nothing breaks — the next LES carries the year-to-date totals forward.")
    }
}

@Composable
private fun SalaryCard(changed: () -> Unit) {
    val ctx = LocalContext.current
    var salary by remember { mutableStateOf(Store.annualSalary(ctx).let {
        if (it <= 0) "" else String.format(Locale.US, "%.2f", it) }) }
    var prior by remember { mutableStateOf(Store.priorSalary(ctx).let {
        if (it <= 0) "" else String.format(Locale.US, "%.2f", it) }) }
    var eff by remember { mutableStateOf(Store.salaryEffective(ctx)) }
    val s = salary.toDoubleOrNull() ?: 0.0
    val year = Store.year()
    val blended = Workdays.blendedAnnualSalary(ctx, year)

    TCard("salary · SF-50", T.Gold) {
        Text("BEFORE — BLOCK 12C", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        DarkField(prior, "Prior adjusted basic pay, if a promotion or PCS changed it",
            Modifier.fillMaxWidth(), numeric = true) {
            prior = it
            Store.setPriorSalary(ctx, it.toDoubleOrNull() ?: 0.0); changed()
        }
        Spacer(Modifier.height(6.dp))
        Hint("Leave blank if this is your only rate for the year. Filled in, the two rates " +
                "are blended by how many scheduled workdays fall on each side of the " +
                "effective date below — not just averaged, since the year splits unevenly.")

        Spacer(Modifier.height(14.dp))
        Text("CURRENT — BLOCK 20C", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        DarkField(salary, "Adjusted basic pay, block 20C", Modifier.fillMaxWidth(),
            numeric = true) {
            salary = it
            Store.setAnnualSalary(ctx, it.toDoubleOrNull() ?: 0.0); changed()
        }
        Spacer(Modifier.height(8.dp))
        DarkField(eff, "Effective date, block 4 (YYYY-MM-DD)", Modifier.fillMaxWidth()) {
            eff = it
            if (it.isBlank() || Regex("\\d{4}-\\d{2}-\\d{2}").matches(it))
                Store.setSalaryEffective(ctx, it); changed()
        }

        if (prior.toDoubleOrNull()?.let { it > 0 } == true && blended > 0 && blended != s) {
            Spacer(Modifier.height(10.dp))
            Text(usd2(blended) + " blended for $year", fontSize = 15.sp,
                fontWeight = FontWeight.Bold, color = T.Hi)
            Spacer(Modifier.height(4.dp))
            Hint("Prior rate through the day before $eff, this rate from it onward, weighted " +
                    "by scheduled workdays on each side. This is what the daily figures below " +
                    "and the dashboard's running total now use — not a flat guess for the " +
                    "whole year at one rate.")
        }

        if (s > 0) {
            // OPM's own divisor: 2,087 hours a year
            val hourly = s / 2087.0
            val worked = Workdays.scheduledWorkdays(ctx, Store.year())
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip(usd2(hourly), "hourly", T.Gold, Modifier.weight(1f))
                StatChip(usd2(hourly * 8), "per paid day", T.Gold, Modifier.weight(1f))
                StatChip(usd2(hourly * 80), "per period", T.Gold, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Hint("OPM's arithmetic: salary over 2,087 hours. A paid day is any weekday you " +
                    "are paid for, holidays included, which is what an LES is built on.")

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip(usd2((if (blended > 0) blended else s) / worked), "per workday",
                    T.Cyan, Modifier.weight(1f))
                StatChip("$worked", "workdays", T.Cyan, Modifier.weight(1f))
                StatChip("${261 - worked}", "holidays", T.Cyan, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Hint("Same salary, fewer slices. You are paid for about 261 weekdays but work " +
                    "$worked of them — the other ${261 - worked} are federal holidays. Virginia " +
                    "only taxes days you worked there, so the app spreads your whole salary " +
                    "over workdays only. The top row is what a day looks like on your LES; " +
                    "this row is what a Pentagon workday is worth for Virginia" +
                    (if (blended > 0 && blended != s) ", blended across the raise" else "") + ".")
        }

        // a rate that started partway through the year, with no prior rate entered
        // to bridge it, is not that year's wages
        if (eff.isNotBlank() && eff.startsWith("${Store.year()}-") &&
            eff > "${Store.year()}-01-01" && (prior.toDoubleOrNull() ?: 0.0) <= 0) {
            Spacer(Modifier.height(14.dp))
            Text("This rate started on $eff, partway through ${Store.year()}.",
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = T.Gold)
            Spacer(Modifier.height(6.dp))
            Hint("Enter the prior rate above and this resolves — the two blend by workdays " +
                    "on each side of $eff instead of guessing. Without it, nothing here " +
                    "multiplies this salary out across the whole year. The dashboard works " +
                    "from your LES year-to-date figures instead, which already carry both " +
                    "rates however they actually fell.")
        }

        Spacer(Modifier.height(12.dp))
        Hint("Block 20C is the new rate — basic pay plus locality. Block 12C is the old one, " +
                "the \"from\" side of the action. A PCS changes your locality partway " +
                "through the year, so this is a rate, not what you will earn in the year: " +
                "for that the LES year-to-date figures below are the real record. Until you " +
                "enter one, the dashboard estimates from this salary instead.")
    }
}

@Composable
private fun WageBaseCard(tick: Int, changed: () -> Unit) {
    val ctx = LocalContext.current
    val year = Store.year()
    // initialised once, not re-keyed to tick: a field that rebuilds its own
    // remembered state every time its own onChange fires races the keyboard's
    // composing buffer and corrupts what is being typed — that is exactly what
    // produced 155353 turning into 1555353 and every decimal point vanishing.
    // An external change (the projection button below) still needs to reach
    // this field, so a LaunchedEffect resyncs it — but only on a tick this
    // field's own typing no longer causes.
    var base by remember { mutableStateOf(Store.grossWages(ctx).let {
        if (it <= 0) "" else fmtNum(it) }) }
    LaunchedEffect(tick) {
        val fresh = Store.grossWages(ctx)
        val shown = if (fresh <= 0) "" else fmtNum(fresh)
        if (shown != base) base = shown
    }
    val used = Workdays.rateSource(ctx, year)
    val suspect = Workdays.rateLooksWrong(ctx, year)

    TCard("wage base for the allocation", if (suspect) T.Danger else T.Edge) {
        Text(usd(used), fontSize = 26.sp, fontWeight = FontWeight.Bold,
            color = if (suspect) T.Danger else T.Hi)
        var paid by remember { mutableStateOf(Workdays.usePaidDays(ctx)) }
        val divisor = Workdays.rateDivisor(ctx, year)
        Text("divided by " +
                (if (paid) "260.9 paid days" else "${divisor.toInt()} worked days") +
                " = " + usd2(Workdays.dailyRate(ctx, year)) + " a day",
            fontSize = 12.sp, color = T.Mid)

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(false to "${Workdays.scheduledWorkdays(ctx, year)} worked days",
                   true to "261 paid days").forEach { (v, label) ->
                val on = paid == v
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                        .background(if (on) T.Cyan.copy(alpha = .18f) else T.Glow)
                        .border(1.dp, if (on) T.Cyan else T.Edge, RoundedCornerShape(9.dp))
                        .clickable { paid = v; Workdays.setUsePaidDays(ctx, v); changed() }
                        .padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 12.sp, color = if (on) T.Cyan else T.Mid,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Hint(
            if (paid) "Paid days include the holidays, so this matches one day on your LES. " +
                    "The dashboard figure will sit about 4% under the worksheet, which always " +
                    "allocates by days worked."
            else "Worked days leave the holidays out, so the dashboard agrees with the " +
                    "worksheet. This changes the daily figure shown, never the allocation."
        )
        Spacer(Modifier.height(4.dp))
        Text("source: " + Workdays.rateBasis(ctx, year), fontSize = 11.sp, color = T.Low)

        if (suspect) {
            Spacer(Modifier.height(10.dp))
            Text("This is well below your SF-50 salary.", fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold, color = T.Danger)
            Spacer(Modifier.height(4.dp))
            Hint("Usually a figure left over from trying the screen out. Clear it below, and " +
                    "delete any test entries from the record, and the app will fall back to " +
                    "your LES figures or your salary.")
        }

        Spacer(Modifier.height(14.dp))
        DarkField(base, "Set it by hand — W-2 Box 1", Modifier.fillMaxWidth(), numeric = true) {
            // no changed() here — nothing on this screen needs to react while
            // this exact field is being typed into, and calling it here is
            // what caused the corruption
            base = it
            Store.setGrossWages(ctx, it.toDoubleOrNull() ?: 0.0)
        }
        Spacer(Modifier.height(8.dp))
        GhostBtn("Clear it and use my LES or salary", color = T.Mid) {
            Store.setGrossWages(ctx, 0.0); base = ""; changed()
        }
        Spacer(Modifier.height(10.dp))
        Hint("Left empty, the app uses what your LES entries project for the year, and falls " +
                "back to the SF-50 salary if there are none. Set it explicitly once the W-2 " +
                "arrives, which is the figure Virginia actually taxes.")
    }
}

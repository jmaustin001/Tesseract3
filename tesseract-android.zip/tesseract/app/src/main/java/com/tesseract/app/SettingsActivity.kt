package com.tesseract.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { SettingsScreen() } }
    }
    fun restartSetup() { startActivity(Intent(this, OnboardingActivity::class.java)); finish() }
}

@Composable
private fun SettingsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }

    var hours by remember { mutableStateOf(Store.checkHours(ctx).joinToString(", ")) }
    var s1 by remember { mutableStateOf(Store.soft1(ctx).toString()) }
    var s2 by remember { mutableStateOf(Store.soft2(ctx).toString()) }
    var hard by remember { mutableStateOf(Store.hard(ctx).toString()) }
    var limit by remember { mutableStateOf(Store.limit(ctx).toString()) }
    var confirmReset by remember { mutableStateOf(false) }

    val next = remember(hours, tick) {
        SimpleDateFormat("EEE HH:mm", Locale.US).format(Date(Scheduler.nextCheckTime(ctx)))
    }
    val pm = ctx.getSystemService(PowerManager::class.java)
    val unrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)

    TessScreen("Settings", "states · schedule · warnings") {

        TCard("states", T.Gold) {
            StateRow("Counting days in", Store.countedState(ctx), T.Gold) {
                Store.setCountedState(ctx, it); tick++
            }
            Spacer(Modifier.height(14.dp))
            StateRow("Claimed home state", Store.homeState(ctx), T.Teal) {
                Store.setHomeState(ctx, it); tick++
            }
            Spacer(Modifier.height(12.dp))
            Hint("Change the counted state when you PCS and every total, warning and report " +
                    "follows it. The warning stages reset so the new state starts clean.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("schedule", T.Cyan) {
            DarkField(hours, "Check at these hours", Modifier.fillMaxWidth()) {
                hours = it
                val p = it.split(",").mapNotNull { h -> h.trim().toIntOrNull() }.filter { h -> h in 0..23 }
                if (p.isNotEmpty()) { Store.setCheckHours(ctx, p); Scheduler.scheduleNextCheck(ctx); tick++ }
            }
            Spacer(Modifier.height(8.dp))
            Hint("Next check: $next. Four a day is the default — more costs battery and buys " +
                    "nothing, since a day counts the same whether you were seen once or ten times.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Check now") { Scheduler.checkNow(ctx) }
        }

        Spacer(Modifier.height(10.dp))
        TCard("warning stages", T.Danger) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DarkField(s1, "Soft 1", Modifier.weight(1f), integer = true) {
                    s1 = it; it.toIntOrNull()?.let { v -> Store.setSoft1(ctx, v) } }
                DarkField(s2, "Soft 2", Modifier.weight(1f), integer = true) {
                    s2 = it; it.toIntOrNull()?.let { v -> Store.setSoft2(ctx, v) } }
                DarkField(hard, "Hard", Modifier.weight(1f), integer = true) {
                    hard = it; it.toIntOrNull()?.let { v -> Store.setHard(ctx, v) } }
                DarkField(limit, "Limit", Modifier.weight(1f), integer = true) {
                    limit = it; it.toIntOrNull()?.let { v -> Store.setLimit(ctx, v) } }
            }
            Spacer(Modifier.height(10.dp))
            Hint("Each stage fires once per calendar year. The hard warning sits short of the " +
                    "limit on purpose, so there is still room to change plans when it lands.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("tracking health", if (unrestricted) T.Teal else T.Danger) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Battery unrestricted", fontSize = 14.sp, color = T.Hi, modifier = Modifier.weight(1f))
                Text(if (unrestricted) "OK" else "NEEDS ATTENTION", fontSize = 11.sp,
                    fontWeight = FontWeight.Bold, color = if (unrestricted) T.Teal else T.Danger)
            }
            if (!unrestricted) {
                Spacer(Modifier.height(12.dp))
                PrimaryBtn("Exempt from battery optimization", accent = T.Danger) {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${ctx.packageName}")))
                }
            }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Allow location all the time") {
                (ctx as? ComponentActivity)?.let { }
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${ctx.packageName}")))
            }
            Spacer(Modifier.height(12.dp))
            Hint("In app settings, turn OFF \"Pause app activity if unused\". Android hibernates " +
                    "apps it thinks you have abandoned and revokes their permissions — and this " +
                    "app is built to be opened rarely, which is exactly what trips it.")
            Spacer(Modifier.height(10.dp))
            Hint("Cost: four checks a day, about a second each, on the low-power network fix " +
                    "rather than the GPS chip. No background service, no wake locks. Asleep the " +
                    "rest of the time.")
        }

        Spacer(Modifier.height(10.dp))
        PcsCard()

        Spacer(Modifier.height(10.dp))
        TextSizeCard()

        Spacer(Modifier.height(10.dp))
        CategoriesCard()

        Spacer(Modifier.height(10.dp))
        ReconstructCard { }

        Spacer(Modifier.height(10.dp))
        PayPeriodCard()

        Spacer(Modifier.height(10.dp))
        WorkScheduleCard()

        Spacer(Modifier.height(10.dp))
        DutyHoursCard()

        Spacer(Modifier.height(10.dp))
        NewPlacesCard()

        Spacer(Modifier.height(10.dp))
        TravelCard()

        Spacer(Modifier.height(10.dp))
        UpdateCard()

        Spacer(Modifier.height(10.dp))
        TCard("setup", T.Low) {
            if (!confirmReset) {
                GhostBtn("Run setup again", color = T.Mid) { confirmReset = true }
            } else {
                Hint("Setup walks through datums, states and thresholds again.")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Keep my log", Modifier.weight(1f)) {
                        Store.resetSetup(ctx, eraseLog = false)
                        (ctx as? SettingsActivity)?.restartSetup()
                    }
                    GhostBtn("Erase all", Modifier.weight(1f), color = T.Danger) {
                        Store.resetSetup(ctx, eraseLog = true)
                        (ctx as? SettingsActivity)?.restartSetup()
                    }
                }
                Spacer(Modifier.height(6.dp))
                GhostBtn("Cancel", color = T.Low) { confirmReset = false }
            }
        }
    }
}

@Composable
private fun StateRow(label: String, selected: String, accent: androidx.compose.ui.graphics.Color,
                     onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        Text(label.uppercase(), fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
                .background(T.Glow).border(1.dp, accent.copy(alpha = .4f), RoundedCornerShape(11.dp))
                .clickable { open = true }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(selected, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = accent)
            Spacer(Modifier.width(10.dp))
            Text(States.fullName(selected), fontSize = 14.sp, color = T.Mid, modifier = Modifier.weight(1f))
            Text("▾", color = T.Mid, fontSize = 13.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false },
            modifier = Modifier.background(T.Deep)) {
            States.all.forEach { s ->
                DropdownMenuItem(
                    text = { Text("$s · ${States.fullName(s)}", color = T.Hi, fontSize = 14.sp) },
                    onClick = { onPick(s); open = false }
                )
            }
        }
    }
}

@Composable
private fun UpdateCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var repo by remember { mutableStateOf(Store.updateRepo(ctx)) }
    var state by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Updater.Release?>(null) }
    var history by remember { mutableStateOf<List<Updater.Release>>(emptyList()) }
    var showHistory by remember { mutableStateOf(false) }

    fun grab(rel: Updater.Release) {
        busy = true; state = ""; bad = false
        scope.launch {
            val d = Updater.download(ctx, rel)
            busy = false
            d.fold(
                onSuccess = { Updater.install(ctx, it) },
                onFailure = { state = it.message ?: "Download failed."; bad = true }
            )
        }
    }

    TCard("updates", if (found != null) T.Cyan else T.Edge) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Installed", fontSize = 14.sp, color = T.Hi)
                Text("Every build carries its own number, so you always know exactly " +
                        "what is running.", fontSize = 11.sp, color = T.Low, lineHeight = 14.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(BuildConfig.VERSION_NAME, fontSize = 17.sp,
                    fontWeight = FontWeight.Bold, color = T.Cyan)
                Text("build ${BuildConfig.VERSION_CODE}", fontSize = 10.sp, color = T.Low)
            }
        }

        Spacer(Modifier.height(14.dp))
        if (found == null) {
            PrimaryBtn(if (busy) "Checking…" else "Check for updates") {
                if (busy) return@PrimaryBtn
                busy = true; state = ""; bad = false
                scope.launch {
                    val r = Updater.check(ctx)
                    busy = false
                    r.fold(
                        onSuccess = { rel ->
                            if (rel == null) state = "You are on the latest build."
                            else found = rel
                        },
                        onFailure = { state = it.message ?: "Check failed."; bad = true }
                    )
                }
            }
        } else {
            val rel = found!!
            Text(rel.label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
            Text("published ${rel.published}", fontSize = 11.sp, color = T.Low)
            if (rel.notes.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Hint(rel.notes)
            }
            Spacer(Modifier.height(12.dp))
            PrimaryBtn(if (busy) "Downloading…" else "Download and install") { grab(rel) }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Not now", color = T.Low) { found = null }
        }

        if (state.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(state, fontSize = 12.sp, color = if (bad) T.Danger else T.Teal)
        }

        /* ---- rollback ---- */
        Spacer(Modifier.height(14.dp))
        if (!showHistory) {
            GhostBtn("Earlier builds", color = T.Mid) {
                showHistory = true
                scope.launch {
                    Updater.history(ctx).fold(
                        onSuccess = { history = it },
                        onFailure = { state = it.message ?: "Could not list builds."; bad = true }
                    )
                }
            }
        } else {
            Text("EARLIER BUILDS", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            if (history.isEmpty()) {
                Hint("Loading…")
            } else history.forEach { r ->
                val current = r.build == BuildConfig.VERSION_CODE
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.label, fontSize = 14.sp,
                            fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                            color = if (current) T.Cyan else T.Hi)
                        Text(r.published, fontSize = 10.sp, color = T.Low)
                    }
                    if (current) Text("RUNNING", fontSize = 9.sp, color = T.Cyan,
                        fontWeight = FontWeight.Bold)
                    else TextButton(onClick = { grab(r) }) {
                        Text("Install", fontSize = 12.sp, color = T.Mid)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            GhostBtn("Hide", color = T.Low) { showHistory = false }
        }

        Spacer(Modifier.height(12.dp))
        Hint("Going back a build: Android will not install an older build over a newer one, " +
                "so a rollback means uninstalling first — which wipes your log. Save a backup " +
                "from the Reports screen before you do it, then restore after. Moving forward " +
                "never needs any of that; it installs straight over the top and keeps everything.")

        Spacer(Modifier.height(12.dp))
        DarkField(repo, "Update source (owner/repo)", Modifier.fillMaxWidth()) {
            repo = it; Store.setUpdateRepo(ctx, it)
        }
        Spacer(Modifier.height(8.dp))
        Hint("Reads the release listing from that public repository. Your log is never " +
                "uploaded — nothing leaves the phone but the request for a version number.")
    }
}

@Composable
private fun PcsCard() {
    val ctx = LocalContext.current
    var date by remember { mutableStateOf(Store.pcsDate(ctx)) }
    val valid = Regex("\\d{4}-\\d{2}-\\d{2}").matches(date)
    val today = Store.today()
    val year = Store.year()
    val counted = Store.countedState(ctx)
    val home = Store.homeState(ctx)

    TCard("pcs", T.Violet) {
        DarkField(date, "PCS date (YYYY-MM-DD)", Modifier.fillMaxWidth()) {
            date = it
            if (it.isBlank() || Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) Store.setPcsDate(ctx, it)
        }

        if (valid) {
            Spacer(Modifier.height(12.dp))
            val before = Store.stateDaysBefore(ctx, counted, year, date)
            val after = Store.stateDaysFrom(ctx, counted, year, date)
            val homeBefore = Store.stateDaysBefore(ctx, home, year, date)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("$homeBefore", "$home · pre-PCS", T.Teal, Modifier.weight(1f))
                StatChip("$before", "$counted · pre-PCS", T.Low, Modifier.weight(1f))
                StatChip("$after", "$counted · post-PCS", T.Gold, Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))
            if (today < date) {
                val remaining = daysBetween(today, date)
                Text("$remaining days until the move", fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold, color = T.Hi)
                val possible = daysBetween(date, "$year-12-31") + 1
                Spacer(Modifier.height(6.dp))
                Hint("Moving on $date leaves at most $possible days in ${States.fullName(counted)} " +
                        "this calendar year — below the ${Store.limit(ctx)} limit even if you never " +
                        "leave. The year of the move is nearly always safe. The first full year is " +
                        "the one this log exists for.")
            } else {
                Hint("Reports now split either side of $date, so the partial year reads as a " +
                        "partial year instead of looking like a light one.")
            }
        } else {
            Spacer(Modifier.height(10.dp))
            Hint("Set the date the duty station changes. Counting stays per calendar year — " +
                    "that is how the law works — but every report splits before and after, so " +
                    "nobody reads a half-year at the new station as a full one.")
        }
    }
}

private fun daysBetween(a: String, b: String): Int = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    Math.round((f.parse(b)!!.time - f.parse(a)!!.time) / 86_400_000.0).toInt()
} catch (e: Exception) { 0 }

@Composable
private fun TravelCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val unresolved = remember(tick) { Store.unresolvedCount(ctx) }

    TCard("travel and TDY", if (unresolved > 0) T.Gold else T.Edge) {
        Hint("TDY anywhere works without setup: a fix outside every datum records the " +
                "state or country it landed in, prompts you to label the day, and gives you " +
                "a note field for the orders number. You only need a datum for places you " +
                "return to often enough to want counted separately.")

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Fixes with no location resolved", fontSize = 14.sp, color = T.Hi,
                modifier = Modifier.weight(1f))
            Text("$unresolved", fontSize = 16.sp, fontWeight = FontWeight.Bold,
                color = if (unresolved > 0) T.Gold else T.Teal)
        }
        Spacer(Modifier.height(6.dp))
        Hint("Overseas with data off, the coordinates still get logged but the country " +
                "cannot be looked up. Run this on wifi afterwards and they fill themselves in.")

        if (unresolved > 0) {
            Spacer(Modifier.height(12.dp))
            PrimaryBtn(if (busy) "Resolving…" else "Resolve $unresolved unknown", accent = T.Gold) {
                if (busy) return@PrimaryBtn
                busy = true; msg = ""
                scope.launch {
                    val n = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        Store.resolveUnknowns(ctx) { la, lo -> Fixer.resolveState(ctx, la, lo) }
                    }
                    busy = false; tick++
                    msg = if (n > 0) "Resolved $n." else "Still no answer — try again on wifi."
                }
            }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }

        Spacer(Modifier.height(12.dp))
        Hint("A VPN does not move your position — that comes from satellites, wifi and " +
                "cell towers, none of which care how your traffic is routed. It can break " +
                "the state lookup though, since that is a network call, which is a common " +
                "reason for fixes landing here. Turn it off for a moment and resolve them.")

        Spacer(Modifier.height(12.dp))
        Hint("Foreign days are recorded as three-letter country codes — DEU, JPN, KOR — " +
                "which can never be mistaken for a US state. A two-letter scheme would read " +
                "Valencia as VA and invent Virginia days.")
    }
}

private fun hhmm(min: Int) = "%02d:%02d".format(min / 60, min % 60)
private fun parseHhmm(v: String): Int? {
    val p = v.split(":")
    if (p.size != 2) return null
    val h = p[0].trim().toIntOrNull() ?: return null
    val m = p[1].trim().toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h * 60 + m
}

@Composable
private fun DutyHoursCard() {
    val ctx = LocalContext.current
    var start by remember { mutableStateOf(hhmm(Store.dutyStart(ctx))) }
    var end by remember { mutableStateOf(hhmm(Store.dutyEnd(ctx))) }
    var tick by remember { mutableIntStateOf(0) }

    val s = parseHhmm(start); val e = parseHhmm(end)
    val hours = remember(tick) { Store.checkHours(ctx) }
    val covered = remember(tick, start, end) {
        s != null && e != null && 1 < hours.count {
            val m = it * 60
            if (s <= e) m in s..e else (m >= s || m <= e)
        }
    }

    TCard("duty hours", if (covered) T.Edge else T.Gold) {
        Hint("Which state earned the day is decided by the fixes taken while you were " +
                "on the clock. Flying home at 1700 does not move the day's wages; being " +
                "somewhere else at 1000 does.")
        Spacer(Modifier.height(8.dp))
        Hint("One exception: a day that touched your duty station, and never went further " +
                "than the local area below during duty hours, is normal duty there — a " +
                "meeting in DC that the 12:00 check happens to catch does not move the day.")
        Spacer(Modifier.height(12.dp))
        LocalAreaField()

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(start, "Start (HH:MM)", Modifier.weight(1f)) {
                start = it; parseHhmm(it)?.let { m -> Store.setDutyStart(ctx, m); tick++ }
            }
            DarkField(end, "End (HH:MM)", Modifier.weight(1f)) {
                end = it; parseHhmm(it)?.let { m -> Store.setDutyEnd(ctx, m); tick++ }
            }
        }

        Spacer(Modifier.height(12.dp))
        val inWindow = if (s == null || e == null) emptyList() else hours.filter {
            val m = it * 60
            if (s <= e) m in s..e else (m >= s || m <= e)
        }

        // Two points inside the window turn a guess into a reading: a morning in one
        // state and an afternoon in another becomes visible rather than inferred.
        val wanted = if (s == null || e == null) emptyList() else
            listOf((s + 120) / 60, (e - 60) / 60).map { ((it % 24) + 24) % 24 }.distinct()
        val missing = wanted.filterNot { it in hours }

        when {
            inWindow.isEmpty() -> Text("No check falls inside your duty hours.",
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = T.Gold)
            inWindow.size == 1 -> Text("One check inside duty hours: " +
                    "%02d:00".format(inWindow.first()),
                fontSize = 13.sp, color = T.Gold)
            else -> Text("Checks inside duty hours: " +
                    inWindow.joinToString(", ") { "%02d:00".format(it) },
                fontSize = 13.sp, color = T.Teal)
        }

        if (inWindow.size < 2) {
            Spacer(Modifier.height(6.dp))
            Hint("One reading has to stand for the whole day. Two means a morning in one " +
                    "state and an afternoon in another shows up as a split you can see and " +
                    "correct, instead of the app quietly picking one.")
        }

        if (missing.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            PrimaryBtn(
                "Add " + missing.joinToString(" and ") { "%02d:00".format(it) },
                accent = T.Gold
            ) {
                Store.setCheckHours(ctx, (hours + missing).distinct().sorted())
                Scheduler.scheduleNextCheck(ctx)
                tick++
            }
            Spacer(Modifier.height(6.dp))
            Hint("Six checks a day instead of four. The difference in battery is not " +
                    "measurable — each one is about a second on the low-power fix.")
        }

        Spacer(Modifier.height(12.dp))
        Hint("Night shifts work too — a window like 22:00 to 06:00 wraps past midnight.")
    }
}

private val DOW = listOf(
    java.util.Calendar.SUNDAY to "Sun", java.util.Calendar.MONDAY to "Mon",
    java.util.Calendar.TUESDAY to "Tue", java.util.Calendar.WEDNESDAY to "Wed",
    java.util.Calendar.THURSDAY to "Thu", java.util.Calendar.FRIDAY to "Fri",
    java.util.Calendar.SATURDAY to "Sat"
)

@Composable
private fun WorkScheduleCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }

    val days = remember(tick) { Store.workWeekdays(ctx) }
    val holidays = remember(tick) { Store.observeHolidays(ctx) }
    var rdoOn by remember { mutableStateOf(Store.rdoOn(ctx)) }
    var rdoDay by remember { mutableIntStateOf(Store.rdoWeekday(ctx)) }
    var rdoWeeks by remember { mutableStateOf(Store.rdoWeeks(ctx).toString()) }
    var rdoAnchor by remember { mutableStateOf(Store.rdoAnchor(ctx)) }

    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    fun saveRdo() = Store.setRdo(ctx, rdoOn, rdoDay, rdoWeeks.toIntOrNull() ?: 2, rdoAnchor.trim())

    TCard("work schedule", T.Teal) {
        Hint("This decides which days earned money. It has nothing to do with the 183-day " +
                "residency count — a Saturday in Virginia still counts toward that.")

        Spacer(Modifier.height(14.dp))
        Text("DUTY DAYS", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DOW.forEach { (num, label) ->
                val on = num in days
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                        .background(if (on) T.Teal.copy(alpha = .20f) else T.Glow)
                        .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(8.dp))
                        .clickable {
                            val next = if (on) days - num else days + num
                            Store.setWorkWeekdays(ctx, next); tick++
                        }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 10.sp, color = if (on) T.Teal else T.Low,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Federal holidays off", fontSize = 14.sp, color = T.Hi)
                Text("All eleven, with the weekend observed shift",
                    fontSize = 11.sp, color = T.Low)
            }
            Switch(checked = holidays, onCheckedChange = {
                Store.setObserveHolidays(ctx, it); tick++
            })
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Regular day off", fontSize = 14.sp, color = T.Hi)
                Text("The every-other-Friday of a 5-4-9 or Maxiflex",
                    fontSize = 11.sp, color = T.Low)
            }
            Switch(checked = rdoOn, onCheckedChange = { rdoOn = it; saveRdo(); tick++ })
        }

        if (rdoOn) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DOW.drop(1).take(5).forEach { (num, label) ->
                    val on = rdoDay == num
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(if (on) T.Gold.copy(alpha = .20f) else T.Glow)
                            .border(1.dp, if (on) T.Gold else T.Edge, RoundedCornerShape(8.dp))
                            .clickable { rdoDay = num; saveRdo(); tick++ }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, fontSize = 10.sp, color = if (on) T.Gold else T.Low,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(rdoWeeks, "Every N weeks", Modifier.weight(1f), integer = true) {
                    rdoWeeks = it; saveRdo(); tick++
                }
                DarkField(rdoAnchor, "A date you had off", Modifier.weight(2f)) {
                    rdoAnchor = it
                    if (it.isBlank() || Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) { saveRdo(); tick++ }
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Put any one of your days off in the date box and the pattern counts " +
                    "outward from there, forwards and backwards. Leave it blank to treat " +
                    "every one of those weekdays as off.")
        }

        Spacer(Modifier.height(18.dp))
        Text("MARK A STRETCH", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(from, "From (YYYY-MM-DD)", Modifier.weight(1f)) { from = it }
            DarkField(to, "To (YYYY-MM-DD)", Modifier.weight(1f)) { to = it }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GhostBtn("Worked", Modifier.weight(1f), color = T.Gold) {
                val n = Store.setWorkOverrideRange(ctx, from, to, Store.WORKED)
                msg = if (n > 0) "$n days marked worked." else "Check those dates."
            }
            GhostBtn("Day off", Modifier.weight(1f), color = T.Teal) {
                val n = Store.setWorkOverrideRange(ctx, from, to, Store.OFF)
                msg = if (n > 0) "$n days marked off." else "Check those dates."
            }
            GhostBtn("Clear", Modifier.weight(1f), color = T.Low) {
                val n = Store.setWorkOverrideRange(ctx, from, to, null)
                msg = if (n > 0) "$n days back to automatic." else "Check those dates."
            }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }
        Spacer(Modifier.height(8.dp))
        Hint("A leave block or a TDY run in one go. Manual marks always beat the rules " +
                "above, and the CSV records that a person set them.")
    }
}

@Composable
private fun NewPlacesCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var hours by remember { mutableStateOf(Store.dwellHours(ctx).toString()) }
    var radius by remember { mutableStateOf(Store.dwellRadius(ctx).toInt().toString()) }
    val ignored = remember(tick) { DwellWatch.suppressedCount(ctx) }

    TCard("new places", T.Violet) {
        Hint("When you settle somewhere the app does not know, it offers to add a datum. " +
                "Passing through does not count — airports and highway stops would fire " +
                "constantly — so it waits until the fixes stay in one area for long enough " +
                "to mean you actually stopped.")

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(hours, "Hours in one place", Modifier.weight(1f), integer = true) {
                hours = it; it.toIntOrNull()?.let { v -> Store.setDwellHours(ctx, v); tick++ }
            }
            DarkField(radius, "Within (miles)", Modifier.weight(1f), numeric = true) {
                radius = it
                it.toDoubleOrNull()?.let { v -> Store.setDwellRadius(ctx, v); tick++ }
            }
        }
        Spacer(Modifier.height(8.dp))
        Hint("Set hours to 0 to switch the prompt off entirely.")

        if (ignored > 0) {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Places you said no to", fontSize = 14.sp, color = T.Hi,
                    modifier = Modifier.weight(1f))
                Text("$ignored", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = T.Mid)
            }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Ask about them again", color = T.Mid) {
                DwellWatch.clearSuppressed(ctx); tick++
            }
        }
    }
}

@Composable
private fun TextSizeCard() {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(Store.textScale(ctx)) }

    TCard("text size", T.Cyan) {
        Hint("Scales every word in the app. Sits on top of your phone's own font " +
                "setting rather than replacing it.")
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0.9f to "Small", 1.0f to "Normal", 1.15f to "Large", 1.3f to "Larger")
                .forEach { (v, label) ->
                    val on = kotlin.math.abs(scale - v) < 0.01f
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (on) T.Cyan.copy(alpha = .18f) else T.Glow)
                            .border(1.dp, if (on) T.Cyan else T.Edge, RoundedCornerShape(9.dp))
                            .clickable { scale = v; Store.setTextScale(ctx, v) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, fontSize = 12.sp, color = if (on) T.Cyan else T.Mid,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
        }
        Spacer(Modifier.height(10.dp))
        Hint("Leave this screen and come back to see it applied. The year grid also " +
                "pinches to zoom on its own.")
    }
}


@Composable
private fun CategoriesCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf("") }
    val saved = remember(tick) { Store.customCategories(ctx) }
    val colors = remember(tick) { Store.customColors(ctx) }
    var newColor by remember(tick) { mutableIntStateOf(Store.nextFreeColor(ctx)) }
    var picking by remember { mutableStateOf<String?>(null) }

    TCard("your categories", CustomPink) {
        Hint("The five built-in categories cannot be changed — they map onto duty status " +
                "and place, which is what the reports are built on. Anything else you need " +
                "lives here and appears on the categorize screen alongside them.")

        if (saved.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            saved.forEach { c ->
                val col = androidx.compose.ui.graphics.Color(colors[c] ?: Store.categoryPalette[0])
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(RoundedCornerShape(5.dp)).background(col)
                        .clickable { picking = if (picking == c) null else c })
                    Spacer(Modifier.width(10.dp))
                    Text(c, fontSize = 14.sp, color = T.Hi, modifier = Modifier.weight(1f))
                    TextButton(onClick = { Store.removeCustomCategory(ctx, c); tick++ }) {
                        Text("Remove", fontSize = 11.sp, color = T.Low)
                    }
                }
                if (picking == c) {
                    Swatches(colors[c] ?: 0) { argb ->
                        Store.setCustomColor(ctx, c, argb); picking = null; tick++
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Tap a color square to change it. Removing a category leaves days already " +
                    "labeled with it untouched.")
        }

        Spacer(Modifier.height(14.dp))
        DarkField(adding, "Add a category", Modifier.fillMaxWidth()) { adding = it }
        Spacer(Modifier.height(8.dp))
        Text("ITS COLOR ON THE YEAR VIEW", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Swatches(newColor) { newColor = it }
        Spacer(Modifier.height(10.dp))
        PrimaryBtn("Add", accent = androidx.compose.ui.graphics.Color(newColor)) {
            if (adding.isNotBlank()) {
                Store.addCustomCategory(ctx, adding)
                Store.setCustomColor(ctx, adding, newColor)
                adding = ""; tick++
            }
        }

        Spacer(Modifier.height(12.dp))
        Hint("Two telework categories are there to begin with. They are ordinary entries — " +
                "rename or remove them like any other.")

        Spacer(Modifier.height(10.dp))
        Hint("Worth keeping them apart: a category like " +
                "\"Residence — TS telework situational\" separates those days from ordinary " +
                "leave at the residence, and they are very different things. One earned " +
                "wages in Florida; the other earned nothing anywhere.")
    }
}

private val CustomPink = androidx.compose.ui.graphics.Color(0xFFFF4FA3)

@Composable
private fun PayPeriodCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var anchor by remember { mutableStateOf(PayPeriods.anchor(ctx)) }
    var number by remember { mutableStateOf(PayPeriods.anchorNumber(ctx).let {
        if (it <= 0) "" else it.toString() }) }
    var need by remember { mutableStateOf(PayPeriods.required(ctx).toString()) }
    val list = remember(tick) { PayPeriods.periods(ctx) }

    TCard("pay periods and locality", T.Cyan) {
        Hint("To keep an official worksite — and the locality pay tied to it — you have " +
                "to physically report there at least twice each biweekly pay period, on a " +
                "regular and recurring basis. Each period is counted on its own.")

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(anchor, "A pay period start", Modifier.weight(2f)) {
                anchor = it
                if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) {
                    PayPeriods.setAnchor(ctx, it); tick++
                }
            }
            DarkField(number, "PP no. (blank = official)", Modifier.weight(1f), integer = true) {
                number = it
                PayPeriods.setAnchorNumber(ctx, it.toIntOrNull() ?: 0); tick++
            }
        }
        Spacer(Modifier.height(8.dp))
        DarkField(need, "Office days required per period", Modifier.fillMaxWidth(),
            integer = true) {
            need = it
            it.toIntOrNull()?.let { n -> PayPeriods.setRequired(ctx, n); tick++ }
        }
        Spacer(Modifier.height(8.dp))
        Hint("Any one period start lines the rest up. Pay periods are biweekly — 26 a " +
                "year, numbered from the first one that starts in January, the way the LES " +
                "numbers them — not two per calendar month. Leave the PP no. blank to use that " +
                "count; type one only if your LES disagrees.")

        if (list.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            list.take(8).forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.label, fontSize = 13.sp, color = T.Hi)
                        if (p.trumps.isNotBlank())
                            Text(p.trumps + (if (p.verdict == PayPeriods.Verdict.EXEMPT)
                                    " — covers the requirement" else ""),
                                fontSize = 10.sp, color = T.Violet)
                    }
                    Text("${p.officeDays}/${p.required}", fontSize = 14.sp,
                        fontWeight = FontWeight.Bold, color = T.Hi)
                    Spacer(Modifier.width(10.dp))
                    val (word, col) = when (p.verdict) {
                        PayPeriods.Verdict.MET -> "met" to T.Teal
                        PayPeriods.Verdict.SHORT -> "short" to T.Danger
                        PayPeriods.Verdict.EXEMPT -> "covered" to T.Violet
                        PayPeriods.Verdict.IN_PROGRESS -> "open" to T.Gold
                    }
                    Text(word.uppercase(), fontSize = 9.sp,
                        fontWeight = FontWeight.Bold, color = col)
                }
            }
            Spacer(Modifier.height(8.dp))
            Hint("A day counts as in the office when it is categorized Duty Station, or — if " +
                    "left uncategorized — when a workday fix lands inside a duty-station datum. " +
                    "A day categorized as travel, TDY, leave or telework never counts, wherever " +
                    "the phone happened to be. A period shows COVERED when days on orders " +
                    "(TDY) or leave left fewer scheduled workdays than the requirement — a " +
                    "temporary situation does not move your worksite, though your agency makes " +
                    "that call. One short period is not a change of worksite; a run of them is " +
                    "the thing to avoid.")
        }
    }
}


@Composable
private fun LocalAreaField() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(fmtNum(Store.localAreaMiles(ctx))) }
    var msg by remember { mutableStateOf("") }
    val v = text.toDoubleOrNull()
    val dirty = v != null && v != Store.localAreaMiles(ctx)
    Row(verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DarkField(text, "Local area around duty station (mi)", Modifier.weight(1f), numeric = true) {
            text = it; msg = ""
        }
        PrimaryBtn("Save", Modifier.width(96.dp), accent = if (dirty) T.Gold else T.Edge) {
            val n = text.toDoubleOrNull()
            if (n == null || n < 0) { msg = "Enter miles, e.g. 10 or 7.5."; return@PrimaryBtn }
            Store.setLocalAreaMiles(ctx, n)
            text = fmtNum(n); msg = "Saved. Every day is re-read with it."
        }
    }
    if (msg.isNotBlank()) {
        Spacer(Modifier.height(4.dp))
        Text(msg, fontSize = 12.sp, color = if (msg.startsWith("Saved")) T.Teal else T.Gold)
    }
    Spacer(Modifier.height(4.dp))
    Hint("Measured from the duty-station datum's center. 10 mi from the Pentagon takes in " +
            "the District, Crystal City, Rosslyn and Alexandria but not Fort Meade or Quantico. " +
            "0 means only fixes inside the datum itself count.")
}


/** The category palette as tappable squares; the chosen one is ringed. */
@Composable
private fun Swatches(selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Store.categoryPalette.forEach { argb ->
            val on = argb == selected
            Box(
                Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
                    .border(if (on) 3.dp else 1.dp, if (on) T.Hi else T.Edge, RoundedCornerShape(8.dp))
                    .padding(if (on) 5.dp else 3.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(androidx.compose.ui.graphics.Color(argb))
                    .clickable { onPick(argb) }
            )
        }
    }
}

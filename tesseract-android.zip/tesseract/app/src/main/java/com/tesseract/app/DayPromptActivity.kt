package com.tesseract.app

import android.app.NotificationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A notification can only show three buttons. This is the full five-way picker,
 * opened by tapping the notification body, with a free-text note for orders numbers.
 */
class DayPromptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val date = intent.getStringExtra("date") ?: Store.today()
        val summary = intent.getStringExtra("summary") ?: ""
        val guess = intent.getStringExtra("guess") ?: Status.DUTY

        setContent {
            TessTheme {
                var note by remember { mutableStateOf(Store.statusOf(this, date).second) }
                val existing = Store.statusOf(this, date).first
                var chosen by remember { mutableStateOf(existing.ifBlank { guess }) }
                var bump by remember { mutableIntStateOf(0) }
                var customOn by remember { mutableStateOf(Status.isCustom(existing)) }
                var customText by remember {
                    mutableStateOf(if (Status.isCustom(existing)) existing else "")
                }
                // a day that has not happened yet: ask once before anything is entered
                var futureOk by remember { mutableStateOf(!Store.isFuture(date)) }
                if (!futureOk) {
                    AlertDialog(
                        containerColor = T.Deep,
                        onDismissRequest = { finish() },
                        title = { Text("$date hasn't happened yet", color = T.Hi) },
                        text = {
                            Text("Today is ${Store.today()}. Anything entered for a future day " +
                                    "goes into the record as if it happened. Planned leave or " +
                                    "orders are fine to enter ahead; anything else, wait for the day.",
                                color = T.Mid, fontSize = 13.sp)
                        },
                        confirmButton = {
                            TextButton(onClick = { futureOk = true }) {
                                Text("Yes, enter a future day", color = T.Gold)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { finish() }) { Text("Go back") }
                        }
                    )
                }

                Column(
                    Modifier
                        .fillMaxSize()
                        .background(T.Void)
                        // the custom field and the keyboard both push the Save button
                        // below the fold on a short screen, so this scrolls
                        .verticalScroll(rememberScrollState())
                        .imePadding()
                        .padding(20.dp)
                ) {
                    Spacer(Modifier.height(28.dp))
                    Text("Categorize $date", fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Hi)
                    if (summary.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(summary, fontSize = 13.sp, color = T.Mid)
                    }
                    Spacer(Modifier.height(18.dp))

                    Status.all.forEach { s ->
                        val selected = s == chosen && !customOn
                        Surface(
                            color = if (selected) T.Cyan else T.Deep,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            onClick = { chosen = s; customOn = false }
                        ) {
                            Row(Modifier.padding(16.dp)) {
                                Text(
                                    s, fontSize = 16.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) Color(0xFF051020) else T.Hi,
                                    modifier = Modifier.weight(1f)
                                )
                                if (s == guess) Text(
                                    "GPS suggests", fontSize = 11.sp,
                                    color = if (selected) Color(0xFFAFC0C8) else T.Mid
                                )
                            }
                        }
                    }

                    // your own categories, kept from last time
                    val saved = remember(bump) { Store.customCategories(this@DayPromptActivity) }
                    saved.forEach { label ->
                        val selected = !customOn && chosen == label
                        Surface(
                            color = if (selected) Color(0xFFFF4FA3) else T.Deep,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            onClick = { chosen = label; customOn = false }
                        ) {
                            Row(Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(label, fontSize = 16.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold
                                                 else FontWeight.Normal,
                                    color = if (selected) Color(0xFF051020) else T.Hi,
                                    modifier = Modifier.weight(1f))
                                Text("SAVED", fontSize = 9.sp,
                                    color = if (selected) Color(0xFF3A0A22) else T.Mid)
                            }
                        }
                    }

                    // name a new one
                    Surface(
                        color = if (customOn) T.Cyan else T.Deep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        onClick = { customOn = true }
                    ) {
                        Row(Modifier.padding(16.dp)) {
                            Text(
                                if (customOn && customText.isNotBlank()) customText else "Something else…",
                                fontSize = 16.sp,
                                fontWeight = if (customOn) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (customOn) Color(0xFF051020) else T.Hi,
                                modifier = Modifier.weight(1f)
                            )
                            Text("CUSTOM", fontSize = 10.sp,
                                color = if (customOn) Color(0xFF0A2140) else T.Mid)
                        }
                    }

                    if (customOn) {
                        OutlinedTextField(
                            value = customText,
                            onValueChange = { customText = it },
                            label = { Text("Name this category") },
                            placeholder = { Text("Telework, PCS travel, holiday…") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Saved for next time, and counted and exported like the built-in " +
                                "five. Remove any you stop using from Settings.",
                            fontSize = 11.sp, color = T.Mid)
                    }

                    Spacer(Modifier.height(14.dp))
                    Text("WHICH STATE WERE YOU IN", fontSize = 9.sp, color = T.Mid,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(6.dp))
                    val autoStates = remember(bump) {
                        Store.days(this@DayPromptActivity)
                            .firstOrNull { it.date == date }?.states?.joinToString(", ") ?: "?"
                    }
                    val curStates = remember(bump) {
                        Store.stateOverride(this@DayPromptActivity, date)
                    }
                    Text(
                        if (curStates == null) "Recorded automatically as $autoStates"
                        else "Set by hand to ${curStates.replace("|", " and ")}",
                        fontSize = 12.sp, color = if (curStates == null) T.Mid else T.Gold
                    )
                    Spacer(Modifier.height(8.dp))
                    val cs = Store.countedState(this@DayPromptActivity)
                    val hs = Store.homeState(this@DayPromptActivity)
                    // tap states on and off — any mix, e.g. VA and DC for a meeting
                    // across the river; Auto goes back to what the fixes say
                    val picked = curStates?.split("|")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
                    val stateOpts = listOf(cs, hs, "DC").distinct()
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (listOf<String?>(null) + stateOpts)
                            .forEach { v ->
                                val label = v ?: "Auto"
                                val on = if (v == null) curStates == null else v in picked
                                Surface(
                                    color = if (on) T.Gold else T.Deep,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        val next = when {
                                            v == null -> null
                                            v in picked -> (picked - v).takeIf { it.isNotEmpty() }
                                            else -> picked + v
                                        }
                                        Store.setStateOverride(this@DayPromptActivity, date,
                                            next?.let { s -> stateOpts.filter { it in s }
                                                .plus(s.filter { it !in stateOpts })
                                                .joinToString("|") })
                                        bump++
                                    }
                                ) {
                                    Text(label, fontSize = 11.sp,
                                        color = if (on) Color(0xFF051020) else T.Hi,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("This is the count that decides residency. Tap every state you were " +
                            "in — a day in both VA and DC is still a VA day. Correct it when a " +
                            "fix could not resolve, or resolved to the wrong side of a line.",
                        fontSize = 11.sp, color = T.Mid)

                    Spacer(Modifier.height(16.dp))
                    Text("DID THIS DAY EARN?", fontSize = 9.sp, color = T.Mid,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        remember(bump, chosen, customOn, customText) {
                            Workdays.reasonOn(this@DayPromptActivity, date,
                                if (customOn) customText else chosen)
                        },
                        fontSize = 12.sp, color = T.Mid
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val cur = remember(bump) {
                            Store.workOverride(this@DayPromptActivity, date)
                        }
                        listOf(null to "Automatic", Store.WORKED to "Worked", Store.OFF to "Day off")
                            .forEach { (v, label) ->
                                val on = cur == v
                                Surface(
                                    color = if (on) T.Cyan else T.Deep,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        Store.setWorkOverride(this@DayPromptActivity, date, v)
                                        bump++
                                    }
                                ) {
                                    Text(label, fontSize = 11.sp,
                                        color = if (on) Color(0xFF051020) else T.Hi,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                    }

                    val earnedToday = Workdays.earnedOn(this@DayPromptActivity, date,
                        if (customOn) customText else chosen)
                    if (earnedToday) {
                        Spacer(Modifier.height(14.dp))
                        Text("WHICH STATE EARNED IT", fontSize = 9.sp, color = T.Mid,
                            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Spacer(Modifier.height(6.dp))
                        val today = Store.days(this@DayPromptActivity)
                            .firstOrNull { it.date == date }
                        val auto = today?.primaryState ?: "?"
                        val chosenState = remember(bump) {
                            Store.incomeStateOverride(this@DayPromptActivity, date)
                        }
                        val isSplit = Store.parseSplit(chosenState) != null
                        var splitOpen by remember(bump) { mutableStateOf(isSplit) }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val opts = listOf<Pair<String?, String>>(null to "Auto ($auto)") +
                                listOf(Store.countedState(this@DayPromptActivity),
                                       Store.homeState(this@DayPromptActivity), "DC")
                                    .distinct().map { it to it }
                            opts.forEach { (v, label) ->
                                val on = !splitOpen && chosenState == v
                                Surface(
                                    color = if (on) T.Gold else T.Deep,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        Store.setIncomeStateOverride(
                                            this@DayPromptActivity, date, v)
                                        bump++
                                    }
                                ) {
                                    Text(label, fontSize = 11.sp,
                                        color = if (on) Color(0xFF051020) else T.Hi,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                        if (chosenState == null && !today?.dutyAnchor.isNullOrBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Auto: normal duty at ${today!!.dutyAnchor}. Every duty-hours " +
                                    "fix stayed within ${fmtNum(Store.localAreaMiles(this@DayPromptActivity))} mi " +
                                    "of it, so a stop nearby — DC included — does not move the day.",
                                fontSize = 11.sp, color = T.Teal)
                        }
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            color = if (splitOpen) T.Gold else T.Deep,
                            shape = RoundedCornerShape(9.dp),
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { splitOpen = true }
                        ) {
                            Text(if (isSplit) "Split by hours — " + Store.parseSplit(chosenState)!!
                                    .entries.joinToString(" · ") { "${it.key} ${fmtNum(it.value)}h" }
                                 else "Split by hours",
                                fontSize = 11.sp,
                                color = if (splitOpen) Color(0xFF051020) else T.Hi,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                        if (splitOpen) {
                            SplitEditor(date, chosenState) { bump++ }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Travel days are a convention, not a fact. When a CPA names " +
                                "one, set it here. A day worked in more than one place — the " +
                                "Pentagon in the morning, a meeting in the District after " +
                                "lunch — can be split by the hours spent in each; only the " +
                                "Virginia hours are Virginia income.", fontSize = 11.sp, color = T.Mid)
                    }

                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Note — orders number, location, purpose") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    if (customOn && customText.isBlank()) {
                        Text("Give the category a name before saving.",
                            fontSize = 12.sp, color = Color(0xFFFF6B5A))
                        Spacer(Modifier.height(8.dp))
                    }
                    Button(
                        enabled = !(customOn && customText.isBlank()),
                        onClick = {
                            val label = if (customOn) customText.trim() else chosen
                            if (customOn) Store.addCustomCategory(this@DayPromptActivity, label)
                            Store.setStatus(this@DayPromptActivity, date, label, note)
                            getSystemService(NotificationManager::class.java).cancel(Notifier.ID_STATUS)
                            finish()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = T.Cyan, contentColor = Color(0xFF051020)),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save") }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Not now")
                    }
                    Spacer(Modifier.height(16.dp))
                    ClearDayButton(date) { finish() }
                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}


/**
 * Hours worked in each state on one day. Typed, then saved with its own button —
 * nothing changes until Save. The shares are the hours over their total, so
 * 4 and 4 is half and half whatever the scheduled day length is.
 */
@Composable
private fun SplitEditor(date: String, current: String?, saved: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val cs = Store.countedState(ctx)
    val hs = Store.homeState(ctx)
    val have = remember(current) { Store.parseSplit(current) ?: linkedMapOf() }
    val states = remember(current) { (listOf(cs, "DC", hs) + have.keys).distinct() }
    val hours = remember(current) {
        mutableStateMapOf<String, String>().apply {
            states.forEach { put(it, have[it]?.let { h -> fmtNum(h) } ?: "") }
        }
    }
    var msg by remember { mutableStateOf("") }
    val day = Store.hoursPerDay(ctx)

    Spacer(Modifier.height(10.dp))
    Text("Hours worked in each — decimals are fine (2.5).", fontSize = 11.sp, color = T.Mid)
    Spacer(Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        states.forEach { st ->
            DarkField(hours[st] ?: "", "$st hours", Modifier.weight(1f), numeric = true) {
                hours[st] = it; msg = ""
            }
        }
    }
    val parsed = states.associateWith { hours[it]?.toDoubleOrNull() ?: 0.0 }.filter { it.value > 0 }
    val total = parsed.values.sum()
    Spacer(Modifier.height(6.dp))
    if (total > 0) {
        Text(parsed.entries.joinToString(" · ") {
                "${it.key} ${fmtNum(it.value)}h = " + String.format(java.util.Locale.US,
                    "%.1f%%", it.value / total * 100)
            } + " · ${fmtNum(total)}h of ${fmtNum(day)}h scheduled",
            fontSize = 12.sp, color = T.Hi)
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PrimaryBtn("Save split", Modifier.weight(1f), accent = T.Gold) {
            if (parsed.size < 2) {
                msg = "Put hours in at least two states — for one state, tap it above."
                return@PrimaryBtn
            }
            Store.setIncomeStateOverride(ctx, date, Store.formatSplit(parsed))
            msg = "Saved."
            saved()
        }
        if (Store.parseSplit(current) != null) {
            GhostBtn("Remove split", Modifier.weight(1f), color = T.Danger) {
                Store.setIncomeStateOverride(ctx, date, null)
                saved()
            }
        }
    }
    if (msg.isNotBlank()) {
        Spacer(Modifier.height(4.dp))
        Text(msg, fontSize = 12.sp, color = if (msg == "Saved.") T.Teal else T.Gold)
    }
}


/**
 * Take back everything entered by hand for this day, after a second tap.
 * Fixes the phone took stay — they are the record.
 */
@Composable
fun ClearDayButton(date: String, done: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var sure by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    OutlinedButton(
        onClick = {
            if (!sure) { sure = true; return@OutlinedButton }
            val r = Store.clearDay(ctx, date)
            sure = false
            if (!r.anything) { msg = "Nothing entered by hand on this day."; return@OutlinedButton }
            android.widget.Toast.makeText(ctx,
                "Cleared $date" + (if (r.gpsFixesKept > 0)
                    " — ${r.gpsFixesKept} GPS fix${if (r.gpsFixesKept == 1) "" else "es"} kept" else ""),
                android.widget.Toast.LENGTH_LONG).show()
            done()
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (sure) "Tap again to clear $date" else "Clear this day",
            color = Color(0xFFFF6B5A), fontSize = 13.sp)
    }
    Spacer(Modifier.height(4.dp))
    Text(if (msg.isNotBlank()) msg else
        "Removes what was entered by hand — days added from a datum, the category and note, " +
        "the state, worked and earning choices, and a schedule-filled entry. Fixes the phone " +
        "actually took are kept.", fontSize = 11.sp, color = T.Mid)
}

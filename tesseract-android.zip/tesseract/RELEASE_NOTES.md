A real bug found by verifying the dashboard's tax figure against the
allocation screen's, on the same inputs: they disagreed, sometimes badly —
an effective rate over 100% was possible early in the year.

The cause: the dashboard was multiplying two earning days by the daily rate,
then applying a tax rate computed against the full logged ratio's VA wages —
two different wage figures feeding one formula. Whenever the two did not
match, which is most of the time, the result was wrong.

Fixed by having the dashboard show the same VA tax and the same VA wages the
allocation screen computes, from the same object, rather than recomputing
either from scratch. They now agree by construction rather than by luck.

Also confirmed in this pass: every dollar-shaped field across the app accepts
a decimal point, 26 of 26 core capabilities are present and working, and all
18 screens are registered.

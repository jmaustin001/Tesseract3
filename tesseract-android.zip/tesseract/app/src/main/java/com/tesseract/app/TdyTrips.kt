package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * TDY trips, each priced on its own: where, the dates, the M&IE rate and the
 * lodging ceiling as read off the GSA table, and any government meals.
 *
 * M&IE paid under an accountable plan is not wages — it is not on the W-2 and
 * no tax comes out of it — so what a trip pays in M&IE is money you keep
 * whatever you spend on food. That is the figure this screen is built around.
 * Lodging is reimbursed against the receipt, up to the ceiling, and is not
 * take-home; it is shown, never added to the take-home figures.
 */
data class TdyTrip(
    val id: String,
    val place: String,
    val datum: String,       // datum name the trip is tied to, or blank
    val start: String,       // yyyy-MM-dd, the day you travel out
    val end: String,         // yyyy-MM-dd, the day you travel back
    val mie: String,         // M&IE rate per day, as typed
    val lodging: String,     // lodging ceiling per night, as typed (not take-home)
    val breakfasts: String,  // government meals provided over the trip
    val lunches: String,
    val dinners: String,
    val longTerm: Boolean,
    val note: String,
    val state: String = "",  // the state the TDY work was done in — FL, TX…
    /** Days set by hand: "2026-10-03=home;2026-10-05=full". Anything not listed
     *  takes the standard pattern — the end days travel, the rest full. */
    val dayKinds: String = ""
)

object TdyTrips {

    private const val KEY = "tdyTrips"

    fun all(ctx: Context): List<TdyTrip> {
        val raw = Store.prefString(ctx, KEY, "")
        if (raw.isBlank()) return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                TdyTrip(o.optString("id"), o.optString("place"), o.optString("datum"),
                    o.optString("start"), o.optString("end"), o.optString("mie"),
                    o.optString("lodging"), o.optString("b"), o.optString("l"),
                    o.optString("d"), o.optBoolean("long", false), o.optString("note"),
                    o.optString("state"), o.optString("kinds"))
            }.sortedByDescending { it.start }
        } catch (e: Exception) { emptyList() }
    }

    private fun save(ctx: Context, list: List<TdyTrip>) {
        val a = JSONArray()
        list.forEach { t ->
            a.put(JSONObject().apply {
                put("id", t.id); put("place", t.place.trim()); put("datum", t.datum)
                put("start", t.start); put("end", t.end); put("mie", t.mie)
                put("lodging", t.lodging); put("b", t.breakfasts); put("l", t.lunches)
                put("d", t.dinners); put("long", t.longTerm); put("note", t.note)
                put("state", t.state.trim().uppercase())
                put("kinds", t.dayKinds)
            })
        }
        Store.setPrefString(ctx, KEY, a.toString())
    }

    fun upsert(ctx: Context, t: TdyTrip) = save(ctx, all(ctx).filterNot { it.id == t.id } + t)
    fun delete(ctx: Context, id: String) = save(ctx, all(ctx).filterNot { it.id == id })
    fun newId() = "trip" + System.currentTimeMillis().toString().takeLast(9)

    private val DATE = Regex("\\d{4}-\\d{2}-\\d{2}")

    /** What stops a save, in a few words, or null. */
    fun problem(t: TdyTrip): String? = when {
        t.place.isBlank() -> "Name the place"
        !DATE.matches(t.start) || !DATE.matches(t.end) -> "Dates need to be YYYY-MM-DD"
        t.end < t.start -> "The trip ends before it starts"
        (t.mie.toDoubleOrNull() ?: 0.0) <= 0.0 -> "Enter the M&IE rate"
        else -> null
    }

    // ---------------- day types ----------------

    const val TRAVEL = "travel"   // 75%: the day out, the day back, a travel day mid-trip
    const val FULL = "full"       // 100%: a day in TDY status at the TDY location
    const val HOME = "home"       // 0%: a day at your own residence — no per diem

    fun factorOf(kind: String) = when (kind) { TRAVEL -> Perdiem.FIRST_LAST; HOME -> 0.0; else -> 1.0 }
    fun labelOf(kind: String) = when (kind) { TRAVEL -> "Travel 75%"; HOME -> "Home — none"; else -> "Full 100%" }

    fun parseKinds(raw: String): Map<String, String> = raw.split(';').mapNotNull {
        val kv = it.split('='); if (kv.size == 2 && kv[0].length == 10) kv[0] to kv[1] else null
    }.toMap()

    fun formatKinds(m: Map<String, String>): String =
        m.toSortedMap().entries.joinToString(";") { "${it.key}=${it.value}" }

    /** The standard pattern for day i of n: the end days travel, the rest full. */
    fun defaultKind(i: Int, n: Int) = if (i == 0 || i == n - 1) TRAVEL else FULL

    fun datesOf(start: String, end: String): List<String> {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val out = mutableListOf<String>()
        try {
            val c = java.util.Calendar.getInstance().apply { time = fmt.parse(start)!! }
            var guard = 0
            while (guard++ < 1500) {
                val s = fmt.format(c.time)
                if (s > end) break
                out.add(s); c.add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
        } catch (e: Exception) { }
        return out
    }

    /** Every day's type, the hand-set ones over the standard pattern. */
    fun kindsFor(start: String, end: String, raw: String): List<String> {
        val set = parseKinds(raw)
        val d = datesOf(start, end)
        return d.mapIndexed { i, date -> set[date] ?: defaultKind(i, d.size) }
    }

    /**
     * Weekends and federal holidays inside the trip — not its first or last
     * day — set to home: the Friday-out, weekend-home, Monday-back pattern.
     */
    fun weekendsHome(start: String, end: String, raw: String): String {
        val m = parseKinds(raw).toMutableMap()
        val d = datesOf(start, end)
        d.forEachIndexed { i, date ->
            if (i == 0 || i == d.lastIndex) return@forEachIndexed
            val dow = Workdays.weekdayOf(date)
            if (dow == java.util.Calendar.SATURDAY || dow == java.util.Calendar.SUNDAY ||
                Workdays.isHoliday(date)) m[date] = HOME
        }
        return formatKinds(m)
    }

    /** The same trip, moved to start on another date, day types and all. */
    fun repeatFrom(t: TdyTrip, newStart: String): TdyTrip? {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return try {
            val shift = Math.round((fmt.parse(newStart)!!.time - fmt.parse(t.start)!!.time) / 86_400_000.0).toInt()
            fun move(d: String): String {
                val c = java.util.Calendar.getInstance().apply { time = fmt.parse(d)!! }
                c.add(java.util.Calendar.DAY_OF_YEAR, shift); return fmt.format(c.time)
            }
            val kinds = parseKinds(t.dayKinds).mapKeys { move(it.key) }
            t.copy(id = newId(), start = newStart, end = move(t.end), dayKinds = formatKinds(kinds),
                note = "repeat of ${t.start}")
        } catch (e: Exception) { null }
    }

    /** The M&IE for one trip, laid out day by day. */
    data class Priced(
        val days: Int,
        val dates: List<String>,
        val perDay: List<Double>,      // M&IE each day, after the meal deduction share
        val rate: Double,              // M&IE after any long-term flat rate
        val flat: Double,              // 1.0, 0.75 or 0.55
        val fullDays: Int,
        val travelDays: Int,
        val gross: Double,
        val deductions: Double,
        val net: Double,
        val nights: Int,
        val lodgingCap: Double,        // ceiling × nights — what lodging could reach, not take-home
        val kinds: List<String> = emptyList(),
        val homeDays: Int = 0
    ) {
        /** M&IE on days that fall in a year, and on or before a date. */
        fun inYear(year: Int, through: String? = null): Double =
            dates.indices.filter { i ->
                dates[i].startsWith("$year-") && (through == null || dates[i] <= through)
            }.sumOf { perDay[it] }

        fun daysInYear(year: Int, through: String? = null): Int =
            dates.count { it.startsWith("$year-") && (through == null || it <= through) }
    }

    /**
     * Day out and day back at 75%, every day between at the full rate. A trip
     * that starts and ends on the same day is one 75% day. The long-term flat
     * rate, when authorized, comes off the rate itself: 75% from day 31, 55%
     * from day 181. A provided meal comes off at its full value, spread evenly
     * over the trip so a part-finished trip carries its share.
     */
    fun price(start: String, end: String, mie: Double, lodging: Double,
              breakfast: Double, lunch: Double, dinner: Double,
              b: Int, l: Int, d: Int, longTerm: Boolean, kindsRaw: String = ""): Priced {
        val dates = datesOf(start, end)
        val n = dates.size
        val kinds = kindsFor(start, end, kindsRaw)
        val flat = when {
            !longTerm -> 1.0
            n >= 181 -> Perdiem.LONG_TERM_181
            n >= 31 -> Perdiem.LONG_TERM_31
            else -> 1.0
        }
        val rate = mie * flat
        val gross = kinds.map { rate * factorOf(it) }
        val deductions = b.coerceAtLeast(0) * breakfast + l.coerceAtLeast(0) * lunch +
                d.coerceAtLeast(0) * dinner
        // meals are only ever provided on a day in travel status, so the
        // deduction is spread over those days and never makes a home day negative
        val paidDays = kinds.count { it != HOME }
        val share = if (paidDays > 0) deductions / paidDays else 0.0
        val perDay = kinds.mapIndexed { i, k -> if (k == HOME) 0.0 else (gross[i] - share).coerceAtLeast(0.0) }
        // a night is lodged when neither that day nor the next is spent at home
        val nights = (0 until (n - 1).coerceAtLeast(0)).count { kinds[it] != HOME && kinds[it + 1] != HOME }
        return Priced(n, dates, perDay, rate, flat, kinds.count { it == FULL }, kinds.count { it == TRAVEL },
            gross.sum(), deductions, perDay.sum(), nights, lodging * nights, kinds, kinds.count { it == HOME })
    }

    /** A meal split for an M&IE total, scaled from the nearest published tier. */
    fun mealsFor(total: Double, tiers: List<Perdiem.Tier>): Perdiem.Tier {
        val near = tiers.minByOrNull { kotlin.math.abs(it.total - total) } ?: return Perdiem.Tier(total, 0.0, 0.0, 0.0)
        val f = if (near.total > 0) total / near.total else 0.0
        return Perdiem.Tier(total, near.b * f, near.l * f, near.d * f)
    }

    fun price(t: TdyTrip, tiers: List<Perdiem.Tier>): Priced {
        val mie = t.mie.toDoubleOrNull() ?: 0.0
        val m = mealsFor(mie, tiers)
        return price(t.start, t.end, mie, t.lodging.toDoubleOrNull() ?: 0.0,
            m.b, m.l, m.d, t.breakfasts.toIntOrNull() ?: 0, t.lunches.toIntOrNull() ?: 0,
            t.dinners.toIntOrNull() ?: 0, t.longTerm, t.dayKinds)
    }

    /**
     * The most recent run of consecutive logged days that touched a datum or
     * were categorized as TDY. Returns first and last date, or null.
     */
    fun lastRunAt(ctx: Context, datum: String): Pair<String, String>? {
        val hit = Store.days(ctx)
            .filter { (datum.isNotBlank() && datum in it.zones) || Status.dutyStatus(it.status) == "TDY" }
            .map { it.date }.sorted()
        if (hit.isEmpty()) return null
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val end = hit.last(); var start = end
        for (i in hit.indices.reversed()) {
            if (hit[i] == start) continue
            val c = java.util.Calendar.getInstance().apply { time = fmt.parse(start)!! }
            c.add(java.util.Calendar.DAY_OF_YEAR, -1)
            if (fmt.format(c.time) == hit[i]) start = hit[i] else break
        }
        return start to end
    }

    /** How many days in a trip's range the log puts at its datum or in TDY status. */
    fun logCheck(ctx: Context, t: TdyTrip): Int {
        if (!DATE.matches(t.start) || !DATE.matches(t.end)) return 0
        return Store.days(ctx).count {
            it.date >= t.start && it.date <= t.end &&
                ((t.datum.isNotBlank() && t.datum in it.zones) || Status.dutyStatus(it.status) == "TDY")
        }
    }

    // ---------------- the trip against the day log ----------------

    /**
     * What a trip did to the year's salary. A workday on TDY is paid at the same
     * SF-50 rate as any other, but it is earned where the work was done — a
     * week in Orlando is Florida-source pay, not Virginia's.
     */
    data class Salary(
        val workdays: Int,             // scheduled workdays in the trip, leave days out
        val pay: Double,               // salary on those workdays, at the SF-50 in effect
        val notCounted: Int,           // workdays the log earns outside the counted state
        val notCountedPay: Double,
        val countedInLog: Int,         // TDY workdays the log still earns in the counted state
        val unlogged: Int              // workdays in the trip with no log entry at all
    )

    fun salary(ctx: Context, t: TdyTrip, year: Int? = null,
               days: Map<String, DaySummary> = Store.days(ctx).associateBy { it.date }): Salary {
        if (!DATE.matches(t.start) || !DATE.matches(t.end)) return Salary(0, 0.0, 0, 0.0, 0, 0)
        val counted = Store.countedState(ctx)
        val recs = Salaries.all(ctx).filter { it.rate > 0 }
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val c = java.util.Calendar.getInstance().apply { time = fmt.parse(t.start)!! }
        var wd = 0; var pay = 0.0; var nc = 0; var ncPay = 0.0; var inC = 0; var none = 0
        var guard = 0
        while (guard++ < 1500) {
            val date = fmt.format(c.time)
            if (date > t.end) break
            c.add(java.util.Calendar.DAY_OF_YEAR, 1)
            if (year != null && !date.startsWith("$year-")) continue
            val d = days[date]
            if (!Workdays.earnedOn(ctx, date, d?.status ?: "")) continue
            val y = date.take(4).toInt()
            val divisor = Workdays.scheduledWorkdays(ctx, y).coerceAtLeast(1)
            val r = if (recs.isEmpty()) null
                    else recs.lastOrNull { it.effective.isBlank() || it.effective <= date } ?: recs.first()
            val dayPay = (r?.rate ?: 0.0) / divisor
            wd++; pay += dayPay
            if (d == null) { none++; continue }
            val share = Store.incomeShareIn(ctx, d, counted)
            if (share < 1.0) { nc++; ncPay += dayPay * (1 - share) }
            if (share > 0.0) inC++
        }
        return Salary(wd, pay, nc, ncPay, inC, none)
    }

    data class Mark(val categorize: Int, val add: Int, val conflicts: Int, val future: Int,
                    val homeLeft: Int = 0)

    /**
     * Put the trip into the day log: a logged day with no category becomes TDY,
     * and a day with no entry at all is added by hand at the trip's state and
     * datum, flagged as hand-entered like any other. A day already given a
     * different category is left alone and counted, never overwritten. Days
     * after today are not touched.
     */
    fun markInLog(ctx: Context, t: TdyTrip, dryRun: Boolean): Mark {
        if (!DATE.matches(t.start) || !DATE.matches(t.end)) return Mark(0, 0, 0, 0)
        val datum = Store.datums(ctx).firstOrNull { it.name == t.datum }
        val status = if (datum?.role == Datum.RESIDENCE) Status.TDY_RES else Status.TDY_OTHER
        val state = t.state.trim().uppercase()
        val days = Store.days(ctx).associateBy { it.date }
        val today = Store.today()
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val c = java.util.Calendar.getInstance().apply { time = fmt.parse(t.start)!! }
        val home = parseKinds(t.dayKinds).filterValues { it == HOME }.keys
        var cat = 0; var add = 0; var conflict = 0; var future = 0; var homeLeft = 0; var guard = 0
        while (guard++ < 1500) {
            val date = fmt.format(c.time)
            if (date > t.end) break
            c.add(java.util.Calendar.DAY_OF_YEAR, 1)
            if (date > today) { future++; continue }
            // a day at home is not a TDY day; it keeps whatever the log says
            if (date in home) { homeLeft++; continue }
            val d = days[date]
            when {
                d == null -> {
                    if (state.length < 2) continue
                    add++
                    if (!dryRun) { Store.addManualDay(ctx, date, state, datum); Store.setStatus(ctx, date, status, t.place) }
                }
                Status.dutyStatus(d.status) == "TDY" -> { }
                // no category, or only the schedule's guess: the trip is better evidence
                d.status.isBlank() || (d.reconstructed && Store.statusOf(ctx, date).first.isBlank()) -> {
                    cat++
                    if (!dryRun) Store.setStatus(ctx, date, status, d.note.ifBlank { t.place })
                }
                else -> conflict++
            }
        }
        return Mark(cat, add, conflict, future, homeLeft)
    }

    /** The trips as a CSV, for the report bundle. */
    fun csv(ctx: Context, tiers: List<Perdiem.Tier>): String {
        val sb = StringBuilder("place,state,datum,start,end,days,full_days,travel_days,mie_rate," +
                "long_term_flat,meal_deductions,mie_tax_free,lodging_ceiling_per_night,lodging_ceiling_total," +
                "workdays,salary_on_workdays,workdays_earned_outside_${Store.countedState(ctx).lowercase()}," +
                "salary_outside_${Store.countedState(ctx).lowercase()},running_mie_total,note\n")
        val days = Store.days(ctx).associateBy { it.date }
        var running = 0.0
        all(ctx).sortedBy { it.start }.forEach { t ->
            val p = price(t, tiers)
            val s = salary(ctx, t, null, days)
            running += p.net
            fun q(v: String) = "\"" + v.replace("\"", "'") + "\""
            sb.append(q(t.place)).append(',').append(t.state).append(',').append(q(t.datum)).append(',')
                .append(t.start).append(',').append(t.end).append(',').append(p.days).append(',')
                .append(p.fullDays).append(',').append(p.travelDays).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", t.mie.toDoubleOrNull() ?: 0.0)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", p.flat)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", p.deductions)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", p.net)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", t.lodging.toDoubleOrNull() ?: 0.0)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", p.lodgingCap)).append(',')
                .append(s.workdays).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", s.pay)).append(',')
                .append(s.notCounted).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", s.notCountedPay)).append(',')
                .append(String.format(java.util.Locale.US, "%.2f", running)).append(',')
                .append(q(t.note)).append('\n')
        }
        return sb.toString()
    }

    // ---------------- forecasting — nothing here is saved ----------------

    /** M&IE for a trip of n calendar days: the end days at 75%, the rest at the rate. */
    fun mieFor(days: Int, mie: Double): Double = when {
        days <= 0 -> 0.0
        days == 1 -> mie * Perdiem.FIRST_LAST
        else -> (days - 2) * mie + 2 * mie * Perdiem.FIRST_LAST
    }

    data class Forecast(
        val trips: Double,
        val mie: Double,
        val workdays: Double,
        val salary: Double,
        val stateTax: Double,
        val awayDays: Double,
        val stateDaysAtMost: Double
    )

    /**
     * A pattern carried through the rest of the year: so many trips a month, each
     * so many days and workdays long, at one M&IE rate. Trips are counted
     * fractionally, so half a trip a month for three months is one and a half
     * trips. The state's day count assumes every day not away is spent in the
     * counted state — the ceiling, not a prediction.
     */
    fun pattern(daysLeft: Int, tripsPerMonth: Double, daysPerTrip: Int, workdaysPerTrip: Int,
                mie: Double, dailyPay: Double, effRate: Double, stateDaysNow: Int,
                homeDaysPerTrip: Int = 0): Forecast {
        val months = daysLeft.coerceAtLeast(0) / 30.4375
        val trips = (tripsPerMonth.coerceAtLeast(0.0) * months)
        val away = minOf(trips * daysPerTrip.coerceAtLeast(0), daysLeft.toDouble())
        val wd = trips * workdaysPerTrip.coerceIn(0, daysPerTrip.coerceAtLeast(0))
        val salary = wd * dailyPay
        // home days sit inside the trip, so each one takes a full day's M&IE off
        val home = homeDaysPerTrip.coerceIn(0, (daysPerTrip - 2).coerceAtLeast(0))
        val perTrip = (mieFor(daysPerTrip, mie) - home * mie).coerceAtLeast(0.0)
        return Forecast(trips, trips * perTrip, wd, salary, salary * effRate,
            away, stateDaysNow + daysLeft - away)
    }
}

package com.tesseract.app

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.util.Locale

class DatumsActivity : ComponentActivity() {
    var resumeTick by androidx.compose.runtime.mutableIntStateOf(0)

    override fun onResume() { super.onResume(); resumeTick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // arriving from the "somewhere new" notification: create the datum at
        // those coordinates so it only needs naming
        val lat = intent.getDoubleExtra("newLat", 0.0)
        val lon = intent.getDoubleExtra("newLon", 0.0)
        if (lat != 0.0 || lon != 0.0) {
            val already = Store.datums(this).any {
                Zones.milesBetween(lat, lon, it.lat, it.lon) <= it.radiusMiles
            }
            if (!already) {
                Store.upsertDatum(this, Datum(
                    Store.newDatumId(),
                    intent.getStringExtra("newState")?.let { "New place in $it" } ?: "New place",
                    lat, lon, 15.0, Datum.OTHER
                ))
            }
        }
        setContent { TessTheme { DatumsScreen() } }
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }
}

private fun roleColor(role: String) = when (role) {
    Datum.DUTY -> T.Gold
    Datum.RESIDENCE -> T.Teal
    else -> T.Violet
}

private fun fmt(v: Double) = String.format(Locale.US, "%.6f", v)

private fun datumColor(ctx: android.content.Context, d: Datum) = Color(Zones.colorOf(ctx, d))

@Composable
private fun DatumsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val datums = remember(tick) { Store.datums(ctx) }
    val year = Store.year()

    TessScreen("Datums", "${datums.size} reference points") {
        Hint("A datum is a named point with a radius. Every fix is measured against these. " +
                "Rename or move one and past days keep the name they had — history is never rewritten.")
        Spacer(Modifier.height(14.dp))

        datums.forEach { d ->
            DatumCard(d, Store.datumDays(ctx, d.name, year)) { tick++ }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(4.dp))
        GhostBtn("Add a datum") {
            Store.upsertDatum(ctx, Datum(Store.newDatumId(), "New datum", 0.0, 0.0, 25.0, Datum.OTHER))
            tick++
        }
        Spacer(Modifier.height(10.dp))
        Hint("Add as many as you need — a second residence, a detail site, a parents' address. " +
                "Days at any datum are tallied by its role, so the five day-categories keep " +
                "working no matter what you call things.")
    }
}

@Composable
private fun DatumCard(d: Datum, daysHere: Int, changed: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(d.name) }
    var radius by remember { mutableStateOf(d.radiusMiles.toInt().toString()) }
    var role by remember { mutableStateOf(d.role) }
    var lat by remember { mutableStateOf(d.lat) }
    var lon by remember { mutableStateOf(d.lon) }
    var color by remember { mutableIntStateOf(d.color) }
    var addr by remember { mutableStateOf("") }
    var latText by remember { mutableStateOf(fmt(d.lat)) }
    var lonText by remember { mutableStateOf(fmt(d.lon)) }
    var looking by remember { mutableStateOf(false) }
    var lookupMsg by remember { mutableStateOf("") }
    var lookupBad by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val accent = if (color != 0) Color(color) else datumColor(ctx, d)

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(T.Deep)
            .border(1.dp, accent.copy(alpha = .45f), RoundedCornerShape(14.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val mark = datumColor(ctx, d)
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
                .background(mark.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                TesseractMark(Modifier.size(24.dp), outer = mark, inner = mark,
                    strut = mark, alpha = .9f, stroke = 1.5f)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
                Text("${Datum.roleLabel(d.role).uppercase()} · ${d.radiusMiles.toInt()} MI · $daysHere DAYS",
                    fontSize = 9.sp, color = T.Low, fontWeight = FontWeight.Medium, letterSpacing = .8.sp)
            }
            Text(if (open) "▴" else "▾", color = T.Mid, fontSize = 14.sp)
        }

        if (open) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                DarkField(name, "Name", Modifier.fillMaxWidth()) { name = it }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(radius, "Radius (mi)", Modifier.weight(1f), numeric = true) { radius = it }
                    Box(Modifier.weight(1f)) {
                        GhostBtn("Use my position", color = accent) {
                            (ctx as? DatumsActivity)?.here { la, lo ->
                                lat = la; lon = lo
                                latText = fmt(la); lonText = fmt(lo)
                                lookupMsg = "Set from where you are now."
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("POSITION", fontSize = 9.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(7.dp))

                // three ways in: an address, typed coordinates, or standing there
                DarkField(addr, "Address or place name", Modifier.fillMaxWidth()) { addr = it }
                Spacer(Modifier.height(8.dp))
                GhostBtn(if (looking) "Looking up…" else "Find coordinates", color = accent) {
                    if (!looking && addr.isNotBlank()) {
                        looking = true; lookupMsg = ""
                        scope.launch {
                            val found = Fixer.geocodeAddress(ctx, addr)
                            looking = false
                            if (found == null) {
                                lookupMsg = "Could not find that. Try a fuller address, " +
                                        "or check you have a connection."
                                lookupBad = true
                            } else {
                                lat = found.lat; lon = found.lon
                                latText = fmt(found.lat); lonText = fmt(found.lon)
                                lookupMsg = found.label
                                lookupBad = false
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(latText, "Latitude", Modifier.weight(1f), signed = true) {
                        latText = it; it.toDoubleOrNull()?.let { v -> lat = v }
                    }
                    DarkField(lonText, "Longitude", Modifier.weight(1f), signed = true) {
                        lonText = it; it.toDoubleOrNull()?.let { v -> lon = v }
                    }
                }

                if (lookupMsg.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(lookupMsg, fontSize = 11.sp,
                        color = if (lookupBad) T.Danger else T.Teal)
                }
                Spacer(Modifier.height(6.dp))
                Hint("Set a datum before you ever go there. Coordinates can also be " +
                        "pasted straight from a maps app — long-press a spot and it gives " +
                        "you the pair.")

                Spacer(Modifier.height(12.dp))
                Text("ROLE", fontSize = 9.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Datum.roles.forEach { r ->
                        val on = role == r
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                                .background(if (on) roleColor(r).copy(alpha = .18f) else T.Glow)
                                .border(1.dp, if (on) roleColor(r) else T.Edge, RoundedCornerShape(9.dp))
                                .clickable { role = r }.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(Datum.roleLabel(r), fontSize = 11.sp,
                                color = if (on) roleColor(r) else T.Mid,
                                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("COLOR", fontSize = 9.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Datum.palette.forEach { c ->
                        val on = color == c
                        Box(
                            Modifier.weight(1f).aspectRatio(1f)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color(c))
                                .border(
                                    if (on) 2.5.dp else 0.dp,
                                    if (on) Color.White else Color.Transparent,
                                    RoundedCornerShape(7.dp)
                                )
                                .clickable { color = c }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Hint("Two datums with the same role would otherwise look identical. " +
                        "Pick one and it is used everywhere this datum appears.")

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Save", Modifier.weight(1f), accent = accent) {
                        Store.upsertDatum(ctx, d.copy(
                            name = name.ifBlank { d.name }, role = role,
                            lat = latText.toDoubleOrNull() ?: lat,
                            lon = lonText.toDoubleOrNull() ?: lon,
                            color = color,
                            radiusMiles = radius.toDoubleOrNull() ?: d.radiusMiles))
                        open = false; changed()
                    }
                    GhostBtn("Delete", Modifier.weight(1f), color = T.Danger) {
                        Store.deleteDatum(ctx, d.id); changed()
                    }
                }
            }
        }
    }
}

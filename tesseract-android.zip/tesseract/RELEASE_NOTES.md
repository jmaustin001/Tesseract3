Pay periods, and the twice-a-period office requirement.

To keep an official worksite — and the Washington locality pay attached to it —
a teleworking employee has to physically report there at least twice each
biweekly pay period, on a regular and recurring basis. That is a per-period
test, so the app now counts it per period.

The year grid marks the first day of every pay period with a bar down the left
edge of the square, clear of the $ in the centre and the travel split in the
corner. Tapping a day says which period it belongs to.

The dashboard shows the current period — office days so far against the two
required, and how many more are needed before it closes, while there is still
time to act on it.

Settings holds the calendar: any one period start lines the rest up (20
September 2026 by default), the PP number off the LES is optional, and the
required count is adjustable. It lists recent periods as met, short, open, or
away — the last for periods mostly spent on leave or TDY, since the rule is
about the regular pattern rather than a fortnight you were not there.

A day counts as in the office when a fix lands inside a duty-station datum or
the day is categorized Duty Station.

Also: two telework categories now ship ready — situational and regular.

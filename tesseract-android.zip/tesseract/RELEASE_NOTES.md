One clarification, no functional change.

The allocation screen's "taxable as a resident" and "tax as a resident on all
income" lines are a step inside Form 763's own arithmetic, not a statement
about residency — the form works out the rate by treating all income as
Virginia's for one line, then taxes only the allocated share. A note now says
so plainly, right where those lines appear, since the wording could otherwise
read as exactly the outcome the whole app exists to avoid.

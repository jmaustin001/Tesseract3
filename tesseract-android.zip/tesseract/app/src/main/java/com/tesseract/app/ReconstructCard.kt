package com.tesseract.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** The day before a yyyy-MM-dd date. */
private fun dayBefore(d: String): String = try {
    val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val c = Calendar.getInstance().apply { time = f.parse(d)!! }
    c.add(Calendar.DAY_OF_YEAR, -1); f.format(c.time)
} catch (e: Exception) { d }

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, accent: Color,
                  onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (value, label) ->
            val on = value == selected
            Box(
                Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (on) accent.copy(alpha = .18f) else T.Glow)
                    .border(1.dp, if (on) accent else T.Edge, RoundedCornerShape(8.dp))
                    .clickable { onPick(value) }
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) { Text(label, fontSize = 12.sp, color = if (on) accent else T.Mid) }
        }
    }
}

/**
 * Fill in the year before the first GPS fix from your schedule: scheduled
 * workdays as earning days, weekends, holidays and days off as rest days.
 */
@Composable
fun ReconstructCard(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val year = Store.year()
    var tick by remember { mutableIntStateOf(0) }
    val first = remember(tick) { Reconstruct.firstFix(ctx) }
    val existing = remember(tick) { Reconstruct.count(ctx) }
    val datums = remember { Store.datums(ctx) }

    var from by remember { mutableStateOf("$year-01-01") }
    var to by remember { mutableStateOf(first?.let { dayBefore(it) } ?: dayBefore(Store.today())) }
    var state by remember { mutableStateOf(Store.homeState(ctx)) }
    var workZone by remember { mutableStateOf("") }
    var offZone by remember {
        mutableStateOf(datums.firstOrNull { it.role == Datum.RESIDENCE }?.id ?: "")
    }
    var workStatus by remember { mutableStateOf(Status.DUTY) }
    var confirm by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    val datesOk = Regex("\\d{4}-\\d{2}-\\d{2}").let { it.matches(from) && it.matches(to) } && from <= to
    val plan = remember(from, to, tick) {
        if (datesOk) Reconstruct.plan(ctx, from, to) else Reconstruct.Plan(emptyList(), emptyList(), 0)
    }

    TCard("before the first fix", T.Violet) {
        Hint("The log starts " + (first?.let { "on $it" } ?: "today") + ". Days before that " +
                "can be filled in from your schedule — scheduled workdays as earning days, " +
                "weekends, federal holidays and regular days off as rest days. Without them " +
                "the allocation divides by a few weeks instead of a year.")
        Spacer(Modifier.height(8.dp))
        Hint("They are marked reconstructed, never as GPS fixes — in the day view and in " +
                "every export — no coordinates are invented, a day with a real fix is never " +
                "touched, and the whole set comes out with one button.")

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(from, "From", Modifier.weight(1f)) { from = it; confirm = false; msg = "" }
            DarkField(to, "Through", Modifier.weight(1f)) { to = it; confirm = false; msg = "" }
        }
        Spacer(Modifier.height(8.dp))
        DarkField(state, "State you were in", Modifier.fillMaxWidth()) {
            state = it.uppercase().take(3); confirm = false
        }

        Spacer(Modifier.height(14.dp))
        Text("WORKDAYS — WHERE", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Chips(listOf("" to "No datum") + datums.map { it.id to it.name }, workZone, T.Gold) {
            workZone = it; confirm = false
        }
        Spacer(Modifier.height(10.dp))
        Text("WORKDAYS — CATEGORY", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Chips(listOf(Status.DUTY to Status.DUTY, Status.TDY_RES to Status.TDY_RES) +
                Store.customCategories(ctx).map { it to it } + listOf("" to "None"),
            workStatus, T.Gold) { workStatus = it; confirm = false }
        Spacer(Modifier.height(10.dp))
        Text("REST DAYS — WHERE", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Chips(listOf("" to "No datum") + datums.map { it.id to it.name }, offZone, T.Teal) {
            offZone = it; confirm = false
        }

        Spacer(Modifier.height(14.dp))
        if (!datesOk) {
            Text("Dates need to be YYYY-MM-DD, the first no later than the second.",
                fontSize = 12.sp, color = T.Gold)
        } else {
            Text("${plan.workdays.size} workdays · ${plan.offDays.size} rest days" +
                    (if (plan.skipped > 0) " · ${plan.skipped} already logged, left alone" else ""),
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
            Spacer(Modifier.height(4.dp))
            Hint("Workdays follow your work schedule in Settings — duty weekdays, less " +
                    "federal holidays and regular days off. Leave or TDY in that stretch can " +
                    "be corrected day by day afterwards, like any other day.")
        }

        Spacer(Modifier.height(12.dp))
        PrimaryBtn(
            if (confirm) "Tap again to fill ${plan.workdays.size + plan.offDays.size} days"
            else "Fill these days", accent = T.Violet
        ) {
            if (!datesOk || plan.workdays.size + plan.offDays.size == 0) {
                msg = "Nothing to fill in that range."; return@PrimaryBtn
            }
            if (state.length < 2) { msg = "Enter the state, e.g. FL."; return@PrimaryBtn }
            if (!confirm) { confirm = true; return@PrimaryBtn }
            Reconstruct.fill(ctx, plan, state,
                datums.firstOrNull { it.id == workZone }, workStatus,
                datums.firstOrNull { it.id == offZone })
            confirm = false; tick++
            msg = "Filled. ${plan.workdays.size} workdays and ${plan.offDays.size} rest days."
            onChanged()
        }

        if (existing > 0) {
            Spacer(Modifier.height(8.dp))
            var sure by remember { mutableStateOf(false) }
            GhostBtn(if (sure) "Tap again to remove all $existing" else
                "Remove all $existing reconstructed days", color = T.Danger) {
                if (!sure) { sure = true; return@GhostBtn }
                Reconstruct.clear(ctx); sure = false; tick++
                msg = "Removed. The log is GPS fixes only again."
                onChanged()
            }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }
    }
}

package com.tesseract.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles the Leave / TDY buttons on the "you are off station" notification. */
class StatusReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val date = intent.getStringExtra("date") ?: Store.today()
        val status = intent.getStringExtra("status") ?: return
        Store.setStatus(ctx, date, status)
        ctx.getSystemService(NotificationManager::class.java).cancel(Notifier.ID_STATUS)
        Notifier.alert(ctx, "$date marked $status", "Change it any time from the dashboard.")
    }
}

package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A backup is the whole app in one JSON file: every fix, every day label, every datum
 * and every setting. The CSV exports are reports — readable, but lossy and not
 * restorable. This is the file that lets the log outlive the phone.
 */
object Backup {

    const val VERSION = 1

    data class Result(
        val samplesAdded: Int,
        val samplesSkipped: Int,
        val tagsAdded: Int,
        val tagsKept: Int,
        val datumsAdded: Int,
        val settingsRestored: Boolean,
        val error: String? = null
    )

    fun build(ctx: Context): String {
        val o = JSONObject()
        o.put("format", "tesseract-backup")
        o.put("version", VERSION)
        o.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date()))
        o.put("samples", JSONArray(Store.rawText(ctx, Store.F_SAMPLES).ifBlank { "[]" }))
        o.put("tags", JSONObject(Store.rawText(ctx, Store.F_TAGS).ifBlank { "{}" }))
        o.put("datums", JSONArray(Store.rawText(ctx, Store.F_DATUMS).ifBlank { "[]" }))
        o.put("settings", JSONObject(Store.settingsMap(ctx).mapValues { it.value ?: "" }))
        return o.toString(2)
    }

    fun suggestedFileName(): String =
        "tesseract-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"

    /** Written alongside the CSVs so the monthly report doubles as an off-device backup. */
    fun writeForReport(ctx: Context): File {
        val dir = File(ctx.filesDir, "reports").apply { mkdirs() }
        return File(dir, suggestedFileName()).apply { writeText(build(ctx)) }
    }

    /**
     * Merge keeps everything already on the phone and adds only what is missing — an
     * existing day label is never overwritten by an older backup. Replace wipes first.
     */
    fun restore(ctx: Context, json: String, replace: Boolean): Result {
        val root = try {
            JSONObject(json)
        } catch (e: Exception) {
            return Result(0, 0, 0, 0, 0, false, "That file is not readable as a backup.")
        }
        if (root.optString("format") != "tesseract-backup")
            return Result(0, 0, 0, 0, 0, false, "That file is not a Tesseract backup.")
        if (root.optInt("version", 0) > VERSION)
            return Result(0, 0, 0, 0, 0, false,
                "That backup came from a newer version of the app. Update first.")

        if (replace) {
            Store.writeRaw(ctx, Store.F_SAMPLES, "[]")
            Store.writeRaw(ctx, Store.F_TAGS, "{}")
            Store.writeRaw(ctx, Store.F_DATUMS, "[]")
        }

        // ---- samples: dedupe on timestamp + coordinates ----
        val existing = JSONArray(Store.rawText(ctx, Store.F_SAMPLES).ifBlank { "[]" })
        val seen = HashSet<String>()
        for (i in 0 until existing.length()) seen.add(key(existing.getJSONObject(i)))

        val incoming = root.optJSONArray("samples") ?: JSONArray()
        var added = 0
        var skipped = 0
        for (i in 0 until incoming.length()) {
            val o = incoming.getJSONObject(i)
            if (seen.add(key(o))) { existing.put(o); added++ } else skipped++
        }
        Store.writeRaw(ctx, Store.F_SAMPLES, existing.toString())

        // ---- tags: never clobber a label already on this phone ----
        val curTags = JSONObject(Store.rawText(ctx, Store.F_TAGS).ifBlank { "{}" })
        val inTags = root.optJSONObject("tags") ?: JSONObject()
        var tagsAdded = 0
        var tagsKept = 0
        inTags.keys().forEach { d ->
            if (curTags.has(d)) tagsKept++ else { curTags.put(d, inTags.get(d)); tagsAdded++ }
        }
        Store.writeRaw(ctx, Store.F_TAGS, curTags.toString())

        // ---- datums: add by id if absent ----
        val curD = JSONArray(Store.rawText(ctx, Store.F_DATUMS).ifBlank { "[]" })
        val ids = HashSet<String>()
        for (i in 0 until curD.length()) ids.add(curD.getJSONObject(i).optString("id"))
        val inD = root.optJSONArray("datums") ?: JSONArray()
        var dAdded = 0
        for (i in 0 until inD.length()) {
            val o = inD.getJSONObject(i)
            if (ids.add(o.optString("id"))) { curD.put(o); dAdded++ }
        }
        Store.writeRaw(ctx, Store.F_DATUMS, curD.toString())

        // ---- settings: only on a full replace, so a restore cannot silently
        //      change the state you are counting on a phone already set up ----
        var settingsRestored = false
        if (replace) {
            root.optJSONObject("settings")?.let { s ->
                val map = HashMap<String, Any?>()
                s.keys().forEach { k -> map[k] = s.get(k) }
                Store.applySettings(ctx, map)
                settingsRestored = true
            }
        }

        return Result(added, skipped, tagsAdded, tagsKept, dAdded, settingsRestored)
    }

    private fun key(o: JSONObject) =
        "${o.optLong("ts")}|${o.optString("date")}|${o.optDouble("lat")}|${o.optDouble("lon")}"
}

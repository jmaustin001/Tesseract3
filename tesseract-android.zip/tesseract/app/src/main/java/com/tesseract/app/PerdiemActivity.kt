package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class PerdiemActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { PerdiemScreen() } }
    }
}

private fun money(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

@Composable
private fun PerdiemScreen() {
    val ctx = LocalContext.current
    var days by remember { mutableStateOf(Store.prefString(ctx, "tdyDays", "5")) }
    var tierIndex by remember { mutableIntStateOf(4) }   // top tier, the DC area
    var customRate by remember { mutableStateOf(Store.prefString(ctx, "tdyCustom", "")) }
    var b by remember { mutableStateOf(Store.prefString(ctx, "tdyB", "0")) }
    var l by remember { mutableStateOf(Store.prefString(ctx, "tdyL", "0")) }
    var d by remember { mutableStateOf(Store.prefString(ctx, "tdyD", "0")) }
    var longTerm by remember { mutableStateOf(false) }
    var tdyMsg by remember { mutableStateOf("") }
    var locTick by remember { mutableIntStateOf(0) }
    var tripMonth by remember {
        mutableIntStateOf(java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1)
    }
    var activeLoc by remember { mutableStateOf<Locality?>(null) }


    var ratesTick by remember { mutableIntStateOf(0) }
    val table = remember(ratesTick) { Rates.current(ctx) }
    val tiers = table.tiers
    val baseTier = tiers[tierIndex.coerceIn(0, tiers.lastIndex)]
    // A saved destination wins, then a typed rate, then the tier buttons. When a
    // total does not match a published tier the meal split is scaled from the
    // nearest one, so breakfast, lunch and dinner still deduct sensibly.
    fun scaled(total: Double): Perdiem.Tier {
        val near = tiers.minByOrNull { kotlin.math.abs(it.total - total) } ?: baseTier
        val f = total / near.total
        return Perdiem.Tier(total, near.b * f, near.l * f, near.d * f)
    }

    // exact equality on a Double read back from storage or typed by hand is
    // fragile once cents are involved, so match within a tenth of a cent
    fun sameRate(a: Double, b: Double) = kotlin.math.abs(a - b) < 0.001

    val tier = when {
        activeLoc != null -> tiers.firstOrNull { sameRate(it.total, activeLoc!!.mie) }
            ?: scaled(activeLoc!!.mie)
        customRate.toDoubleOrNull() != null -> scaled(customRate.toDouble())
        else -> baseTier
    }

    val r = Perdiem.compute(
        days = days.toIntOrNull() ?: 0,
        tier = tier,
        breakfasts = b.toIntOrNull() ?: 0,
        lunches = l.toIntOrNull() ?: 0,
        dinners = d.toIntOrNull() ?: 0,
        longTerm = longTerm
    )


    TessScreen("TDY per diem", "meals and incidentals") {

        RatesBanner(ratesTick) { ratesTick++ }

        Spacer(Modifier.height(10.dp))
        LocalityCard(locTick, tripMonth, activeLoc,
            onMonth = { tripMonth = it },
            onPick = { activeLoc = it },
            onChanged = { locTick++ })

        Spacer(Modifier.height(10.dp))
        TCard("what you would draw", T.Gold) {
            Text(money(r.net), fontSize = 38.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text("${r.days} day${if (r.days == 1) "" else "s"} of M&IE",
                fontSize = 12.sp, color = T.Mid)
            Spacer(Modifier.height(14.dp))
            Line("${r.fullDays} full day${if (r.fullDays == 1) "" else "s"} at ${money(r.perFullDay)}",
                money(r.fullDays * r.perFullDay))
            Line("${r.travelDays} travel day${if (r.travelDays == 1) "" else "s"} at 75%",
                money(r.travelDays * r.perTravelDay))
            if (r.mealDeductions > 0)
                Line("Meals provided", "− " + money(r.mealDeductions), true)
            HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 8.dp))
            Line("Net", money(r.net), false, bold = true)
        }

        Spacer(Modifier.height(10.dp))
        TCard("the trip", T.Cyan) {
            DarkField(days, "Days in travel status", Modifier.fillMaxWidth(), integer = true) {
                days = it; Store.setPrefString(ctx, "tdyDays", it)
            }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Count my last TDY from the log", color = T.Cyan) {
                val run = Store.lastTdyRun(ctx)
                days = if (run == null) days else run.second.toString()
                tdyMsg = run?.let {
                    "${it.second} days, ${it.first} to ${it.third}"
                } ?: "No TDY days found in the log yet."
            }
            if (tdyMsg.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(tdyMsg, fontSize = 11.sp, color = T.Teal)
            }
            Spacer(Modifier.height(6.dp))
            Hint("Count calendar days, not nights. A four-night trip is five days: the " +
                    "day out and the day back at 75%, the three between at full rate.")

            Spacer(Modifier.height(16.dp))
            Text("LOCALITY M&IE RATE", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                tiers.forEachIndexed { i, t ->
                    val on = tierIndex == i && customRate.isBlank()
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(if (on) T.Gold.copy(alpha = .20f) else T.Glow)
                            .border(1.dp, if (on) T.Gold else T.Edge, RoundedCornerShape(8.dp))
                            .clickable { tierIndex = i; customRate = "" }
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(t.label, fontSize = 12.sp,
                            color = if (on) T.Gold else T.Mid,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
            if (activeLoc != null) {
                Spacer(Modifier.height(8.dp))
                Text("Overridden by ${activeLoc!!.name} at ${money(activeLoc!!.mie.toDouble())}",
                    fontSize = 12.sp, color = T.Teal)
            }
            Spacer(Modifier.height(8.dp))
            Hint("$68 is standard CONUS. $92 is the top tier and covers the District, " +
                    "Arlington, Alexandria and Falls Church — so a Pentagon TDY sits there. " +
                    "Look the destination up on the GSA site if you are unsure.")
            Spacer(Modifier.height(10.dp))
            DarkField(customRate, "Or type a rate (OCONUS, or a new fiscal year)",
                Modifier.fillMaxWidth(), numeric = true) { customRate = it; Store.setPrefString(ctx, "tdyCustom", it) }
        }

        Spacer(Modifier.height(10.dp))
        TCard("meals provided", T.Teal) {
            Hint("A meal furnished by the government comes off at its full value, even on " +
                    "a 75% travel day. A dining facility or a conference fee that includes " +
                    "meals counts. A hotel's free breakfast and anything served on a plane " +
                    "do not.")
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(b, "Breakfasts", Modifier.weight(1f), integer = true) { b = it; Store.setPrefString(ctx, "tdyB", it) }
                DarkField(l, "Lunches", Modifier.weight(1f), integer = true) { l = it; Store.setPrefString(ctx, "tdyL", it) }
                DarkField(d, "Dinners", Modifier.weight(1f), integer = true) { d = it; Store.setPrefString(ctx, "tdyD", it) }
            }
            Spacer(Modifier.height(10.dp))
            Text("At this rate: breakfast ${money(tier.b.toDouble())} · " +
                    "lunch ${money(tier.l.toDouble())} · dinner ${money(tier.d.toDouble())}",
                fontSize = 11.sp, color = T.Mid)
            if (r.allMealsProvidedDays > 0) {
                Spacer(Modifier.height(8.dp))
                Hint("On a day where all three are provided you keep the ${money(tier.inc.toDouble())} " +
                        "incidental portion and nothing else.")
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("long-term TDY", T.Violet) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Apply the JTR flat rate", fontSize = 14.sp, color = T.Hi)
                    Text("75% from 31 days, 55% from 181", fontSize = 11.sp, color = T.Low)
                }
                Switch(checked = longTerm, onCheckedChange = { longTerm = it })
            }
            if (longTerm && r.flatMultiplier < 1.0) {
                Spacer(Modifier.height(10.dp))
                Text("Flat rate applied: ${(r.flatMultiplier * 100).toInt()}% of ${money(tier.total.toDouble())} " +
                        "= ${money(r.rate)} a day",
                    fontSize = 12.sp, color = T.Violet)
            }
            Spacer(Modifier.height(10.dp))
            Hint("Long-term flat rates are an authorizing-official decision, not automatic. " +
                    "Confirm which applies before counting on it.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("lodging", T.Edge) {
            Hint("Not included here. M&IE is a flat allowance you keep whatever you spend; " +
                    "lodging is reimbursed against what you actually paid, up to the cap. " +
                    "If you stay at your own place you incur nothing and claim nothing — " +
                    "that is simply correct, and it costs you no M&IE.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("tax", T.Teal) {
            Hint("TDY per diem paid under an accountable plan is not taxable income and does " +
                    "not appear on your W-2. Relocation money is the opposite — every dollar " +
                    "of TQSE is wages. That is why they are separate screens.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("before you rely on this", T.Danger) {
            Hint("A planning estimate. Your travel office settles the voucher against the " +
                    "JTR, not this app. Percentages — the 75 percent travel day, the TQSE " +
                    "splits, the long-term flat rates — come from regulation and change " +
                    "rarely; when they do, they arrive in an app update rather than a rate " +
                    "file.")
        }
    }
}

@Composable
private fun Line(label: String, value: String, minus: Boolean = false, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (minus) T.Danger else T.Hi)
    }
}

@Composable
private fun RatesBanner(tick: Int, onRefreshed: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }

    val table = remember(tick) { Rates.current(ctx) }
    val left = remember(tick) { Rates.daysLeft(ctx) }
    val expired = left < 0

    TCard("rates in use", if (expired) T.Danger else if (left < 45) T.Gold else T.Edge) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("FY${table.fiscalYear}", fontSize = 16.sp,
                    fontWeight = FontWeight.Bold, color = T.Hi)
                Text(
                    when {
                        expired -> "Expired ${-left} days ago on ${table.expires}"
                        left < 45 -> "Expires in $left days, on ${table.expires}"
                        else -> "Good until ${table.expires}"
                    },
                    fontSize = 11.sp,
                    color = if (expired) T.Danger else if (left < 45) T.Gold else T.Low
                )
            }
            TextButton(onClick = {
                if (!busy) {
                    busy = true; msg = ""
                    scope.launch {
                        Rates.fetch(ctx).fold(
                            onSuccess = {
                                msg = "Updated to FY${it.fiscalYear}."; bad = false; onRefreshed()
                            },
                            onFailure = { msg = it.message ?: "Could not fetch."; bad = true }
                        )
                        busy = false
                    }
                }
            }) { Text(if (busy) "…" else "Check", fontSize = 12.sp, color = T.Cyan) }
        }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 11.sp, color = if (bad) T.Danger else T.Teal)
        }

        if (expired) {
            Spacer(Modifier.height(10.dp))
            Hint("GSA republishes every 1 October. Tap Check to pull the new table, or type " +
                    "a rate by hand. The buttons below are last year's numbers until one or " +
                    "the other happens.")
        } else {
            Spacer(Modifier.height(8.dp))
            Hint("Source: ${table.source}. Last checked ${Rates.lastFetched(ctx)}. " +
                    "Rates are read from a small file rather than scraped from a web page, " +
                    "so a site redesign cannot quietly feed this the wrong number.")
        }
    }
}

private val MONTHS = listOf("Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec")

@Composable
private fun LocalityCard(
    tick: Int,
    month: Int,
    active: Locality?,
    onMonth: (Int) -> Unit,
    onPick: (Locality?) -> Unit,
    onChanged: () -> Unit
) {
    val ctx = LocalContext.current
    val saved = remember(tick) { Localities.all(ctx) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newMie by remember { mutableStateOf("") }
    var newLodging by remember { mutableStateOf("") }
    var seasonal by remember { mutableStateOf(false) }
    var monthly by remember { mutableStateOf(List(12) { "" }) }

    TCard("destination", if (active != null) T.Teal else T.Gold) {
        if (active == null) {
            Hint("Rates are per locality and lodging moves month by month. Look a place up " +
                    "once on GSA, save it here, and every trip after is one tap. Nothing is " +
                    "guessed — the numbers are the ones you read off the official table.")
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(active.name, fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Hi)
                    Text("M&IE ${money(active.mie.toDouble())} · lodging " +
                            "${money(active.lodgingFor(month).toDouble())} in ${MONTHS[month - 1]}" +
                            if (active.seasonal) " · seasonal" else "",
                        fontSize = 11.sp, color = T.Mid)
                }
                TextButton(onClick = { onPick(null) }) {
                    Text("Clear", fontSize = 12.sp, color = T.Mid)
                }
            }
        }

        if (saved.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            saved.forEach { l ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { onPick(l) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (active?.id == l.id) T.Teal else T.Edge))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(l.name, fontSize = 14.sp, color = T.Hi)
                        Text("FY${l.fiscalYear} · ${money(l.rateFor(month).toDouble())} in ${MONTHS[month - 1]}",
                            fontSize = 10.sp, color = T.Low)
                    }
                    TextButton(onClick = { Localities.delete(ctx, l.id); onChanged() }) {
                        Text("Remove", fontSize = 11.sp, color = T.Low)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("MONTH IN QUARTERS", fontSize = 9.sp, color = T.Low,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(7.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            MONTHS.forEachIndexed { i, m ->
                val on = month == i + 1
                Box(
                    Modifier.clip(RoundedCornerShape(7.dp))
                        .background(if (on) T.Teal.copy(alpha = .20f) else T.Glow)
                        .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(7.dp))
                        .clickable { onMonth(i + 1) }
                        .padding(horizontal = 11.dp, vertical = 8.dp)
                ) { Text(m, fontSize = 11.sp, color = if (on) T.Teal else T.Mid) }
            }
        }

        Spacer(Modifier.height(14.dp))
        if (!adding) {
            GhostBtn("Add a destination", color = T.Gold) { adding = true }
        } else {
            DarkField(query, "City, state or ZIP", Modifier.fillMaxWidth()) { query = it }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Look it up on GSA", color = T.Cyan) {
                val fy = Rates.current(ctx).fiscalYear.let { if (it > 0) it else 2026 }
                ctx.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse(Localities.gsaUrl(query, fy)))
                )
            }
            Spacer(Modifier.height(6.dp))
            Hint("Opens the official table. Read off M&IE and the lodging for the month you " +
                    "will be there, then type them below.")

            Spacer(Modifier.height(12.dp))
            DarkField(newName, "Name it", Modifier.fillMaxWidth()) { newName = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(newMie, "M&IE", Modifier.weight(1f), numeric = true) { newMie = it }
                DarkField(newLodging, "Lodging", Modifier.weight(1f), numeric = true) {
                    newLodging = it
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lodging changes by month", fontSize = 13.sp, color = T.Hi)
                    Text("True for the DC area and most resort towns",
                        fontSize = 10.sp, color = T.Low)
                }
                Switch(checked = seasonal, onCheckedChange = { seasonal = it })
            }
            if (seasonal) {
                Spacer(Modifier.height(10.dp))
                MONTHS.chunked(3).forEachIndexed { row, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        chunk.forEachIndexed { col, m ->
                            val idx = row * 3 + col
                            DarkField(monthly[idx], m, Modifier.weight(1f), numeric = true) { v ->
                                monthly = monthly.toMutableList().also { it[idx] = v }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Hint("Any month left blank falls back to the single lodging figure above.")
            }

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryBtn("Save destination", Modifier.weight(1f), accent = T.Teal) {
                    val base = newLodging.toDoubleOrNull() ?: 0.0
                    val list = if (!seasonal) List(12) { base }
                    else (0..11).map { monthly[it].toDoubleOrNull() ?: base }
                    val lodgingOk = seasonal || (newLodging.toDoubleOrNull() ?: 0.0) > 0.0
                    if (newName.isNotBlank() && (newMie.toDoubleOrNull() ?: 0.0) > 0.0 && lodgingOk) {
                        val l = Locality(
                            Localities.newId(), newName.trim(),
                            newMie.toDoubleOrNull() ?: 68.0, list,
                            Rates.current(ctx).fiscalYear, Store.today()
                        )
                        Localities.upsert(ctx, l)
                        onPick(l); onChanged()
                        adding = false
                        newName = ""; newMie = ""; newLodging = ""
                        seasonal = false; monthly = List(12) { "" }
                    }
                }
                GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { adding = false }
            }
            if ((newLodging.toDoubleOrNull() ?: 0.0) <= 0.0 && !seasonal) {
                Spacer(Modifier.height(8.dp))
                Text("Lodging is needed as well as M&IE — TQSE runs off both, and a " +
                        "destination saved without it computes lodging as zero.",
                    fontSize = 12.sp, color = T.Danger)
            }
            Spacer(Modifier.height(8.dp))
            Hint("Saved against FY${Rates.current(ctx).fiscalYear}. When the fiscal year " +
                    "turns over the card will still show the year it was entered, so a stale " +
                    "figure is visible rather than silent.")
        }
    }
}

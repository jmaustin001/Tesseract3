package com.tesseract.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Reports {

    /** One row per day: the file a CPA actually reads. */
    fun dayCsv(ctx: Context, year: Int): String {
        val counted = Store.countedState(ctx)
        val pcs = Store.pcsDate(ctx)
        val sb = StringBuilder(
            "date,pcs_phase,states_present,travel_day,datums,category,duty_status,place,note," +
                    "fixes,counts_as_${counted.lowercase()}_day,earned_income,income_state," +
                    "income_state_source,income_basis\n"
        )
        Store.days(ctx, year).forEach { d ->
            sb.append(d.date).append(',')
                .append('"')
                .append(if (pcs.isBlank()) "" else if (d.date < pcs) "pre-PCS" else "post-PCS")
                .append('"').append(',')
                .append('"').append(d.states.joinToString("|")).append('"').append(',')
                .append(if (d.states.size > 1) "yes" else "no").append(',')
                .append('"').append(d.zones.joinToString("|")).append('"').append(',')
                .append('"').append(d.status).append('"').append(',')
                .append('"').append(Status.dutyStatus(d.status)).append('"').append(',')
                .append('"').append(Status.place(d.status)).append('"').append(',')
                .append('"').append(d.note.replace("\"", "'")).append('"').append(',')
                .append(d.sampleCount).append(',')
                .append(if (counted in d.states) "yes" else "no").append(',')
                .append(if (Workdays.earned(ctx, d)) "yes" else "no").append(',')
                .append(if (Workdays.earned(ctx, d)) Store.incomeStateOf(ctx, d) else "").append(',')
                .append(if (Store.incomeStateOverride(ctx, d.date) != null) "set by hand"
                        else "duty-hours fix").append(',')
                .append('"').append(Workdays.reason(ctx, d))
                .append(if (Workdays.earned(ctx, d) && !d.fixDuringDuty)
                    " (no fix during duty hours)" else "").append('"')
                .append('\n')
        }
        Store.gapDays(ctx, year).forEach {
            sb.append(it).append(',').append('"')
              .append(if (pcs.isBlank()) "" else if (it < pcs) "pre-PCS" else "post-PCS")
              .append("\",\"\",no,\"\",\"NO DATA\",\"\",\"\",\"\",0,unknown,unknown,,,\"no data\"\n")
        }
        return sb.toString()
    }

    /** One row per fix: the evidence underneath. */
    fun sampleCsv(ctx: Context, year: Int): String {
        val sb = StringBuilder(
            "date,time,timezone,state,datum,datum_role,latitude,longitude,accuracy_m,manual_entry\n"
        )
        val tf = SimpleDateFormat("HH:mm:ss", Locale.US)
        Store.samples(ctx).filter { it.date.startsWith("$year-") }.forEach { s ->
            sb.append(s.date).append(',').append(tf.format(Date(s.timestamp))).append(',')
                .append(s.tz).append(',').append(s.state).append(',')
                .append('"').append(s.zoneName).append('"').append(',')
                .append(s.zoneRole).append(',')
                .append(s.lat).append(',').append(s.lon).append(',')
                .append(s.accuracyM).append(',').append(s.manual).append('\n')
        }
        return sb.toString()
    }

    fun files(ctx: Context, year: Int): ArrayList<Uri> {
        val dir = File(ctx.filesDir, "reports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val a = File(dir, "tesseract-by-day-$year-$stamp.csv").apply { writeText(dayCsv(ctx, year)) }
        val b = File(dir, "tesseract-fixes-$year-$stamp.csv").apply { writeText(sampleCsv(ctx, year)) }
        // The backup rides along, so every report you send is also an off-device copy
        // of the whole log — the one that can actually be restored from.
        val c = Backup.writeForReport(ctx)
        val d = Allocation.writeFile(ctx, Allocation.compute(ctx, year))
        val e = Domicile.writeFile(ctx)
        val auth = "${ctx.packageName}.fileprovider"
        return arrayListOf(
            FileProvider.getUriForFile(ctx, auth, a),
            FileProvider.getUriForFile(ctx, auth, b),
            FileProvider.getUriForFile(ctx, auth, c),
            FileProvider.getUriForFile(ctx, auth, d),
            FileProvider.getUriForFile(ctx, auth, e)
        )
    }

    /** Hand the files to any app - Drive, Sheets, Files - without composing an email. */
    fun shareIntent(ctx: Context, year: Int): Intent {
        val uris = files(ctx, year)
        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "text/csv"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            putExtra(Intent.EXTRA_SUBJECT, "Tesseract log $year")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun emailIntent(ctx: Context, year: Int): Intent {
        val uris = files(ctx, year)
        val counted = Store.countedState(ctx)
        val home = Store.homeState(ctx)
        val days = Store.days(ctx, year)
        val pcs = Store.pcsDate(ctx)
        val to = Store.email(ctx)

        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, "Residency day log — $year")
            putExtra(Intent.EXTRA_TEXT, buildString {
                append("Day log through ${Store.today()}\n\n")
                append("Days in ${States.fullName(counted)}: ")
                append("${Store.stateDays(ctx, counted, year)} of ${Store.limit(ctx)}\n")
                append("  duty ${days.count { Status.dutyStatus(it.status) == "Duty" }}")
                append(" · TDY ${days.count { Status.dutyStatus(it.status) == "TDY" }}")
                append(" · leave ${days.count { Status.dutyStatus(it.status) == "Leave" }}\n")
                append("Days in ${States.fullName(home)}: ${Store.stateDays(ctx, home, year)}\n")
                if (pcs.isNotBlank()) {
                    append("\nDuty station changed $pcs\n")
                    append("  before: ${Store.stateDaysBefore(ctx, counted, year, pcs)} in $counted")
                    append(", ${Store.stateDaysBefore(ctx, home, year, pcs)} in $home\n")
                    append("  after:  ${Store.stateDaysFrom(ctx, counted, year, pcs)} in $counted")
                    append(", ${Store.stateDaysFrom(ctx, home, year, pcs)} in $home\n")
                }
                append("\nIncome days (worked, by where the day was spent)\n")
                append("  ${States.fullName(counted)}: ${Store.earningDays(ctx, counted, year)}\n")
                append("  ${States.fullName(home)}: ${Store.earningDays(ctx, home, year)}\n")
                append("  total worked: ${Store.earningDaysTotal(ctx, year)}\n")
                append("  (weekends, federal holidays and leave excluded; ")
                append("days you marked off by hand are excluded too)\n\n")
                append("Days with a record: ${days.size}\n")
                val travel = days.count { it.states.size > 1 }
                if (travel > 0) append("Travel days (more than one state): $travel\n")
                val gaps = Store.gapDays(ctx, year).size
                if (gaps > 0) append("Days with no data: $gaps\n")
                val untagged = Store.untaggedOutDays(ctx, year).size
                if (untagged > 0) append("Off-station days not yet labeled: $untagged\n")
                append("\nFive files attached:\n")
                append("  the day-by-day log, one row per calendar day\n")
                append("  the raw fixes behind it, one row per reading\n")
                append("  a JSON backup that can be restored into the app\n")
                append("  the wage allocation worksheet, with the tax estimate\n")
                append("  the domicile evidence checklist")
            })
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}

class ReportWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val year = Store.year()
        val counted = Store.countedState(ctx)
        val n = Store.stateDays(ctx, counted, year)
        val pi = PendingIntent.getActivity(
            ctx, 2, Intent.createChooser(Reports.emailIntent(ctx, year), "Send report"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        Notifier.report(ctx, "Monthly day log ready",
            "$n days in ${States.fullName(counted)} so far this year. Tap to send it.", pi)
        return Result.success()
    }
}

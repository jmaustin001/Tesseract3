package com.tesseract.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object Notifier {
    const val CH_ALERTS = "daycount_alerts"
    const val CH_STATUS = "daycount_status"
    const val CH_REPORTS = "daycount_reports"
    const val CH_PLACE = "tesseract_place"

    const val ID_ALERT = 1001
    const val ID_REPORT = 1002
    const val ID_STATUS = 1003
    const val ID_PLACE = 1004

    fun createChannels(ctx: Context) {
        val m = ctx.getSystemService(NotificationManager::class.java)
        m.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Day limit warnings", NotificationManager.IMPORTANCE_HIGH)
        )
        m.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Off-station prompts", NotificationManager.IMPORTANCE_HIGH)
        )
        m.createNotificationChannel(
            NotificationChannel(CH_REPORTS, "Scheduled reports", NotificationManager.IMPORTANCE_DEFAULT)
        )
        m.createNotificationChannel(
            NotificationChannel(CH_PLACE, "New places", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    fun alert(ctx: Context, title: String, body: String) =
        post(ctx, CH_ALERTS, title, body, ID_ALERT, openApp(ctx), emptyList())

    fun report(ctx: Context, title: String, body: String, pi: PendingIntent) =
        post(ctx, CH_REPORTS, title, body, ID_REPORT, pi, emptyList())

    /**
     * The daily category prompt. A notification shows at most three buttons, so the
     * two likeliest go on the notification and the body opens the full five-way picker.
     */
    fun askDay(ctx: Context, date: String, summary: String, guess: String) {
        val alt = if (guess == Status.DUTY) Status.LEAVE_RES else Status.DUTY
        val actions = listOf(
            action(ctx, date, guess),
            action(ctx, date, alt)
        )
        val open = PendingIntent.getActivity(
            ctx, date.hashCode(),
            Intent(ctx, DayPromptActivity::class.java)
                .putExtra("date", date).putExtra("summary", summary).putExtra("guess", guess)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        post(
            ctx, CH_STATUS,
            "How should $date be counted?",
            "$summary\nTap for all five options and a note field.",
            ID_STATUS, open, actions
        )
    }

    /** One notification button that writes a category straight into the log. */
    /**
     * Fired when you have stayed somewhere unknown long enough for it to be a
     * place rather than a stopover.
     */
    fun askNewPlace(ctx: Context, d: DwellWatch.Dwell) {
        val add = PendingIntent.getActivity(
            ctx, 4001,
            Intent(ctx, DatumsActivity::class.java)
                .putExtra("newLat", d.lat).putExtra("newLon", d.lon)
                .putExtra("newState", d.state)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val ignore = PendingIntent.getBroadcast(
            ctx, 4002,
            Intent(ctx, DwellReceiver::class.java)
                .putExtra("lat", d.lat).putExtra("lon", d.lon),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val b = NotificationCompat.Builder(ctx, CH_PLACE)
            .setSmallIcon(R.drawable.ic_stat_tesseract)
            .setContentTitle("${d.hours} hours somewhere new")
            .setContentText("You have been in ${States.fullName(d.state)}, outside every " +
                    "datum, for ${d.hours} hours. Worth adding as a place?")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "You have been in ${States.fullName(d.state)}, outside every datum, for " +
                        "${d.hours} hours. If you will be back, adding it as a datum means " +
                        "these days get labeled on their own instead of landing in Off station."
            ))
            .setContentIntent(add)
            .addAction(NotificationCompat.Action(0, "Add as a datum", add))
            .addAction(NotificationCompat.Action(0, "Not a place", ignore))
            .setAutoCancel(true)
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(ID_PLACE, b.build())
        } catch (e: SecurityException) { }
    }

    private fun action(ctx: Context, date: String, status: String): NotificationCompat.Action {
        val i = Intent(ctx, StatusReceiver::class.java)
            .putExtra("date", date).putExtra("status", status)
        val pi = PendingIntent.getBroadcast(
            ctx, (date + status).hashCode(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Action(0, status, pi)
    }

    private fun post(
        ctx: Context, channel: String, title: String, body: String,
        id: Int, pi: PendingIntent, actions: List<NotificationCompat.Action>
    ) {
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_tesseract)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pi)
            .setAutoCancel(true)
        actions.forEach { b.addAction(it) }
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
        } catch (e: SecurityException) { /* notifications not permitted */ }
    }

    private fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}

Pay tracking, from the LES rather than from a screenshot.

A new Pay screen takes four figures off the year-to-date column each payday —
gross, taxable, federal withheld, state withheld. Twenty seconds, and nothing
is stored but the numbers. No image, no document, nothing carrying your name.

Everything is recorded as year to date rather than per period, which is what
makes a missed payday harmless: the next LES restates the year, so one entry
catches the record up and there is no gap to go back and fill. Per-period
amounts are worked out by subtraction when they are wanted.

It projects where the year lands, feeds the wage base straight into the
allocation screen so it is not typed twice, and flags the state withholding
line when it reads zero — which it will, while your record says Florida, even
as the liability accrues.

Reminders are optional and arrive on payday. Set any one payday and the rest
are counted from it. They are ordinary notifications: they appear when there is
something to enter and go when dismissed. Nothing sits in the status bar
permanently.

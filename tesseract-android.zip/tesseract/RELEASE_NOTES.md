The LES form works out pre-tax deductions for you.

Pre-tax deductions — TSP, FEHB, FEDVIP, FSA and the like — are exactly what
separates gross pay from taxable wages, so the form now shows gross minus
taxable as the pre-tax total the moment both are typed, and saves it. There is
nothing to add up. The box stays for the rare case where you want a different
figure; if you type one, the form shows how far it is from gross minus taxable.

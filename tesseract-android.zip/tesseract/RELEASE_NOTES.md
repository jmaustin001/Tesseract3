The $ was being drawn and then thrown away.

Each square had a rounded-corner clip on it, and a clip trims its children —
so the glyph, which is taller than a ten-pixel square, was cut to nothing.
The corners are now rounded by the background itself rather than by a clip,
and the mark survives. It is also drawn on top of the diagonal split instead
of underneath it, so travel days that earned show their $ too.

The mark appears on every workday in both views, whichever state earned it.
Pinch the grid and it grows with everything else.

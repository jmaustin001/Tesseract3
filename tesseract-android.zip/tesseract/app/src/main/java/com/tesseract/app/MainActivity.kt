package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF16232B)
private val Paper = Color(0xFFE7EBEE)
private val CardBg = Color(0xFFFFFFFF)
private val Gold = Color(0xFFC0842B)
private val Teal = Color(0xFF2F6E6B)
private val Muted = Color(0xFF5A6A72)
private val Warn = Color(0xFFA33B2A)

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Store.onboarded(this)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }

        val want = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(want.toTypedArray())
        Scheduler.scheduleNextCheck(this)
        setContent { MaterialTheme { Dashboard() } }
    }

    fun requestBackground() {
        if (Build.VERSION.SDK_INT >= 29)
            perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
    }

    @SuppressLint("MissingPermission")
    fun here(onResult: (Double, Double) -> Unit) {
        LocationServices.getFusedLocationProviderClient(this)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { it?.let { l -> onResult(l.latitude, l.longitude) } }
    }

    var onFileChosen: ((Uri) -> Unit)? = null
    var onFileCreated: ((Uri) -> Unit)? = null

    private val openDoc =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onFileChosen?.invoke(it) }
        }

    private val createDoc =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            uri?.let { onFileCreated?.invoke(it) }
        }

    fun pickBackupFile(onPicked: (Uri) -> Unit) {
        onFileChosen = onPicked
        openDoc.launch(arrayOf("application/json", "text/plain", "*/*"))
    }

    fun saveBackupFile(name: String, onCreated: (Uri) -> Unit) {
        onFileCreated = onCreated
        createDoc.launch(name)
    }

    fun writeTo(uri: Uri, text: String) =
        contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }

    fun readFrom(uri: Uri): String =
        contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""

    fun restartSetup() {
        startActivity(Intent(this, OnboardingActivity::class.java))
        finish()
    }
}

@Composable
fun Dashboard() {
    val ctx = LocalContext.current
    val year = remember { Store.year() }
    var tick by remember { mutableIntStateOf(0) }

    val counted = remember(tick) { Store.countedState(ctx) }
    val homeSt = remember(tick) { Store.homeState(ctx) }
    val days = remember(tick) { Store.days(ctx, year) }
    val countedDays = remember(tick) { Store.stateDays(ctx, counted, year) }
    val homeDays = remember(tick) { Store.stateDays(ctx, homeSt, year) }
    val offDays = remember(tick) { Store.offStationDays(ctx, year) }
    val untagged = remember(tick) { Store.untaggedOutDays(ctx, year) }
    val gaps = remember(tick) { Store.gapDays(ctx, year) }
    val projected = remember(tick) { Store.projectedStateDays(ctx, counted, year) }
    val limit = remember(tick) { Store.limit(ctx) }
    val datums = remember(tick) { Store.datums(ctx) }

    Column(
        Modifier.fillMaxSize().background(Paper).verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text("Tesseract", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Ink)
        Text("Residency log · $year", fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(16.dp))

        Surface(color = Ink, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$countedDays", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("of $limit days in ${States.fullName(counted)}", fontSize = 15.sp,
                        color = Color(0xFFAFC0C8), modifier = Modifier.padding(bottom = 10.dp))
                }
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { (countedDays.toFloat() / limit).coerceIn(0f, 1f) },
                    color = if (countedDays >= limit) Warn else Gold,
                    trackColor = Color(0xFF2C3F49),
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    if (countedDays < limit) "${limit - countedDays} days left this year."
                    else "${countedDays - limit} days past $limit.",
                    fontSize = 13.sp,
                    color = if (countedDays >= limit) Color(0xFFE8A99C) else Color(0xFFAFC0C8)
                )
                if (projected >= 0) {
                    Spacer(Modifier.height(6.dp))
                    Text("At this pace the year ends near $projected.",
                        fontSize = 12.sp,
                        color = if (projected > limit) Color(0xFFE8A99C) else Color(0xFF8FA3AD))
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("${States.fullName(homeSt)} days", homeDays, Teal, Modifier.weight(1f))
            Stat("Off station", offDays, Muted, Modifier.weight(1f))
            Stat("Days on record", days.size, Ink, Modifier.weight(1f))
        }

        if (untagged.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Panel("Days that need a label (${untagged.size})") {
                Text("Fixes outside every datum. Labelling them is what makes the log defensible.",
                    fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(10.dp))
                untagged.takeLast(8).reversed().forEach { d ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.date, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Ink)
                            Text(d.states.joinToString(", "), fontSize = 12.sp, color = Muted)
                        }
                        TextButton(onClick = {
                            ctx.startActivity(
                                Intent(ctx, DayPromptActivity::class.java)
                                    .putExtra("date", d.date)
                                    .putExtra("summary", "Fix in ${d.states.joinToString(", ")}, off station.")
                                    .putExtra("guess", Status.TDY_OTHER)
                            )
                        }) { Text("Categorise", fontSize = 13.sp) }
                    }
                    HorizontalDivider(color = Color(0xFFE2E7EA))
                }
            }
        }

        if (gaps.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Panel("Missing days (${gaps.size})") {
                Text("No fix landed on these dates. Unexplained gaps are the weak point in any " +
                        "day-count log — fill them while you still remember.",
                    fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(8.dp))
                gaps.takeLast(4).forEach { g ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(g, fontSize = 14.sp, color = Ink, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            Store.addManualDay(ctx, g, counted, Zones.firstWithRole(ctx, Datum.DUTY)); tick++
                        }) { Text(counted, fontSize = 12.sp) }
                        TextButton(onClick = {
                            Store.addManualDay(ctx, g, homeSt, Zones.firstWithRole(ctx, Datum.RESIDENCE)); tick++
                        }) { Text(homeSt, fontSize = 12.sp) }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Panel("Datums") {
            datums.forEach { d ->
                DatumRow(ctx, d) { tick++ }
                HorizontalDivider(color = Color(0xFFE2E7EA))
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = {
                    Store.upsertDatum(ctx, Datum(
                        Store.newDatumId(), "New datum", 0.0, 0.0, 25.0, Datum.OTHER
                    )); tick++
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Add a datum") }
            Spacer(Modifier.height(8.dp))
            Text("Add as many as you need — a second residence, a detail site, a parents' " +
                    "address. Days at any datum are tallied by its role.",
                fontSize = 12.sp, color = Muted)
        }

        Spacer(Modifier.height(12.dp))
        Panel("States") {
            StatePicker("Counting days in", counted) { Store.setCountedState(ctx, it); tick++ }
            Spacer(Modifier.height(14.dp))
            StatePicker("Claimed home state", homeSt) { Store.setHomeState(ctx, it); tick++ }
            Spacer(Modifier.height(10.dp))
            Text("Change the counted state when you PCS and every total, warning and report " +
                    "follows it. Warning stages reset when it changes.",
                fontSize = 12.sp, color = Muted)
        }

        Spacer(Modifier.height(12.dp))
        Panel("Recent days") {
            if (days.isEmpty()) {
                Text("Nothing yet. Tap Check now to log the first fix.", fontSize = 14.sp, color = Muted)
            } else days.reversed().take(8).forEach { d ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(
                        when {
                            counted in d.states -> Gold
                            homeSt in d.states -> Teal
                            else -> Muted
                        }, RoundedCornerShape(2.dp)))
                    Spacer(Modifier.width(10.dp))
                    Text(d.date, fontSize = 14.sp, color = Ink, modifier = Modifier.width(94.dp))
                    Text(d.states.joinToString(", "), fontSize = 14.sp,
                        fontWeight = FontWeight.Medium, color = Ink, modifier = Modifier.weight(1f))
                    Text(d.status.ifBlank { "${d.sampleCount} fixes" }, fontSize = 12.sp, color = Muted)
                }
                HorizontalDivider(color = Color(0xFFE2E7EA))
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = {
                    ctx.startActivity(Intent(ctx, DayPromptActivity::class.java)
                        .putExtra("date", Store.today())
                        .putExtra("summary", "Set or change today's category.")
                        .putExtra("guess", Status.DUTY))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Categorise today") }
        }

        Spacer(Modifier.height(12.dp))
        ScheduleSettings(ctx) { tick++ }

        Spacer(Modifier.height(12.dp))
        ReportSettings(ctx)

        Spacer(Modifier.height(12.dp))
        BackupPanel(ctx) { tick++ }

        Spacer(Modifier.height(12.dp))
        HealthPanel(ctx)

        Spacer(Modifier.height(20.dp))
        Text("A record-keeping aid, not tax advice.", fontSize = 11.sp, color = Muted)
        Spacer(Modifier.height(36.dp))
    }
}

@Composable
private fun DatumRow(ctx: Context, d: Datum, changed: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(d.name) }
    var radius by remember { mutableStateOf(d.radiusMiles.toInt().toString()) }
    var role by remember { mutableStateOf(d.role) }
    var lat by remember { mutableStateOf(d.lat) }
    var lon by remember { mutableStateOf(d.lon) }

    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(
                when (d.role) {
                    Datum.DUTY -> Gold
                    Datum.RESIDENCE -> Teal
                    else -> Muted
                }, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink)
                Text("${Datum.roleLabel(d.role)} · ${d.radiusMiles.toInt()} mi · " +
                        String.format(Locale.US, "%.3f, %.3f", d.lat, d.lon),
                    fontSize = 12.sp, color = Muted)
            }
            TextButton(onClick = { open = !open }) { Text(if (open) "Close" else "Edit", fontSize = 13.sp) }
        }

        if (open) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Name") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    radius, { radius = it.filter { c -> c.isDigit() } },
                    label = { Text("Radius (mi)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedButton(
                    onClick = { (ctx as? MainActivity)?.here { la, lo -> lat = la; lon = lo } },
                    modifier = Modifier.weight(1f)
                ) { Text("Use my position", fontSize = 12.sp) }
            }
            Spacer(Modifier.height(10.dp))
            Text("Role", fontSize = 13.sp, color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Datum.roles.forEach { r ->
                    FilterChip(
                        selected = role == r,
                        onClick = { role = r },
                        label = { Text(Datum.roleLabel(r), fontSize = 11.sp) }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        Store.upsertDatum(ctx, d.copy(
                            name = name.ifBlank { d.name }, role = role,
                            lat = lat, lon = lon,
                            radiusMiles = radius.toDoubleOrNull() ?: d.radiusMiles
                        ))
                        open = false; changed()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Ink),
                    modifier = Modifier.weight(1f)
                ) { Text("Save") }
                OutlinedButton(
                    onClick = { Store.deleteDatum(ctx, d.id); open = false; changed() },
                    modifier = Modifier.weight(1f)
                ) { Text("Delete", color = Warn) }
            }
            Spacer(Modifier.height(4.dp))
            Text("Renaming or moving a datum does not rewrite past days — each fix stored " +
                    "the name it had at the time.", fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
private fun ScheduleSettings(ctx: Context, changed: () -> Unit) {
    var hours by remember { mutableStateOf(Store.checkHours(ctx).joinToString(", ")) }
    var s1 by remember { mutableStateOf(Store.soft1(ctx).toString()) }
    var s2 by remember { mutableStateOf(Store.soft2(ctx).toString()) }
    var hard by remember { mutableStateOf(Store.hard(ctx).toString()) }
    var limit by remember { mutableStateOf(Store.limit(ctx).toString()) }
    var msg by remember { mutableStateOf("") }
    val next = remember(hours) {
        SimpleDateFormat("EEE HH:mm", Locale.US).format(Date(Scheduler.nextCheckTime(ctx)))
    }

    Panel("Schedule and warnings") {
        OutlinedTextField(
            value = hours,
            onValueChange = {
                hours = it
                val p = it.split(",").mapNotNull { h -> h.trim().toIntOrNull() }.filter { h -> h in 0..23 }
                if (p.isNotEmpty()) { Store.setCheckHours(ctx, p); Scheduler.scheduleNextCheck(ctx) }
            },
            label = { Text("Check at these hours") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Text("Next check: $next.", fontSize = 12.sp, color = Muted)

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Num("Soft 1", s1, Modifier.weight(1f)) { s1 = it; it.toIntOrNull()?.let { v -> Store.setSoft1(ctx, v); changed() } }
            Num("Soft 2", s2, Modifier.weight(1f)) { s2 = it; it.toIntOrNull()?.let { v -> Store.setSoft2(ctx, v); changed() } }
            Num("Hard", hard, Modifier.weight(1f)) { hard = it; it.toIntOrNull()?.let { v -> Store.setHard(ctx, v); changed() } }
            Num("Limit", limit, Modifier.weight(1f)) { limit = it; it.toIntOrNull()?.let { v -> Store.setLimit(ctx, v); changed() } }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { Scheduler.checkNow(ctx); msg = "Fix requested." },
            colors = ButtonDefaults.buttonColors(containerColor = Ink),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Check now") }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(6.dp)); Text(msg, fontSize = 12.sp, color = Teal)
        }
    }
}

@Composable
private fun ReportSettings(ctx: Context) {
    var email by remember { mutableStateOf(Store.email(ctx)) }
    Panel("Reports") {
        OutlinedTextField(
            value = email, onValueChange = { email = it; Store.setEmail(ctx, it) },
            label = { Text("Send reports to") }, placeholder = { Text("cpa@example.com") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                ctx.startActivity(Intent.createChooser(
                    Reports.emailIntent(ctx, Store.year()), "Send report"))
            },
            colors = ButtonDefaults.buttonColors(containerColor = Ink),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Email the log now") }
        Spacer(Modifier.height(8.dp))
        Text("A report notification arrives on the 1st of each month.",
            fontSize = 12.sp, color = Muted)
    }
}

@Composable
private fun BackupPanel(ctx: Context, changed: () -> Unit) {
    val act = ctx as? MainActivity
    var msg by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var pendingReplace by remember { mutableStateOf(false) }

    fun doRestore(uri: Uri, replace: Boolean) {
        val a = act ?: return
        val r = Backup.restore(a, a.readFrom(uri), replace)
        if (r.error != null) { msg = r.error; isError = true; return }
        isError = false
        msg = buildString {
            append("Restored ${r.samplesAdded} fixes")
            if (r.samplesSkipped > 0) append(", ${r.samplesSkipped} already present")
            append(". ${r.tagsAdded} day labels added")
            if (r.tagsKept > 0) append(", ${r.tagsKept} kept as they were")
            if (r.datumsAdded > 0) append(". ${r.datumsAdded} datums added")
            if (r.settingsRestored) append(". Settings restored")
            append(".")
        }
        changed()
    }

    Panel("Backup") {
        Text(
            "One JSON file holding every fix, day label, datum and setting. The CSVs are " +
                    "reports and cannot be restored from — this is the file that lets the log " +
                    "outlive the phone.",
            fontSize = 12.sp, color = Muted
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val a = act ?: return@Button
                a.saveBackupFile(Backup.suggestedFileName()) { uri ->
                    a.writeTo(uri, Backup.build(a))
                    msg = "Backup saved."; isError = false
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Ink),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save a backup") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { act?.pickBackupFile { uri -> doRestore(uri, replace = false) } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Restore — merge") }

        Spacer(Modifier.height(8.dp))
        if (!pendingReplace) {
            TextButton(onClick = { pendingReplace = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Restore — replace everything", fontSize = 13.sp)
            }
        } else {
            Text(
                "Replace wipes this phone's log, labels and datums first, then restores the " +
                        "backup including its settings. Use it on a new phone, not on one that " +
                        "has been logging.",
                fontSize = 12.sp, color = Warn
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        pendingReplace = false
                        act?.pickBackupFile { uri -> doRestore(uri, replace = true) }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Choose file", color = Warn) }
                TextButton(onClick = { pendingReplace = false }, modifier = Modifier.weight(1f)) {
                    Text("Cancel")
                }
            }
        }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(msg, fontSize = 12.sp, color = if (isError) Warn else Teal)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Merge adds only what is missing and never overwrites a day label already on " +
                    "this phone, so restoring an old backup cannot undo recent work. Save to " +
                    "Drive or Dropbox rather than the phone itself — a backup on the device it " +
                    "is backing up is not a backup.",
            fontSize = 11.sp, color = Muted
        )
    }
}

@Composable
private fun HealthPanel(ctx: Context) {
    val pm = ctx.getSystemService(PowerManager::class.java)
    val unrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)
    var confirmReset by remember { mutableStateOf(false) }

    Panel("Tracking health") {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text("Battery unrestricted", fontSize = 14.sp, color = Ink, modifier = Modifier.weight(1f))
            Text(if (unrestricted) "OK" else "Needs attention",
                fontSize = 13.sp, color = if (unrestricted) Teal else Warn)
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { (ctx as? MainActivity)?.requestBackground() },
            colors = ButtonDefaults.buttonColors(containerColor = Ink),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Allow location all the time") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:${ctx.packageName}")))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Open app settings") }

        Spacer(Modifier.height(16.dp))
        if (!confirmReset) {
            TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Run setup again", fontSize = 13.sp)
            }
        } else {
            Text("Setup will walk through datums, states and thresholds again. Your logged " +
                    "days are kept.", fontSize = 12.sp, color = Muted)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        Store.resetSetup(ctx, eraseLog = false)
                        (ctx as? MainActivity)?.restartSetup()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Ink),
                    modifier = Modifier.weight(1f)
                ) { Text("Keep log") }
                OutlinedButton(
                    onClick = {
                        Store.resetSetup(ctx, eraseLog = true)
                        (ctx as? MainActivity)?.restartSetup()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Erase all", color = Warn) }
            }
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = { confirmReset = false }, modifier = Modifier.fillMaxWidth()) {
                Text("Cancel", fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Num(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.filter { c -> c.isDigit() }) },
        label = { Text(label, fontSize = 11.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true, modifier = modifier
    )
}

@Composable
private fun Stat(label: String, value: Int, accent: Color, modifier: Modifier = Modifier) {
    Surface(color = CardBg, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text("$value", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = accent)
            Text(label, fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
private fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = CardBg, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Muted)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

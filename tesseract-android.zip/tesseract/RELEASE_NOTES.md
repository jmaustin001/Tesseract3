Duty periods. A PCS splits the year into stretches a CPA reads separately, so
Settings now takes any number of transition dates, each with its own label.
Reports carry a period column and break the day count out by period; the year
view shows the same split.

Also in this build:
- A sixth day-category you name yourself
- "Log me now" takes a high-accuracy fix on command and reports what it recorded
- Travel days render as a diagonally split square in the year grid
- One permanent signing key, so updates install over the top from here on

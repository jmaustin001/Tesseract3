Your own categories are now kept.

A custom category typed once used to disappear with the day. Named patterns
recur — situational telework, a standing detail — so they are saved and appear
on the categorize screen alongside the built-in five, in magenta. Settings has
a card to add and remove them; removing one leaves days already labeled with it
untouched.

The five built-ins stay fixed, because they map onto duty status and place,
which is what every report is built on.

Also fixed: the lodging tax line finally shows in the TQSE summary. It was
being added into the total but never drawn — an edit of mine targeted label
text that did not exist in the file, so it silently did nothing while the
total quietly disagreed with the rows above it.

package com.tesseract.app

import android.content.Context

/**
 * Where the money was earned. Every figure is built from logged days only —
 * nothing is projected — and each worked day is priced at the SF-50 in effect
 * on that date.
 *
 * A worked day is credited to exactly one place, so the place totals add up to
 * the year total: the duty-station datum if the day touched one, otherwise the
 * first named datum it touched, otherwise "elsewhere" in the state that earned it.
 */
object Earnings {

    data class Line(
        val label: String,
        val sub: String,
        val present: Int,
        val worked: Int,
        val dollars: Double
    ) {
        val perDay get() = if (worked > 0) dollars / worked else 0.0
    }

    data class Sf50Line(
        val record: SalaryRecord,
        val from: String,
        val toExclusive: String,
        val perDay: Double,
        val worked: Int,
        val dollars: Double,
        val stateWorked: Int,
        val stateDollars: Double
    )

    data class Report(
        val year: Int,
        val counted: String,
        val worked: Int,
        val dollars: Double,
        val byState: List<Line>,
        val byPlace: List<Line>,
        val dutyPlaces: List<String>,
        val dutyWorked: Int,
        val dutyDollars: Double,
        val stateWorked: Int,
        val stateDollars: Double,
        val bySf50: List<Sf50Line>,
        val taxRate: Double
    ) {
        val dutyTax get() = dutyDollars * taxRate
        val stateTax get() = stateDollars * taxRate
    }

    /** The one place a worked day's pay is credited to. */
    fun placeOf(d: DaySummary, roles: Map<String, String>, incomeState: String): String =
        d.zones.firstOrNull { roles[it] == Datum.DUTY }
            ?: d.zones.firstOrNull { it != Zones.OUT_NAME && roles.containsKey(it) }
            ?: "Elsewhere in $incomeState"

    fun compute(ctx: Context, year: Int): Report {
        val counted = Store.countedState(ctx)
        val roles = Store.datums(ctx).associate { it.name to it.role }
        val days = Store.days(ctx, year)
        val windows = Salaries.windows(ctx, year)
        // read once per report, not once per day — a year of days would otherwise
        // re-parse the salary history and recount the year's workdays each time
        val divisor = Workdays.scheduledWorkdays(ctx, year).coerceAtLeast(1)
        val recs = Salaries.all(ctx).filter { it.rate > 0 }
        fun payOn(date: String): Double {
            if (recs.isEmpty()) return 0.0
            val r = recs.lastOrNull { it.effective.isBlank() || it.effective <= date } ?: recs.first()
            return r.rate / divisor
        }

        class Acc { var present = 0; var worked = 0; var dollars = 0.0; var sub = "" }
        val states = linkedMapOf<String, Acc>()
        val places = linkedMapOf<String, Acc>()
        val sf = windows.map { doubleArrayOf(0.0, 0.0, 0.0, 0.0) } // worked, $, state worked, state $
        val dutyNames = linkedSetOf<String>()
        var worked = 0; var dollars = 0.0
        var dutyWorked = 0; var dutyDollars = 0.0
        var stWorked = 0; var stDollars = 0.0

        for (d in days) {
            Store.resolvedStates(d).forEach { states.getOrPut(it) { Acc() }.present++ }
            d.zones.filter { it != Zones.OUT_NAME && roles.containsKey(it) }
                .forEach { places.getOrPut(it) { Acc() }.present++ }

            if (!Workdays.earned(ctx, d)) continue
            val inc = Store.incomeStateOf(ctx, d)
            val pay = payOn(d.date)
            worked++; dollars += pay

            states.getOrPut(inc) { Acc() }.let { it.worked++; it.dollars += pay }
            val place = placeOf(d, roles, inc)
            places.getOrPut(place) { Acc() }.let { it.worked++; it.dollars += pay; it.sub = inc }

            if (inc == counted) {
                stWorked++; stDollars += pay
                if (roles[place] == Datum.DUTY) {
                    dutyWorked++; dutyDollars += pay; dutyNames.add(place)
                }
            }
            val w = windows.indexOfFirst { d.date >= it.from && d.date < it.toExclusive }
            if (w >= 0) {
                sf[w][0] += 1.0; sf[w][1] += pay
                if (inc == counted) { sf[w][2] += 1.0; sf[w][3] += pay }
            }
        }

        val basis = Store.totalIncome(ctx).let { if (it > 0) it else Workdays.blendedAnnualSalary(ctx, year) }
        val rate = VaTax.effectiveRate(basis, Store.filingJoint(ctx), Store.exemptions(ctx), year)

        return Report(
            year = year,
            counted = counted,
            worked = worked,
            dollars = dollars,
            byState = states.map { (k, a) -> Line(k, "", a.present, a.worked, a.dollars) }
                .sortedByDescending { it.dollars },
            byPlace = places.map { (k, a) ->
                Line(k, if (roles[k] == Datum.DUTY) "duty station" else a.sub,
                    a.present, a.worked, a.dollars)
            }.sortedByDescending { it.dollars },
            dutyPlaces = dutyNames.toList(),
            dutyWorked = dutyWorked,
            dutyDollars = dutyDollars,
            stateWorked = stWorked,
            stateDollars = stDollars,
            bySf50 = windows.mapIndexed { i, w ->
                Sf50Line(w.record, w.from, w.toExclusive, w.record.rate / divisor,
                    sf[i][0].toInt(), sf[i][1], sf[i][2].toInt(), sf[i][3])
            },
            taxRate = rate
        )
    }
}

package com.tesseract.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        Store.loadCategoryKinds(this)
        // Undo only takes snapshots while a screen is open, never for background checks
        registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: android.app.Activity) { Undo.resumed++ }
            override fun onActivityPaused(a: android.app.Activity) { Undo.resumed = (Undo.resumed - 1).coerceAtLeast(0) }
            override fun onActivityCreated(a: android.app.Activity, b: android.os.Bundle?) {}
            override fun onActivityStarted(a: android.app.Activity) {}
            override fun onActivityStopped(a: android.app.Activity) {}
            override fun onActivitySaveInstanceState(a: android.app.Activity, b: android.os.Bundle) {}
            override fun onActivityDestroyed(a: android.app.Activity) {}
        })
        Notifier.createChannels(this)
        Store.seedDefaultCategories(this)
        Scheduler.scheduleNextCheck(this)
        Scheduler.scheduleMonthlyReport(this)
    }
}

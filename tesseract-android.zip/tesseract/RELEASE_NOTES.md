The mark has something burning in it now.

The launcher icon gains a nebulous core — stacked radial gradients behind the
cage, frosted faces on the outer cube, and a white spark at the centre where
the internal edges meet.

Inside the app the mark turns. The outer cube rotates on a 52-second cycle,
the inner one counter-rotates on 71 seconds, so the silhouette keeps changing
instead of looping, and the core breathes on a four-second pulse. It only
animates while the dashboard is on screen.

Launcher icons themselves cannot animate — Android draws them as static
images — so the home screen keeps the still version.

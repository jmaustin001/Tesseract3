package com.tesseract.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        Scheduler.scheduleNextCheck(this)
        Scheduler.scheduleMonthlyReport(this)
    }
}

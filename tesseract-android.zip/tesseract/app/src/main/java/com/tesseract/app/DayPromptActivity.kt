package com.tesseract.app

import android.app.NotificationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A notification can only show three buttons. This is the full five-way picker,
 * opened by tapping the notification body, with a free-text note for orders numbers.
 */
class DayPromptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val date = intent.getStringExtra("date") ?: Store.today()
        val summary = intent.getStringExtra("summary") ?: ""
        val guess = intent.getStringExtra("guess") ?: Status.DUTY

        setContent {
            TessTheme {
                var note by remember { mutableStateOf(Store.statusOf(this, date).second) }
                val existing = Store.statusOf(this, date).first
                var chosen by remember { mutableStateOf(existing.ifBlank { guess }) }
                var bump by remember { mutableIntStateOf(0) }
                var customOn by remember { mutableStateOf(Status.isCustom(existing)) }
                var customText by remember {
                    mutableStateOf(if (Status.isCustom(existing)) existing else "")
                }

                Column(
                    Modifier
                        .fillMaxSize()
                        .background(T.Void)
                        // the custom field and the keyboard both push the Save button
                        // below the fold on a short screen, so this scrolls
                        .verticalScroll(rememberScrollState())
                        .imePadding()
                        .padding(20.dp)
                ) {
                    Spacer(Modifier.height(28.dp))
                    Text("Categorize $date", fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Hi)
                    if (summary.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(summary, fontSize = 13.sp, color = T.Mid)
                    }
                    Spacer(Modifier.height(18.dp))

                    Status.all.forEach { s ->
                        val selected = s == chosen && !customOn
                        Surface(
                            color = if (selected) T.Cyan else T.Deep,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            onClick = { chosen = s; customOn = false }
                        ) {
                            Row(Modifier.padding(16.dp)) {
                                Text(
                                    s, fontSize = 16.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) Color(0xFF051020) else T.Hi,
                                    modifier = Modifier.weight(1f)
                                )
                                if (s == guess) Text(
                                    "GPS suggests", fontSize = 11.sp,
                                    color = if (selected) Color(0xFFAFC0C8) else T.Mid
                                )
                            }
                        }
                    }

                    // sixth option: name it yourself
                    Surface(
                        color = if (customOn) T.Cyan else T.Deep,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        onClick = { customOn = true }
                    ) {
                        Row(Modifier.padding(16.dp)) {
                            Text(
                                if (customOn && customText.isNotBlank()) customText else "Something else…",
                                fontSize = 16.sp,
                                fontWeight = if (customOn) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (customOn) Color(0xFF051020) else T.Hi,
                                modifier = Modifier.weight(1f)
                            )
                            Text("CUSTOM", fontSize = 10.sp,
                                color = if (customOn) Color(0xFF0A2140) else T.Mid)
                        }
                    }

                    if (customOn) {
                        OutlinedTextField(
                            value = customText,
                            onValueChange = { customText = it },
                            label = { Text("Name this category") },
                            placeholder = { Text("Telework, PCS travel, holiday…") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Your own categories are counted and exported like the built-in " +
                                "five, and appear in the CSV as Custom.",
                            fontSize = 11.sp, color = T.Mid)
                    }

                    Spacer(Modifier.height(14.dp))
                    Text("DID THIS DAY EARN?", fontSize = 9.sp, color = T.Mid,
                        fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        remember(bump, chosen, customOn, customText) {
                            Workdays.reasonOn(this@DayPromptActivity, date,
                                if (customOn) customText else chosen)
                        },
                        fontSize = 12.sp, color = T.Mid
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val cur = remember(bump) {
                            Store.workOverride(this@DayPromptActivity, date)
                        }
                        listOf(null to "Automatic", Store.WORKED to "Worked", Store.OFF to "Day off")
                            .forEach { (v, label) ->
                                val on = cur == v
                                Surface(
                                    color = if (on) T.Cyan else T.Deep,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        Store.setWorkOverride(this@DayPromptActivity, date, v)
                                        bump++
                                    }
                                ) {
                                    Text(label, fontSize = 11.sp,
                                        color = if (on) Color(0xFF051020) else T.Hi,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                    }

                    val earnedToday = Workdays.earnedOn(this@DayPromptActivity, date,
                        if (customOn) customText else chosen)
                    if (earnedToday) {
                        Spacer(Modifier.height(14.dp))
                        Text("WHICH STATE EARNED IT", fontSize = 9.sp, color = T.Mid,
                            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Spacer(Modifier.height(6.dp))
                        val auto = Store.days(this@DayPromptActivity)
                            .firstOrNull { it.date == date }?.primaryState ?: "?"
                        val chosenState = remember(bump) {
                            Store.incomeStateOverride(this@DayPromptActivity, date)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val opts = listOf(
                                null to "Auto ($auto)",
                                Store.countedState(this@DayPromptActivity) to
                                        Store.countedState(this@DayPromptActivity),
                                Store.homeState(this@DayPromptActivity) to
                                        Store.homeState(this@DayPromptActivity)
                            )
                            opts.forEach { (v, label) ->
                                val on = chosenState == v
                                Surface(
                                    color = if (on) T.Gold else T.Deep,
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        Store.setIncomeStateOverride(
                                            this@DayPromptActivity, date, v)
                                        bump++
                                    }
                                ) {
                                    Text(label, fontSize = 11.sp,
                                        color = if (on) Color(0xFF051020) else T.Hi,
                                        modifier = Modifier.padding(vertical = 10.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Travel days are a convention, not a fact. When a CPA names " +
                                "one, set it here.", fontSize = 11.sp, color = T.Mid)
                    }

                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Note — orders number, location, purpose") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    if (customOn && customText.isBlank()) {
                        Text("Give the category a name before saving.",
                            fontSize = 12.sp, color = Color(0xFFFF6B5A))
                        Spacer(Modifier.height(8.dp))
                    }
                    Button(
                        enabled = !(customOn && customText.isBlank()),
                        onClick = {
                            val label = if (customOn) customText.trim() else chosen
                            Store.setStatus(this@DayPromptActivity, date, label, note)
                            getSystemService(NotificationManager::class.java).cancel(Notifier.ID_STATUS)
                            finish()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = T.Cyan, contentColor = Color(0xFF051020)),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save") }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Not now")
                    }
                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}

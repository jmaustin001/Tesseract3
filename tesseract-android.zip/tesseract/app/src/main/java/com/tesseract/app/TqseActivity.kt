package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class TqseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { TqseScreen() } }
    }
}

private fun cash(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)
private val MONTHS_T = listOf("Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec")

@Composable
private fun TqseScreen() {
    val ctx = LocalContext.current

    // everything on this screen is remembered between visits — a relocation is
    // planned over weeks, not filled in once
    var days by remember { mutableStateOf(Store.prefString(ctx, "tqDays", "30")) }
    var lodgingMax by remember { mutableStateOf(Store.prefString(ctx, "tqLodgeMax", "199")) }
    var mieMax by remember { mutableStateOf(Store.prefString(ctx, "tqMieMax", "92")) }
    var actualLodging by remember { mutableStateOf(Store.prefString(ctx, "tqRoom", "180")) }
    var lodgingTax by remember { mutableStateOf(Store.prefString(ctx, "tqTax", "0")) }
    var over12 by remember { mutableStateOf(Store.prefString(ctx, "tqOver12", "0")) }
    var under12 by remember { mutableStateOf(Store.prefString(ctx, "tqUnder12", "0")) }
    var month by remember {
        mutableIntStateOf(Store.prefInt(ctx, "tqMonth",
            java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1))
    }

    // tax inputs
    var fed by remember { mutableStateOf(Store.prefString(ctx, "tqFed", "22")) }
    var state by remember { mutableStateOf(Store.prefString(ctx, "tqState", "5.75")) }

    var locTick by remember { mutableIntStateOf(0) }
    var loc by remember { mutableStateOf<Locality?>(null) }

    // the first day in temporary quarters — every day after it is dated from here
    var start by remember {
        mutableStateOf(Store.prefString(ctx, "tqStart", "").ifBlank {
            Store.pcsDate(ctx).ifBlank { Store.today() }
        })
    }
    val startOk = Regex("\\d{4}-\\d{2}-\\d{2}").matches(start)

    // ceilings by calendar month, as saved; the draft is what is on screen
    var ratesTick by remember { mutableIntStateOf(0) }
    val savedRates = remember(ratesTick) { TqseRates.all(ctx) }
    val draft = remember(ratesTick) { mutableStateMapOf<String, Pair<String, String>>() }

    // which months the stay touches, from a first pass with no rates
    val months = remember(start, days) {
        if (!startOk) emptyList() else Perdiem.lodgingsPlusDated(start, days.toIntOrNull() ?: 0,
            0.0, 0.0, 0, 0, { null }).months
    }
    // a month with nothing saved is offered a figure, never silently given one:
    // the destination's figure when its fiscal year matches, else an earlier
    // month of the same fiscal year, else what the old one-month screen held
    LaunchedEffect(months, ratesTick, loc) {
        months.forEach { m ->
            if (draft.containsKey(m)) return@forEach
            savedRates[m]?.let { draft[m] = it; return@forEach }
            val fy = Perdiem.fiscalYearOf(m)
            val mon = m.drop(5).toInt()
            val fromLoc = loc?.takeIf { it.fiscalYear == fy && it.lodgingFor(mon) > 0 }
                ?.let { fmtNum(it.lodgingFor(mon)) to fmtNum(it.mie) }
            val fromEarlier = months.takeWhile { it < m }.lastOrNull { Perdiem.fiscalYearOf(it) == fy }
                ?.let { draft[it] }?.takeIf { it.first.isNotBlank() }
            val legacy = if (mon == month && lodgingMax.isNotBlank()) lodgingMax to mieMax else null
            draft[m] = fromLoc ?: fromEarlier ?: legacy ?: ("" to "")
        }
    }

    val lp = Perdiem.lodgingsPlusDated(
        start = start,
        days = days.toIntOrNull() ?: 0,
        actualLodgingPerNight = actualLodging.toDoubleOrNull() ?: 0.0,
        lodgingTaxPerNight = lodgingTax.toDoubleOrNull() ?: 0.0,
        over12 = over12.toIntOrNull() ?: 0,
        under12 = under12.toIntOrNull() ?: 0,
        rateFor = { m ->
            val d = draft[m] ?: savedRates[m]
            val l = d?.first?.toDoubleOrNull()
            if (l == null || l <= 0) null else l to (d.second.toDoubleOrNull() ?: 0.0)
        }
    )
    val unsaved = months.filter { m ->
        val d = draft[m] ?: return@filter false
        d.first.isNotBlank() && d != savedRates[m]
    }

    val payout = lp.total
    val tax = RelocTax.compute(
        taxable = payout,
        federalMarginal = (fed.toDoubleOrNull() ?: 22.0) / 100.0,
        stateMarginal = (state.toDoubleOrNull() ?: 0.0) / 100.0
    )

    TessScreen("TQSE (LP)", "lodgings plus · temporary quarters") {

        Spacer(Modifier.height(12.dp))
        TCard("lodgings plus reimbursement", T.Gold) {
            Text(cash(payout), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text("lodging against receipts, M&IE flat", fontSize = 12.sp, color = T.Mid)

            // one block per month and percentage — each month at its own ceiling
            lp.lines.forEach { ln ->
                Spacer(Modifier.height(12.dp))
                Text(monthName(ln.month) + " · FY" + (ln.fiscalYear % 100) + " · " +
                        ln.days + (if (ln.days == 1) " day" else " days") + " at " +
                        String.format(Locale.US, "%.0f%%", ln.factor * 100),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    color = if (ln.missingRate) T.Danger else T.Hi)
                Text(shortDate(ln.first) + (if (ln.last != ln.first) " – " + shortDate(ln.last) else "") +
                        (if (ln.missingRate) " · no lodging ceiling entered for this month"
                         else " · ceiling " + cash(ln.lodgingMax) + ", M&IE " + cash(ln.mieMax)),
                    fontSize = 11.sp, color = if (ln.missingRate) T.Danger else T.Low)
                Line("  lodging, capped at ${cash(ln.lodgingCap)} a night", cash(ln.lodgingPaid))
                Line("  M&IE, flat", cash(ln.miePaid))
            }
            if (lp.lines.isEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Set the first day and the number of days below.", fontSize = 12.sp, color = T.Gold)
            }
                HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 8.dp))
                Line("Lodging, against the cap", cash(lp.lodgingTotal))
                Line("M&IE, flat", cash(lp.mieTotal))
                Line("Lodging tax, outside the cap", cash(lp.taxTotal))
                Line("Total", cash(lp.total), bold = true)
            if (lp.missing.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("No lodging ceiling for " + lp.missing.joinToString(", ") { monthName(it) } +
                        " — those days count lodging and M&IE as zero until it is entered.",
                    fontSize = 11.sp, color = T.Danger)
            }
            if (lp.cappedOut) {
                Spacer(Modifier.height(8.dp))
                Text("Your lodging exceeds the cap — the excess is yours to absorb.",
                    fontSize = 11.sp, color = T.Danger)
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("what this is taxed at", T.Danger) {
            Text("Every dollar of it is wages.", fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold, color = T.Hi)
            Spacer(Modifier.height(6.dp))
            Hint("Since 2018 civilian relocation reimbursements are reported on the W-2 " +
                    "and taxed. TDY per diem is not — that is the difference between the " +
                    "two calculators, and it is why WTA and RITA exist.")

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(fed, "Federal marginal %", Modifier.weight(1f), numeric = true) { fed = it; Store.setPrefString(ctx, "tqFed", it) }
                DarkField(state, "State marginal %", Modifier.weight(1f), numeric = true) { state = it; Store.setPrefString(ctx, "tqState", it) }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Leave state at zero if you will still be a Florida resident when this is " +
                    "paid. If Virginia has you by then, 5.75 is the top rate.")

            Spacer(Modifier.height(14.dp))
            Line("Reimbursement", cash(tax.taxable))
            Line("WTA advanced at ${(tax.wtaRate * 100).toInt()}%", cash(tax.wta))
            Line("Reported as wages", cash(tax.grossedUp), bold = true)
            Spacer(Modifier.height(10.dp))
            Line("Combined marginal rate", String.format(Locale.US, "%.2f%%", tax.cmtr * 100))
            Line("Full gross-up needed", cash(tax.trueGrossUp))
            Line(
                if (tax.ritaEstimate >= 0) "RITA owed to you next year"
                else "Owed back at RITA settlement",
                cash(kotlin.math.abs(tax.ritaEstimate)),
                bad = tax.ritaEstimate < 0
            )
            Spacer(Modifier.height(10.dp))
            Hint("WTA is an advance at the flat 22% supplemental rate. RITA settles the " +
                    "difference the following year against what you actually owed — and if " +
                    "your real rate is below 22%, RITA runs the other way and you repay. " +
                    "You must file for RITA; it does not arrive on its own.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("the stay", T.Cyan) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(start, "First day (YYYY-MM-DD)", Modifier.weight(1.3f)) {
                    start = it
                    if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) Store.setPrefString(ctx, "tqStart", it)
                }
                DarkField(days, "Days", Modifier.weight(1f), integer = true) {
                    days = it; Store.setPrefString(ctx, "tqDays", it)
                }
            }
            if (!startOk) {
                Spacer(Modifier.height(4.dp))
                Text("The first day needs to be YYYY-MM-DD.", fontSize = 12.sp, color = T.Danger)
            } else {
                val n = days.toIntOrNull() ?: 0
                Spacer(Modifier.height(6.dp))
                Text(if (n > 0) shortDate(start) + " through " + shortDate(addDays(start, n - 1))
                     else "No days yet.", fontSize = 12.sp, color = T.Hi)
                Spacer(Modifier.height(8.dp))
                GhostBtn("Count through today", color = T.Cyan) {
                    val through = daysBetween(start, Store.today()) + 1
                    if (through > 0) { days = "$through"; Store.setPrefString(ctx, "tqDays", days) }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(actualLodging, "Room rate, per night", Modifier.weight(1f),
                    numeric = true) { actualLodging = it; Store.setPrefString(ctx, "tqRoom", it) }
                DarkField(lodgingTax, "Tax, per night", Modifier.weight(1f), numeric = true) {
                    lodgingTax = it; Store.setPrefString(ctx, "tqTax", it)
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("The multiplier drops from 100% to 75% after day 30. The clock does not " +
                    "stop for leave taken during the period.")
            Spacer(Modifier.height(8.dp))
            Hint("Keep them apart. The room rate is what counts against the ceiling; " +
                    "lodging tax is a separately reimbursable TQSE miscellaneous expense " +
                    "and is paid on top of it. Rolling the tax into the room rate would " +
                    "push you into the cap for money you never actually spent on the room.")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(over12, "Spouse and 12+", Modifier.weight(1f), integer = true) {
                    over12 = it; Store.setPrefString(ctx, "tqOver12", it)
                }
                DarkField(under12, "Under 12", Modifier.weight(1f), integer = true) {
                    under12 = it; Store.setPrefString(ctx, "tqUnder12", it)
                }
            }
            Spacer(Modifier.height(8.dp))
            Hint("Each person adds to the daily ceiling: 50% for a spouse or anyone twelve " +
                    "and over, 30% for under twelve, in the first period.")
            Spacer(Modifier.height(10.dp))
            Hint("Laundry and dry cleaning go the other way — the same rule folded those " +
                    "into the daily M&IE allowance, so they are not claimed separately.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("the locality, month by month", T.Teal) {
            Hint("Each month the stay touches gets its own ceiling, because GSA rates change " +
                    "every 1 October and some places change by season. A day is paid at the " +
                    "ceiling for its own month: September 2026 at the FY26 figure, October 2026 " +
                    "on at FY27.")
            Spacer(Modifier.height(12.dp))
            if (months.isEmpty()) {
                Text("Set the first day in temporary quarters below.", fontSize = 12.sp, color = T.Gold)
            }
            months.forEach { m ->
                val d = draft[m] ?: ("" to "")
                val saved = savedRates[m]
                val isSaved = saved != null && saved == d
                Text(monthName(m).uppercase() + " · FY" + (Perdiem.fiscalYearOf(m) % 100),
                    fontSize = 10.sp, color = T.Low, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(d.first, "Lodging max", Modifier.weight(1f), numeric = true) {
                        draft[m] = it to d.second
                    }
                    DarkField(d.second, "M&IE max", Modifier.weight(1f), numeric = true) {
                        draft[m] = d.first to it
                    }
                }
                Text(
                    when {
                        d.first.isBlank() -> "Enter the FY${Perdiem.fiscalYearOf(m) % 100} " +
                                "lodging ceiling for ${monthName(m)}."
                        isSaved -> "Saved."
                        saved != null -> "Changed — not saved. Saved figure is " + saved.first + "."
                        else -> "Not saved yet — check it against GSA for FY${Perdiem.fiscalYearOf(m) % 100}."
                    },
                    fontSize = 11.sp,
                    color = when {
                        d.first.isBlank() -> T.Danger
                        isSaved -> T.Teal
                        else -> T.Gold
                    }
                )
                Spacer(Modifier.height(10.dp))
            }
            if (months.isNotEmpty()) {
                PrimaryBtn(if (unsaved.isEmpty()) "All months saved" else
                    "Save ${unsaved.size} month${if (unsaved.size == 1) "" else "s"}",
                    accent = if (unsaved.isEmpty()) T.Edge else T.Teal) {
                    if (unsaved.isEmpty()) return@PrimaryBtn
                    unsaved.forEach { m -> draft[m]?.let { TqseRates.save(ctx, m, it.first, it.second) } }
                    ratesTick++
                }
            }

            val saved = remember(locTick) { Localities.all(ctx) }
            if (saved.isNotEmpty()) {
                Spacer(Modifier.height(14.dp))
                Text("FILL FROM A SAVED DESTINATION", fontSize = 9.sp, color = T.Low,
                    fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(4.dp))
                saved.forEach { l ->
                    Row(Modifier.fillMaxWidth().clickable {
                        loc = l
                        // only the months in that destination's own fiscal year
                        months.filter { Perdiem.fiscalYearOf(it) == l.fiscalYear }.forEach { m ->
                            val v = l.lodgingFor(m.drop(5).toInt())
                            if (v > 0) draft[m] = fmtNum(v) to fmtNum(l.mie)
                        }
                    }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (loc?.id == l.id) T.Teal else T.Edge))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(l.name, fontSize = 14.sp, color = T.Hi)
                            Text("FY${l.fiscalYear % 100} — fills only that year's months",
                                fontSize = 10.sp, color = T.Low)
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Hint("Destinations saved on the TDY screen can fill these too.")
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("before you rely on this", T.Edge) {
            Hint("Lodgings Plus is the method DoD authorises; Actual Expense was dropped as " +
                    "redundant and Lump Sum is not available here. The percentage multipliers come from JTR Table " +
                    "5-85 and have already moved once — confirm them against the current table " +
                    "before planning around a figure. A planning estimate, settled by your " +
                    "travel office.")
        }
    }
}

@Composable
private fun Line(label: String, value: String, bold: Boolean = false, bad: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (bad) T.Danger else T.Hi)
    }
}


private fun monthName(m: String): String {
    val i = m.drop(5).take(2).toIntOrNull() ?: return m
    return MONTHS_T[i - 1] + " " + m.take(4)
}

private fun shortDate(d: String): String {
    val i = d.drop(5).take(2).toIntOrNull() ?: return d
    return MONTHS_T[i - 1] + " " + d.drop(8).trimStart('0') + ", " + d.take(4)
}

private fun addDays(d: String, n: Int): String = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val c = java.util.Calendar.getInstance().apply { time = f.parse(d)!! }
    c.add(java.util.Calendar.DAY_OF_YEAR, n); f.format(c.time)
} catch (e: Exception) { d }

private fun daysBetween(a: String, b: String): Int = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
    f.timeZone = java.util.TimeZone.getTimeZone("UTC")
    ((f.parse(b)!!.time - f.parse(a)!!.time) / 86_400_000L).toInt()
} catch (e: Exception) { -1 }

/**
 * Lodging and M&IE ceilings by calendar month, exactly as typed. Keyed
 * yyyy-MM, so September 2026 (FY26) and October 2026 (FY27) are separate
 * entries and a new fiscal year never overwrites the last one.
 */
object TqseRates {
    private const val KEY = "tqRates"

    fun all(ctx: android.content.Context): Map<String, Pair<String, String>> {
        val raw = Store.prefString(ctx, KEY, "")
        if (raw.isBlank()) return emptyMap()
        return try {
            val o = org.json.JSONObject(raw)
            o.keys().asSequence().associateWith { k ->
                val v = o.getJSONObject(k); v.optString("l") to v.optString("m")
            }
        } catch (e: Exception) { emptyMap() }
    }

    fun save(ctx: android.content.Context, month: String, lodging: String, mie: String) {
        val o = try { org.json.JSONObject(Store.prefString(ctx, KEY, "").ifBlank { "{}" }) }
                catch (e: Exception) { org.json.JSONObject() }
        o.put(month, org.json.JSONObject().apply { put("l", lodging.trim()); put("m", mie.trim()) })
        Store.setPrefString(ctx, KEY, o.toString())
    }
}

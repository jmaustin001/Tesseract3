The wage base is now visible, editable and clearable.

A daily rate of $61 was coming from a wage base of about $15,250 — a figure
left over from trying the LES screen out with test numbers. The arithmetic was
correct; the input was wrong and there was no way to see it. That is the worse
failure of the two.

The Pay screen now has a card showing exactly what the allocation is dividing,
where that figure came from, and the resulting daily rate. You can set it by
hand or clear it, in which case the app falls back to what your LES entries
project and then to the SF-50 salary.

The dashboard names the amount too, not just its provenance, and flags a wage
base well below your SF-50 salary rather than quietly dividing by it.

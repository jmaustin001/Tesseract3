Your SF-50 salary now has a home, at the top of the Pay screen.

Enter adjusted basic pay from block 20C — basic pay plus locality — and the
effective date from block 4. The screen works out hourly, daily and per-pay-
period figures the way OPM does, over 2,087 hours a year, which is what to
check an LES against.

The salary is a rate rather than a record of what you will earn. A PCS changes
locality partway through the year, so a year's actual wages still come from the
LES year-to-date entries. Until one of those exists, the dashboard estimates
from salary and says so, noting the figure is before pre-tax deductions.

Also in this build: the daily rate divides by the year's scheduled workdays
rather than days logged so far, the dashboard labels days and dollars
separately, and travel days no longer count toward the office requirement.

package com.tesseract.app

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The category palette as tappable squares; the chosen one is ringed. */
@Composable
fun CategorySwatches(selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Store.categoryPalette.forEach { argb ->
            val on = argb == selected
            Box(
                Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
                    .border(if (on) 3.dp else 1.dp, if (on) T.Hi else T.Edge, RoundedCornerShape(8.dp))
                    .padding(if (on) 5.dp else 3.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(argb))
                    .clickable { onPick(argb) }
            )
        }
    }
}

/**
 * Everything about one of your categories in one place: its name, its color,
 * and what it counts as — which decides whether a day earns, whether it is
 * TDY or leave, and whether it counts toward the in-office requirement.
 * Nothing changes until Save.
 */
@Composable
fun CategoryEditDialog(label: String, onClose: (changed: Boolean) -> Unit) {
    val ctx = LocalContext.current
    val startColor = remember { Store.customColors(ctx).entries.firstOrNull { it.key.equals(label, true) }?.value
        ?: Store.categoryPalette[0] }
    val startKind = remember { Store.customKind(ctx, label) }
    val guessed = remember { !Store.customKindIsSet(ctx, label) }
    val days = remember { Store.daysLabeled(ctx, label) }

    var name by remember { mutableStateOf(label) }
    var color by remember { mutableIntStateOf(startColor) }
    var kind by remember { mutableStateOf(startKind) }
    var relabel by remember { mutableStateOf(true) }
    var sureDelete by remember { mutableStateOf(false) }
    val clash = name.trim().isNotEmpty() && !name.trim().equals(label, true) &&
            (Store.customCategories(ctx).any { it.equals(name.trim(), true) } || name.trim() in Status.all)

    AlertDialog(
        containerColor = T.Deep,
        onDismissRequest = { onClose(false) },
        title = { Text("Edit category", color = T.Hi, fontSize = 18.sp) },
        text = {
            Column(Modifier.verticalScrollIfNeeded()) {
                DarkField(name, "Name", Modifier.fillMaxWidth()) { name = it }
                if (clash) Text("There is already a category by that name.", fontSize = 11.sp, color = T.Danger)
                if (name.trim() != label && days > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = relabel, onCheckedChange = { relabel = it })
                        Text("Also rename it on the $days day${if (days == 1) "" else "s"} already labeled",
                            fontSize = 12.sp, color = T.Mid)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("COLOR", fontSize = 9.sp, color = T.Low, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(6.dp))
                CategorySwatches(color) { color = it }
                Spacer(Modifier.height(12.dp))
                Text("COUNTS AS", fontSize = 9.sp, color = T.Low, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(6.dp))
                Status.KINDS.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (k, lbl) ->
                            val on = kind == k
                            Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                                .background(if (on) T.Gold.copy(alpha = .18f) else T.Glow)
                                .border(1.dp, if (on) T.Gold else T.Edge, RoundedCornerShape(8.dp))
                                .clickable { kind = k }
                                .padding(vertical = 9.dp), contentAlignment = Alignment.Center
                            ) { Text(lbl, fontSize = 12.sp, color = if (on) T.Gold else T.Mid) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Text(when (kind) {
                    "Duty" -> "A workday at the duty station: earns, and counts as an office day for the pay period."
                    "TDY" -> "A workday on orders: earns where the work was done, counts as TDY in the pay period and the TDY log."
                    "Leave" -> "Leave: earns nothing anywhere, and counts as leave in the pay period."
                    "Off" -> "A day off — weekend, holiday, RDO: earns nothing."
                    "Telework" -> "A workday away from the office: earns where you were, never an office day."
                    else -> "No special meaning: a workday earns on a scheduled duty day, by where you were."
                } + if (guessed && kind == startKind) " (Guessed from the name until you save.)" else "",
                    fontSize = 11.sp, color = T.Low)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && !clash, onClick = {
                val to = name.trim()
                if (to != label) Store.renameCustomCategory(ctx, label, to, relabel)
                Store.setCustomColor(ctx, to, color)
                Store.setCustomKind(ctx, to, kind)
                onClose(true)
            }) { Text("Save", color = T.Gold) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    if (!sureDelete) { sureDelete = true; return@TextButton }
                    Store.removeCustomCategory(ctx, label); onClose(true)
                }) { Text(if (sureDelete) "Tap to remove" else "Remove", color = T.Danger) }
                TextButton(onClick = { onClose(false) }) { Text("Cancel", color = T.Mid) }
            }
        }
    )
}

private fun Modifier.verticalScrollIfNeeded(): Modifier = this

/**
 * The undo button every screen carries. One tap undoes the last change; Redo
 * appears after an undo until something new is changed. The screen is rebuilt
 * afterwards so every figure on it is re-read.
 */
@Composable
fun UndoButton() {
    val ctx = LocalContext.current
    val v = Undo.version.intValue
    val can = remember(v) { Undo.canUndo(ctx) }
    val canRedo = remember(v) { Undo.canRedo(ctx) }
    var open by remember { mutableStateOf(false) }
    if (!can && !canRedo) return
    Box(
        Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
            .background(T.Deep).border(1.dp, T.Edge, RoundedCornerShape(9.dp))
            .clickable { open = true },
        contentAlignment = Alignment.Center
    ) { Text("↶", color = T.Cyan, fontSize = 18.sp) }
    Spacer(Modifier.width(8.dp))
    if (open) {
        val at = remember(v) { Undo.lastTime(ctx) }
        val n = remember(v) { Undo.count(ctx) }
        AlertDialog(
            containerColor = T.Deep,
            onDismissRequest = { open = false },
            title = { Text("Undo", color = T.Hi, fontSize = 18.sp) },
            text = {
                Text(if (can) "Put everything back as it was before your last change" +
                        (if (at > 0) ", made at " + java.text.SimpleDateFormat("h:mm a 'on' MMM d",
                            java.util.Locale.US).format(java.util.Date(at)) else "") +
                        ". $n step${if (n == 1) "" else "s"} kept. GPS fixes taken since are kept."
                     else "Nothing left to undo.",
                    color = T.Mid, fontSize = 13.sp)
            },
            confirmButton = {
                if (can) TextButton(onClick = {
                    open = false
                    if (Undo.undo(ctx)) {
                        android.widget.Toast.makeText(ctx, "Undone", android.widget.Toast.LENGTH_SHORT).show()
                        (ctx as? Activity)?.recreate()
                    }
                }) { Text("Undo", color = T.Gold) }
            },
            dismissButton = {
                Row {
                    if (canRedo) TextButton(onClick = {
                        open = false
                        if (Undo.redo(ctx)) {
                            android.widget.Toast.makeText(ctx, "Redone", android.widget.Toast.LENGTH_SHORT).show()
                            (ctx as? Activity)?.recreate()
                        }
                    }) { Text("Redo", color = T.Cyan) }
                    TextButton(onClick = { open = false }) { Text("Close", color = T.Mid) }
                }
            }
        )
    }
}

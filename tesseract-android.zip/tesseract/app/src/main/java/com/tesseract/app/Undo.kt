package com.tesseract.app

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Ctrl-Z for the whole app.
 *
 * Just before anything you change is written — a category, a datum, a salary,
 * a setting, a day added by hand — the app saves a snapshot of everything as
 * it stood. Writes that follow each other within a few seconds are one change,
 * so typing a figure or saving a form undoes in one step, not one keystroke
 * at a time.
 *
 * Snapshots are only taken while one of the app's screens is open, so the
 * background GPS checks never create undo steps. And undoing never removes a
 * GPS fix the phone took in the meantime: those are put back on top of the
 * restored log. Twenty steps are kept. One Redo is kept until the next change.
 */
object Undo {

    private const val KEEP = 20
    private const val WINDOW_MS = 2500L

    /** Screens currently open; set by the Application's lifecycle callbacks. */
    @Volatile var resumed = 0
    @Volatile private var suspended = false
    @Volatile private var lastTouch = 0L

    /** Bumped on every change to the stack, so the undo button redraws. */
    val version = mutableIntStateOf(0)

    private fun dir(ctx: Context) = File(ctx.filesDir, "undo").apply { mkdirs() }
    private fun redoFile(ctx: Context) = File(dir(ctx), "redo.json")

    private fun steps(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.name.startsWith("u-") && f.name.endsWith(".json") }
            ?.sortedBy { it.name } ?: emptyList()

    fun canUndo(ctx: Context) = steps(ctx).isNotEmpty()
    fun canRedo(ctx: Context) = redoFile(ctx).exists()
    fun count(ctx: Context) = steps(ctx).size

    /** When the newest undo step was taken, in ms, or 0. */
    fun lastTime(ctx: Context): Long =
        steps(ctx).lastOrNull()?.name?.removePrefix("u-")?.removeSuffix(".json")?.toLongOrNull() ?: 0L

    /** Called by Store before every write. Cheap when nothing needs doing. */
    fun willChange(ctx: Context) {
        if (suspended || resumed <= 0) return
        val now = System.currentTimeMillis()
        val startOfChange = now - lastTouch > WINDOW_MS
        lastTouch = now
        if (!startOfChange) return
        try {
            File(dir(ctx), "u-$now.json").writeText(snapshot(ctx, now).toString())
            redoFile(ctx).delete()               // a new change ends the redo chain
            steps(ctx).dropLast(KEEP).forEach { it.delete() }
            version.intValue++
        } catch (e: Exception) { }
    }

    private fun snapshot(ctx: Context, at: Long): JSONObject {
        val prefs = JSONObject()
        Store.settingsMap(ctx).forEach { (k, v) ->
            val t = when (v) {
                is String -> "s"; is Int -> "i"; is Long -> "l"; is Float -> "f"
                is Boolean -> "b"; is Set<*> -> "set"; else -> null
            } ?: return@forEach
            prefs.put(k, JSONObject().apply {
                put("t", t)
                put("v", if (v is Set<*>) JSONArray(v.toList()) else v)
            })
        }
        return JSONObject().apply {
            put("at", at)
            put("samples", Store.rawText(ctx, Store.F_SAMPLES))
            put("tags", Store.rawText(ctx, Store.F_TAGS))
            put("datums", Store.rawText(ctx, Store.F_DATUMS))
            put("prefs", prefs)
        }
    }

    private fun apply(ctx: Context, snap: JSONObject) {
        val at = snap.optLong("at")
        // the log as it was, plus any fix the phone took on its own since then
        val then = try { JSONArray(snap.optString("samples").ifBlank { "[]" }) } catch (e: Exception) { JSONArray() }
        val seen = HashSet<Long>()
        for (i in 0 until then.length()) seen.add(then.getJSONObject(i).optLong("ts"))
        val now = try { JSONArray(Store.rawText(ctx, Store.F_SAMPLES).ifBlank { "[]" }) } catch (e: Exception) { JSONArray() }
        for (i in 0 until now.length()) {
            val o = now.getJSONObject(i)
            if (!o.optBoolean("manual", false) && o.optLong("ts") > at && o.optLong("ts") !in seen) then.put(o)
        }
        Store.writeRaw(ctx, Store.F_SAMPLES, then.toString())
        Store.writeRaw(ctx, Store.F_TAGS, snap.optString("tags"))
        Store.writeRaw(ctx, Store.F_DATUMS, snap.optString("datums").ifBlank { "[]" })

        val p = snap.optJSONObject("prefs") ?: JSONObject()
        val map = mutableMapOf<String, Any?>()
        p.keys().forEach { k ->
            val o = p.getJSONObject(k)
            map[k] = when (o.optString("t")) {
                "s" -> o.optString("v"); "i" -> o.optInt("v"); "l" -> o.optLong("v")
                "f" -> o.optDouble("v").toFloat(); "b" -> o.optBoolean("v")
                "set" -> o.optJSONArray("v")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() }
                else -> null
            }
        }
        Store.replaceSettings(ctx, map)
        Store.loadCategoryKinds(ctx)
    }

    /** Put everything back as it was before the last change. */
    @Synchronized
    fun undo(ctx: Context): Boolean {
        val step = steps(ctx).lastOrNull() ?: return false
        suspended = true
        try {
            val snap = JSONObject(step.readText())
            redoFile(ctx).writeText(snapshot(ctx, System.currentTimeMillis()).toString())
            apply(ctx, snap)
            step.delete()
        } catch (e: Exception) {
            return false
        } finally {
            suspended = false; lastTouch = 0L; version.intValue++
        }
        return true
    }

    /** Put back what the last Undo took away. */
    @Synchronized
    fun redo(ctx: Context): Boolean {
        val r = redoFile(ctx)
        if (!r.exists()) return false
        suspended = true
        try {
            val snap = JSONObject(r.readText())
            val now = System.currentTimeMillis()
            File(dir(ctx), "u-$now.json").writeText(snapshot(ctx, now).toString())
            apply(ctx, snap)
            r.delete()
        } catch (e: Exception) {
            return false
        } finally {
            suspended = false; lastTouch = 0L; version.intValue++
        }
        return true
    }
}

package com.tesseract.app

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Checks the GitHub release that the build workflow publishes, and installs it.
 * Nothing about your log is involved — this only reads a public release listing.
 */
object Updater {

    data class Release(
        val version: String,     // 1.1.0
        val build: Int,          // the CI run number, unique per build
        val tag: String,         // v1.1.0-b12
        val notes: String,
        val apkUrl: String,
        val published: String
    ) {
        val label get() = "$version · build $build"
    }

    private fun parse(o: JSONObject): Release? {
        val tag = o.optString("tag_name")
        val version = tag.removePrefix("v").substringBefore("-b")
        val build = tag.substringAfter("-b", "0").toIntOrNull() ?: 0
        val assets = o.optJSONArray("assets") ?: return null
        var url = ""
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
        }
        if (url.isBlank()) return null
        return Release(version, build, tag, o.optString("body").take(400), url,
            o.optString("published_at").take(10))
    }

    /** Null when there is nothing newer, or when the check could not be completed. */
    suspend fun check(ctx: Context): Result<Release?> = withContext(Dispatchers.IO) {
        val repo = Store.updateRepo(ctx)
        if (repo.isBlank()) return@withContext Result.failure(Exception("No repository set."))
        try {
            val conn = (URL("https://api.github.com/repos/$repo/releases/latest")
                .openConnection() as HttpURLConnection).apply {
                setRequestProperty("Accept", "application/vnd.github+json")
                connectTimeout = 12000; readTimeout = 12000
            }
            if (conn.responseCode == 404)
                return@withContext Result.failure(
                    Exception("No releases found. If the repository is private, the app cannot see it.")
                )
            if (conn.responseCode != 200)
                return@withContext Result.failure(Exception("GitHub returned ${conn.responseCode}."))

            val rel = parse(JSONObject(conn.inputStream.bufferedReader().use { it.readText() }))
                ?: return@withContext Result.failure(Exception("That release has no APK attached."))

            val newer = isNewer(rel.version, BuildConfig.VERSION_NAME) ||
                    (rel.version == BuildConfig.VERSION_NAME && rel.build > BuildConfig.VERSION_CODE)
            Result.success(if (newer) rel else null)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Every build still on the releases page, newest first. Nothing is ever deleted. */
    suspend fun history(ctx: Context): Result<List<Release>> = withContext(Dispatchers.IO) {
        val repo = Store.updateRepo(ctx)
        try {
            val conn = (URL("https://api.github.com/repos/$repo/releases?per_page=20")
                .openConnection() as HttpURLConnection).apply {
                setRequestProperty("Accept", "application/vnd.github+json")
                connectTimeout = 12000; readTimeout = 12000
            }
            if (conn.responseCode != 200)
                return@withContext Result.failure(Exception("GitHub returned ${conn.responseCode}."))
            val arr = org.json.JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            Result.success((0 until arr.length()).mapNotNull { parse(arr.getJSONObject(it)) })
        } catch (e: Exception) { Result.failure(e) }
    }

    /** 1.10.0 is newer than 1.9.0 — compared as numbers, not as text. */
    fun isNewer(remote: String, local: String): Boolean {
        val r = remote.split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        val l = local.split(".").map { it.filter(Char::isDigit).toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }; val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    suspend fun download(ctx: Context, rel: Release): Result<File> = withContext(Dispatchers.IO) {
        try {
            val dir = File(ctx.getExternalFilesDir(null), "updates").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val out = File(dir, "tesseract-${rel.version}-b${rel.build}.apk")
            val conn = (URL(rel.apkUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true; connectTimeout = 15000; readTimeout = 60000
            }
            conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
            if (out.length() < 10_000) return@withContext Result.failure(Exception("Download was incomplete."))
            Result.success(out)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
    }
}

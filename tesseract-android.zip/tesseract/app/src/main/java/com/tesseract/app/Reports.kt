package com.tesseract.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Reports {

    /** One row per day: the file a CPA actually reads. */
    fun dayCsv(ctx: Context, year: Int): String {
        val counted = Store.countedState(ctx)
        val sb = StringBuilder(
            "date,states_present,datums,category,duty_status,place,note,fixes," +
                    "counts_as_${counted.lowercase()}_day\n"
        )
        Store.days(ctx, year).forEach { d ->
            sb.append(d.date).append(',')
                .append('"').append(d.states.joinToString("|")).append('"').append(',')
                .append('"').append(d.zones.joinToString("|")).append('"').append(',')
                .append('"').append(d.status).append('"').append(',')
                .append('"').append(Status.dutyStatus(d.status)).append('"').append(',')
                .append('"').append(Status.place(d.status)).append('"').append(',')
                .append('"').append(d.note.replace("\"", "'")).append('"').append(',')
                .append(d.sampleCount).append(',')
                .append(if (counted in d.states) "yes" else "no").append('\n')
        }
        Store.gapDays(ctx, year)
            .forEach { sb.append(it).append(",\"\",\"\",\"NO DATA\",\"\",\"\",\"\",0,unknown\n") }
        return sb.toString()
    }

    /** One row per fix: the evidence underneath. */
    fun sampleCsv(ctx: Context, year: Int): String {
        val sb = StringBuilder(
            "date,time,timezone,state,datum,datum_role,latitude,longitude,accuracy_m,manual_entry\n"
        )
        val tf = SimpleDateFormat("HH:mm:ss", Locale.US)
        Store.samples(ctx).filter { it.date.startsWith("$year-") }.forEach { s ->
            sb.append(s.date).append(',').append(tf.format(Date(s.timestamp))).append(',')
                .append(s.tz).append(',').append(s.state).append(',')
                .append('"').append(s.zoneName).append('"').append(',')
                .append(s.zoneRole).append(',')
                .append(s.lat).append(',').append(s.lon).append(',')
                .append(s.accuracyM).append(',').append(s.manual).append('\n')
        }
        return sb.toString()
    }

    fun files(ctx: Context, year: Int): ArrayList<Uri> {
        val dir = File(ctx.filesDir, "reports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val a = File(dir, "tesseract-by-day-$year-$stamp.csv").apply { writeText(dayCsv(ctx, year)) }
        val b = File(dir, "tesseract-fixes-$year-$stamp.csv").apply { writeText(sampleCsv(ctx, year)) }
        // The backup rides along, so every report you send is also an off-device copy
        // of the whole log — the one that can actually be restored from.
        val c = Backup.writeForReport(ctx)
        val auth = "${ctx.packageName}.fileprovider"
        return arrayListOf(
            FileProvider.getUriForFile(ctx, auth, a),
            FileProvider.getUriForFile(ctx, auth, b),
            FileProvider.getUriForFile(ctx, auth, c)
        )
    }

    fun emailIntent(ctx: Context, year: Int): Intent {
        val uris = files(ctx, year)
        val counted = Store.countedState(ctx)
        val home = Store.homeState(ctx)
        val days = Store.days(ctx, year)
        val to = Store.email(ctx)

        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, "Residency day log — $year")
            putExtra(Intent.EXTRA_TEXT, buildString {
                append("Day log through ${Store.today()}\n\n")
                append("Days in ${States.fullName(counted)}: ")
                append("${Store.stateDays(ctx, counted, year)} of ${Store.limit(ctx)}\n")
                append("  duty ${days.count { Status.dutyStatus(it.status) == "Duty" }}")
                append(" · TDY ${days.count { Status.dutyStatus(it.status) == "TDY" }}")
                append(" · leave ${days.count { Status.dutyStatus(it.status) == "Leave" }}\n")
                append("Days in ${States.fullName(home)}: ${Store.stateDays(ctx, home, year)}\n")
                append("Days with a record: ${days.size}\n")
                val gaps = Store.gapDays(ctx, year).size
                if (gaps > 0) append("Days with no data: $gaps\n")
                val untagged = Store.untaggedOutDays(ctx, year).size
                if (untagged > 0) append("Off-station days not yet labelled: $untagged\n")
                append("\nThree files attached: one row per day, the raw fixes behind it, ")
                append("and a JSON backup that can be restored into the app.")
            })
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}

class ReportWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val year = Store.year()
        val counted = Store.countedState(ctx)
        val n = Store.stateDays(ctx, counted, year)
        val pi = PendingIntent.getActivity(
            ctx, 2, Intent.createChooser(Reports.emailIntent(ctx, year), "Send report"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        Notifier.report(ctx, "Monthly day log ready",
            "$n days in ${States.fullName(counted)} so far this year. Tap to send it.", pi)
        return Result.success()
    }
}

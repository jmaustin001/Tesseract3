package com.tesseract.app

/**
 * M&IE arithmetic for a TDY trip.
 *
 * Rates are FY2026 (1 Oct 2025 – 30 Sep 2026). GSA republishes every October,
 * so the tier list goes stale on a known date and the app says so rather than
 * pretending otherwise. A custom rate is always available.
 *
 * This is a planning estimate. The voucher is settled by your travel office
 * against the JTR, not by this.
 */
object Perdiem {

    /**
     * Locality tier: total M&IE, then breakfast, lunch, dinner, incidental.
     * GSA publishes these in whole dollars, but the field takes a decimal —
     * a locally negotiated or OCONUS rate is not always a round number, and a
     * field that silently truncates what was typed is worse than one that
     * simply allows more than is usually needed.
     */
    data class Tier(val total: Double, val b: Double, val l: Double, val d: Double,
                     val inc: Double = 5.0) {
        val label get() = "$" + fmtNum(total)
    }

    val TIERS = listOf(
        Tier(68.0, 16.0, 19.0, 28.0),   // standard CONUS
        Tier(74.0, 18.0, 20.0, 31.0),
        Tier(80.0, 20.0, 22.0, 33.0),
        Tier(86.0, 21.0, 23.0, 37.0),
        Tier(92.0, 23.0, 26.0, 38.0)    // top tier — includes DC, Arlington, Alexandria
    )

    const val FIRST_LAST = 0.75
    const val LONG_TERM_31 = 0.75    // JTR flat rate, 31 to 180 days
    const val LONG_TERM_181 = 0.55   // JTR flat rate, 181 days and over

    data class Result(
        val days: Int,
        val fullDays: Int,
        val travelDays: Int,
        val rate: Double,
        val flatMultiplier: Double,
        val gross: Double,
        val mealDeductions: Double,
        val net: Double,
        val perFullDay: Double,
        val perTravelDay: Double,
        val allMealsProvidedDays: Int
    )

    // ---------------- TQSE ----------------
    //
    // Relocation, not travel, and the arithmetic has nothing in common with TDY.
    // Lump sum pays a fixed amount whatever you spend. Actual expense reimburses
    // what you actually spent up to a ceiling. Both run off the full locality
    // per diem rate — lodging plus M&IE — not the M&IE portion alone.

    const val LS_EMPLOYEE = 0.75
    const val LS_DEPENDENT = 0.25

    data class LumpSum(
        val days: Int, val rate: Double, val dependents: Int,
        val employeeShare: Double, val dependentShare: Double, val total: Double
    )

    /** Employee 75% of the locality rate a day, each dependent 25%. */
    fun lumpSum(days: Int, localityRate: Double, dependents: Int): LumpSum {
        val n = days.coerceIn(0, 30)
        val emp = localityRate * LS_EMPLOYEE * n
        val dep = localityRate * LS_DEPENDENT * n * dependents.coerceAtLeast(0)
        return LumpSum(n, localityRate, dependents, emp, dep, emp + dep)
    }

    /**
     * TQSE Lodgings Plus — the method DoD now prefers, having dropped Actual
     * Expense as redundant.
     *
     * Lodging is reimbursed at what you actually paid, capped at the locality
     * maximum times a percentage. M&IE is paid flat at the locality maximum
     * times the same percentage, with no receipts. The percentage falls after
     * the first thirty days.
     *
     * Multipliers are editable because Table 5-85 has moved once already and
     * a wrong multiplier is invisible in the output.
     */
    data class LpPeriod(
        val days: Int, val factor: Double, val lodgingCap: Double,
        val lodgingPaid: Double, val miePaid: Double
    ) { val total get() = lodgingPaid + miePaid }

    data class LodgingsPlus(
        val first: LpPeriod, val second: LpPeriod,
        val lodgingTotal: Double, val mieTotal: Double,
        /** Lodging tax. The 2024 rule made this a separately reimbursable TQSE
         *  miscellaneous expense, so it sits outside the ceiling rather than
         *  eating into it. */
        val taxTotal: Double,
        val total: Double,
        val cappedOut: Boolean
    )

    fun lodgingsPlus(
        days: Int,
        actualLodgingPerNight: Double,
        lodgingTaxPerNight: Double = 0.0,
        lodgingMax: Double,
        mieMax: Double,
        over12: Int,
        under12: Int,
        p1Emp: Double = 1.00, p1Over: Double = 0.50, p1Under: Double = 0.30,
        p2Emp: Double = 0.75, p2Over: Double = 0.45, p2Under: Double = 0.27
    ): LodgingsPlus {
        val n = days.coerceAtLeast(0)
        val d1 = minOf(n, 30)
        val d2 = (n - 30).coerceAtLeast(0)

        fun period(d: Int, emp: Double, over: Double, under: Double): LpPeriod {
            val factor = emp + over * over12.coerceAtLeast(0) + under * under12.coerceAtLeast(0)
            val cap = lodgingMax * factor
            val lodging = minOf(actualLodgingPerNight, cap) * d
            val mie = mieMax * factor * d
            return LpPeriod(d, factor, cap, lodging, mie)
        }

        val a = period(d1, p1Emp, p1Over, p1Under)
        val b = period(d2, p2Emp, p2Over, p2Under)
        val tax = lodgingTaxPerNight.coerceAtLeast(0.0) * n
        return LodgingsPlus(
            a, b,
            a.lodgingPaid + b.lodgingPaid,
            a.miePaid + b.miePaid,
            tax,
            a.total + b.total + tax,
            actualLodgingPerNight > a.lodgingCap || (d2 > 0 && actualLodgingPerNight > b.lodgingCap)
        )
    }

    /** The federal fiscal year a yyyy-MM month falls in: October starts the next one. */
    fun fiscalYearOf(month: String): Int {
        val y = month.take(4).toIntOrNull() ?: return 0
        val m = month.drop(5).take(2).toIntOrNull() ?: return 0
        return if (m >= 10) y + 1 else y
    }

    /** One run of nights sharing a month and a percentage. */
    data class LpLine(
        val month: String,        // yyyy-MM
        val fiscalYear: Int,
        val first: String,        // yyyy-MM-dd of the first day in the run
        val last: String,
        val days: Int,
        val period: Int,          // 1 = first 30 days, 2 = after
        val factor: Double,
        val lodgingMax: Double,   // the locality ceiling for that month, before the factor
        val mieMax: Double,
        val lodgingCap: Double,   // ceiling × factor
        val lodgingPaid: Double,
        val miePaid: Double,
        val taxPaid: Double,
        val missingRate: Boolean
    ) { val total get() = lodgingPaid + miePaid + taxPaid }

    data class LpDated(
        val lines: List<LpLine>,
        val lodgingTotal: Double,
        val mieTotal: Double,
        val taxTotal: Double,
        val total: Double,
        val cappedOut: Boolean,
        val months: List<String>,      // every month the stay touches, in order
        val missing: List<String>      // months with no lodging ceiling entered
    )

    /**
     * Lodgings Plus priced day by day. Each day takes the ceiling for its own
     * month — so a stay that starts 20 September and runs into October takes
     * the FY26 September figure for the September days and the FY27 October
     * figure from 1 October on. The 30-day step-down is counted from check-in
     * and does not reset at a month or a fiscal year.
     */
    fun lodgingsPlusDated(
        start: String,
        days: Int,
        actualLodgingPerNight: Double,
        lodgingTaxPerNight: Double,
        over12: Int,
        under12: Int,
        rateFor: (String) -> Pair<Double, Double>?,   // yyyy-MM -> lodging max, M&IE max
        p1Emp: Double = 1.00, p1Over: Double = 0.50, p1Under: Double = 0.30,
        p2Emp: Double = 0.75, p2Over: Double = 0.45, p2Under: Double = 0.27
    ): LpDated {
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val cal = java.util.Calendar.getInstance()
        try { cal.time = fmt.parse(start)!! } catch (e: Exception) {
            return LpDated(emptyList(), 0.0, 0.0, 0.0, 0.0, false, emptyList(), emptyList())
        }
        val o = over12.coerceAtLeast(0); val u = under12.coerceAtLeast(0)
        val f1 = p1Emp + p1Over * o + p1Under * u
        val f2 = p2Emp + p2Over * o + p2Under * u
        val tax = lodgingTaxPerNight.coerceAtLeast(0.0)

        val lines = mutableListOf<LpLine>()
        val months = linkedSetOf<String>()
        var capped = false
        for (i in 0 until days.coerceIn(0, 2000)) {
            val date = fmt.format(cal.time)
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            val month = date.take(7)
            months.add(month)
            val period = if (i < 30) 1 else 2
            val factor = if (period == 1) f1 else f2
            val r = rateFor(month)
            val lMax = r?.first ?: 0.0
            val mMax = r?.second ?: 0.0
            val cap = lMax * factor
            if (actualLodgingPerNight > cap && lMax > 0) capped = true
            val lodging = minOf(actualLodgingPerNight, cap)
            val mie = mMax * factor
            val prev = lines.lastOrNull()
            if (prev != null && prev.month == month && prev.period == period) {
                lines[lines.size - 1] = prev.copy(
                    last = date, days = prev.days + 1,
                    lodgingPaid = prev.lodgingPaid + lodging,
                    miePaid = prev.miePaid + mie, taxPaid = prev.taxPaid + tax)
            } else {
                lines.add(LpLine(month, fiscalYearOf(month), date, date, 1, period, factor,
                    lMax, mMax, cap, lodging, mie, tax, r == null || lMax <= 0))
            }
        }
        val l = lines.sumOf { it.lodgingPaid }
        val m = lines.sumOf { it.miePaid }
        val t = lines.sumOf { it.taxPaid }
        return LpDated(lines, l, m, t, l + m + t, capped, months.toList(),
            lines.filter { it.missingRate }.map { it.month }.distinct())
    }

    fun compute(
        days: Int,
        tier: Tier,
        breakfasts: Int,
        lunches: Int,
        dinners: Int,
        longTerm: Boolean
    ): Result {
        val n = days.coerceAtLeast(0)
        // a one-day trip is a single travel day; anything longer has two
        val travelDays = if (n <= 0) 0 else if (n == 1) 1 else 2
        val fullDays = (n - travelDays).coerceAtLeast(0)

        val flat = when {
            !longTerm -> 1.0
            n >= 181 -> LONG_TERM_181
            n >= 31 -> LONG_TERM_31
            else -> 1.0
        }

        val rate = tier.total * flat
        val perTravel = rate * FIRST_LAST
        val gross = fullDays * rate + travelDays * perTravel

        // provided meals come off at the full meal value, even on a 75% day
        val deductions = breakfasts * tier.b + lunches * tier.l + dinners * tier.d

        return Result(
            days = n,
            fullDays = fullDays,
            travelDays = travelDays,
            rate = rate,
            flatMultiplier = flat,
            gross = gross,
            mealDeductions = deductions,
            net = (gross - deductions).coerceAtLeast(tier.inc * n.toDouble() * 0.0),
            perFullDay = rate,
            perTravelDay = perTravel,
            allMealsProvidedDays = minOf(breakfasts, lunches, dinners)
        )
    }
}

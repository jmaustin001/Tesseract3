package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume

/**
 * Takes one fix and writes it to the log. Shared by the scheduled worker and by the
 * dashboard's on-demand button, so a manual check records exactly what an automatic
 * one would — same accuracy, same fields, same rules.
 */
object Fixer {

    data class Outcome(val state: String, val datum: Datum?, val summary: String)

    @SuppressLint("MissingPermission")
    suspend fun capture(ctx: Context, highAccuracy: Boolean = false): Result<Outcome> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return Result.failure(Exception("Location permission is not granted."))

        val client = LocationServices.getFusedLocationProviderClient(ctx)
        val priority = if (highAccuracy) Priority.PRIORITY_HIGH_ACCURACY
        else Priority.PRIORITY_BALANCED_POWER_ACCURACY

        val loc: Location? = suspendCancellableCoroutine { cont ->
            client.getCurrentLocation(priority, null)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(null) }
        }
        if (loc == null) return Result.failure(Exception("No location available right now."))

        val lat = round5(loc.latitude)
        val lon = round5(loc.longitude)
        val state = resolveState(ctx, lat, lon)
        val datum = Zones.classify(ctx, lat, lon)
        val now = System.currentTimeMillis()

        Store.append(
            ctx, Sample(
                now, Store.dateKey(now), lat, lon, loc.accuracy.toInt(), state,
                datum?.id ?: Zones.OUT_ID, datum?.name ?: Zones.OUT_NAME,
                datum?.role ?: Datum.OTHER, TimeZone.getDefault().id, manual = false
            )
        )

        val where = datum?.name ?: "off station"
        return Result.success(
            Outcome(state, datum, "${States.fullName(state)} · $where · ±${loc.accuracy.toInt()}m")
        )
    }

    /** "?" when there was no network to ask - the coordinates are still logged
     *  and can be resolved later from Settings. */
    fun resolveState(ctx: Context, lat: Double, lon: Double): String = try {
        @Suppress("DEPRECATION")
        val a = Geocoder(ctx, Locale.US).getFromLocation(lat, lon, 1)?.firstOrNull()
        if (a == null) "?" else States.forAddress(a.adminArea, a.countryCode)
    } catch (e: Exception) { "?" }

    data class Located(val lat: Double, val lon: Double, val label: String)

    /**
     * Turns an address into coordinates. Needs a network, and returns null when
     * the place cannot be found rather than guessing at something nearby.
     */
    suspend fun geocodeAddress(ctx: Context, query: String): Located? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                @Suppress("DEPRECATION")
                val a = Geocoder(ctx, Locale.US).getFromLocationName(query, 1)?.firstOrNull()
                    ?: return@withContext null
                val label = listOfNotNull(
                    a.getAddressLine(0) ?: a.featureName,
                    if (a.getAddressLine(0) == null) a.locality else null,
                    if (a.getAddressLine(0) == null) a.adminArea else null
                ).distinct().joinToString(", ")
                Located(
                    String.format(Locale.US, "%.6f", a.latitude).toDouble(),
                    String.format(Locale.US, "%.6f", a.longitude).toDouble(),
                    label.ifBlank { query }
                )
            } catch (e: Exception) { null }
        }

    /** A human label for the prompt - "Ramstein, Rheinland-Pfalz" - never stored. */
    fun describe(ctx: Context, lat: Double, lon: Double): String = try {
        @Suppress("DEPRECATION")
        val a = Geocoder(ctx, Locale.US).getFromLocation(lat, lon, 1)?.firstOrNull()
        listOfNotNull(a?.locality, a?.adminArea, a?.countryName)
            .distinct().joinToString(", ").ifBlank { "" }
    } catch (e: Exception) { "" }

    private fun round5(v: Double) = String.format(Locale.US, "%.5f", v).toDouble()
}

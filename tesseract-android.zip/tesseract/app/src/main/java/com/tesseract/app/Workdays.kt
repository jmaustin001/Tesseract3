package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Residency and income are two different questions.
 *
 * The 183-day test counts days you were PRESENT. A nonresident income
 * allocation counts days you WORKED and where. A Saturday in Virginia counts
 * toward residency and earns nothing; a Tuesday TDY in Texas earns Texas-side
 * wages while adding nothing to the Virginia presence count.
 */
object Workdays {

    /** US federal holidays, with the Saturday/Sunday observed shift applied. */
    fun federalHolidays(year: Int): Set<String> {
        val out = HashSet<String>()
        fun add(c: Calendar) { out.add(key(c)) }

        // fixed dates, observed on the nearest weekday
        listOf(1 to 1, 6 to 19, 7 to 4, 11 to 11, 12 to 25).forEach { (m, d) ->
            val c = cal(year, m, d)
            when (c.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SATURDAY -> c.add(Calendar.DAY_OF_YEAR, -1)
                Calendar.SUNDAY -> c.add(Calendar.DAY_OF_YEAR, 1)
            }
            add(c)
        }
        add(nth(year, 1, Calendar.MONDAY, 3))    // MLK
        add(nth(year, 2, Calendar.MONDAY, 3))    // Presidents
        add(last(year, 5, Calendar.MONDAY))      // Memorial
        add(nth(year, 9, Calendar.MONDAY, 1))    // Labor
        add(nth(year, 10, Calendar.MONDAY, 2))   // Columbus
        add(nth(year, 11, Calendar.THURSDAY, 4)) // Thanksgiving
        return out
    }

    fun isHoliday(date: String): Boolean {
        val y = date.take(4).toIntOrNull() ?: return false
        return date in federalHolidays(y)
    }

    fun weekdayOf(date: String): Int = parse(date)?.get(Calendar.DAY_OF_WEEK) ?: -1

    /** Not a scheduled duty day — Saturday by default, but the week is configurable. */
    fun isNonWorkWeekday(ctx: Context, date: String): Boolean {
        val d = weekdayOf(date)
        return d > 0 && d !in Store.workWeekdays(ctx)
    }

    /**
     * The regular day off of a compressed schedule. Counted in whole weeks from an
     * anchor date you set to any one of your days off.
     */
    fun isRdo(ctx: Context, date: String): Boolean {
        if (!Store.rdoOn(ctx)) return false
        if (weekdayOf(date) != Store.rdoWeekday(ctx)) return false
        val anchor = Store.rdoAnchor(ctx)
        if (anchor.isBlank()) return true          // every such weekday
        val a = parse(anchor) ?: return false
        val d = parse(date) ?: return false
        val days = ((d.timeInMillis - a.timeInMillis) / 86_400_000L).toInt()
        val weeks = Math.floorDiv(days, 7)
        return Math.floorMod(weeks, Store.rdoWeeks(ctx).coerceAtLeast(1)) == 0
    }

    /**
     * Did this day earn money? Any manual override wins outright — that is what
     * makes a Maxiflex or gliding schedule workable, where a Wednesday off is
     * normal and no rule could predict it.
     */
    fun earned(ctx: Context, d: DaySummary): Boolean = earnedOn(ctx, d.date, d.status)

    fun earnedOn(ctx: Context, date: String, status: String): Boolean {
        when (Store.workOverride(ctx, date)) {
            Store.WORKED -> return true
            Store.OFF -> return false
        }
        if (isNonWorkWeekday(ctx, date)) return false
        if (isRdo(ctx, date)) return false
        if (Store.observeHolidays(ctx) && isHoliday(date)) return false
        if (Status.dutyStatus(status) == "Leave") return false
        return true
    }

    /**
     * Scheduled workdays in a whole calendar year, under your own schedule:
     * duty weekdays, less federal holidays if you observe them, less regular days
     * off. A salary divided by this is a real daily rate. Divided by days logged
     * so far, it is nonsense early in the year — one logged day would make the
     * daily rate the entire salary.
     */
    fun scheduledWorkdays(ctx: Context, year: Int): Int {
        val cal = Calendar.getInstance().apply { clear(); set(year, 0, 1) }
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var n = 0
        while (cal.get(Calendar.YEAR) == year) {
            val d = fmt.format(cal.time)
            val scheduled = !isNonWorkWeekday(ctx, d) && !isRdo(ctx, d) &&
                    !(Store.observeHolidays(ctx) && isHoliday(d))
            if (scheduled) n++
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return n
    }

    /** Salary over the year's scheduled workdays. Zero until wages are entered. */
    fun dailyRate(ctx: Context, year: Int): Double {
        val wages = Store.grossWages(ctx)
        val days = scheduledWorkdays(ctx, year)
        return if (wages > 0 && days > 0) wages / days else 0.0
    }

    /** Why the app decided what it decided, in plain words. */
    fun reason(ctx: Context, d: DaySummary): String = reasonOn(ctx, d.date, d.status)

    fun reasonOn(ctx: Context, date: String, status: String): String = when {
        Store.workOverride(ctx, date) == Store.WORKED -> "marked as worked"
        Store.workOverride(ctx, date) == Store.OFF -> "marked as a day off"
        isNonWorkWeekday(ctx, date) -> "not a scheduled duty day"
        isRdo(ctx, date) -> "regular day off"
        Store.observeHolidays(ctx) && isHoliday(date) -> "federal holiday"
        Status.dutyStatus(status) == "Leave" -> "on leave"
        else -> "regular workday"
    }

    /** Flags a day whose income state was guessed from fixes outside duty hours. */
    fun incomeIsSolid(d: DaySummary) = d.fixDuringDuty

    private fun cal(y: Int, m: Int, d: Int): Calendar =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d) }

    private fun nth(y: Int, month: Int, dow: Int, n: Int): Calendar =
        cal(y, month, 1).apply {
            var count = 0
            while (true) {
                if (get(Calendar.DAY_OF_WEEK) == dow) { count++; if (count == n) break }
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

    private fun last(y: Int, month: Int, dow: Int): Calendar =
        cal(y, month, 1).apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            while (get(Calendar.DAY_OF_WEEK) != dow) add(Calendar.DAY_OF_YEAR, -1)
        }

    private fun key(c: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)

    private fun parse(date: String): Calendar? = try {
        Calendar.getInstance().apply {
            time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
        }
    } catch (e: Exception) { null }
}

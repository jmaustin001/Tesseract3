The dashboard card, rebuilt around four figures — and a bug that had been
hiding most of it.

The card had a fixed height and clipped anything past it. Every line added
since 1.23 — the Virginia tax figure, the projection, even the days-of-183
line and the stage bar — was being drawn and then cut off. The tax line
existed; the card simply would not show it. It now grows with its content.

VIRGINIA · SO FAR now reads, in order:
  days in Virginia            — the presence count, toward 183
  days worked there           — the earning days
  earned on those days        — each priced at the SF-50 rate in effect that
                                day, summed, to the cent
  Virginia tax on that        — with the effective rate beside it

The tax rate is worked out directly from your salary, the same figure the
dollars are priced from, rather than from the full allocation chain. It equals
the worksheet's rate exactly — the allocation percentage cancels out — but a
stray figure elsewhere on the Pay screen can no longer knock it off the card.

Also corrected: the dollar figure was labeled "from taxable wages" when it has
always been priced from the SF-50 salary. It now says so.

package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class EarningsActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { EarningsScreen() } }
    }
}

private fun cash(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

@Composable
private fun EarningsScreen() {
    val ctx = LocalContext.current
    var year by remember { mutableIntStateOf(Store.year()) }
    val resumed = (ctx as? EarningsActivity)?.resumeTick ?: 0
    val r = remember(year, resumed) { Earnings.compute(ctx, year) }
    val st = r.counted

    TessScreen("Earnings by place", "$year · logged days only, nothing projected") {

        // the headline: the duty station in the counted state
        TCard("at your duty station in $st", T.Gold) {
            if (r.dutyPlaces.isEmpty()) {
                Hint("No worked day yet at a duty-station datum in $st. A day counts here when " +
                        "a fix lands inside a datum whose role is Duty station — set your " +
                        "Pentagon datum's role under Datums if it is not.")
            } else {
                Text(r.dutyPlaces.joinToString(" · "), fontSize = 13.sp, color = T.Mid)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("${r.dutyWorked}", "days worked", T.Gold, Modifier.weight(1f))
                    StatChip(cash(if (r.dutyWorked > 0) r.dutyDollars / r.dutyWorked else 0.0),
                        "per day", T.Gold, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip(cash(r.dutyDollars), "earned", T.Gold, Modifier.weight(1f))
                    StatChip(cash(r.dutyTax), "$st tax", T.Danger, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text(String.format(Locale.US, "tax at %.2f%% effective", r.taxRate * 100),
                    fontSize = 11.sp, color = T.Low)
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("all of $st", T.Danger) {
            Line3("Days worked in $st", "${r.stateWorked}")
            Line3("Earned on those days", cash(r.stateDollars))
            Line3("$st tax on that", cash(r.stateTax), bold = true)
            Spacer(Modifier.height(6.dp))
            Hint("Every day whose pay $st can reach — the duty station above plus any other " +
                    "worked day that landed in $st. This is the figure that goes to Form 763.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("by state", T.Cyan) {
            Header3("present", "worked", "earned")
            r.byState.forEach { Row3(it.label, "${it.present}", "${it.worked}", cash(it.dollars)) }
            HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 6.dp))
            Row3("All", "", "${r.worked}", cash(r.dollars), bold = true)
            Spacer(Modifier.height(6.dp))
            Hint("Present counts every day with a fix in the state, travel days in both. Worked " +
                    "counts each earning day once, in the state that earned it.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("by place", T.Teal) {
            Header3("present", "worked", "earned")
            if (r.byPlace.isEmpty()) Hint("No datums touched yet this year.")
            r.byPlace.forEach {
                Row3(it.label + (if (it.sub.isNotBlank()) "  ·  " + it.sub else ""),
                    if (it.present > 0) "${it.present}" else "–", "${it.worked}", cash(it.dollars))
            }
            Spacer(Modifier.height(6.dp))
            Hint("Each worked day is credited to one place: the duty-station datum if the day " +
                    "touched one, else the first datum it touched, else elsewhere in the state " +
                    "that earned it. So the column adds up to the year's total.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("by SF-50", T.Violet) {
            if (r.bySf50.isEmpty()) Hint("Add your SF-50s on the Pay screen.")
            r.bySf50.forEach { w ->
                Text((w.record.grade.ifBlank { "SF-50" }) + " · " + cash(w.record.rate) + " a year",
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = T.Hi)
                Text(w.from + " to " + lastDay(w.toExclusive) + " · " + cash(w.perDay) + " a workday",
                    fontSize = 11.sp, color = T.Low)
                Spacer(Modifier.height(4.dp))
                Line3("Worked, anywhere", "${w.worked} days · " + cash(w.dollars))
                Line3("Worked in $st", "${w.stateWorked} days · " + cash(w.stateDollars))
                Spacer(Modifier.height(10.dp))
            }
            Hint("Each SF-50 governs the days from its effective date to the day before the " +
                    "next one. A day is priced at the rate in effect on it — never spread " +
                    "backward or forward onto days it did not cover.")
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostBtn("◀ ${year - 1}", Modifier.weight(1f), color = T.Mid) { year -= 1 }
            GhostBtn("${year + 1} ▶", Modifier.weight(1f), color = T.Mid) { year += 1 }
        }
    }
}

/** The day before an exclusive end date, for display. */
private fun lastDay(toExclusive: String): String = try {
    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val c = java.util.Calendar.getInstance().apply { time = f.parse(toExclusive)!! }
    c.add(java.util.Calendar.DAY_OF_YEAR, -1)
    f.format(c.time)
} catch (e: Exception) { toExclusive }

@Composable
private fun Line3(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 15.sp else 13.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold, color = T.Hi)
    }
}

@Composable
private fun Header3(a: String, b: String, c: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Spacer(Modifier.weight(1f))
        Text(a.uppercase(), fontSize = 9.sp, color = T.Low, modifier = Modifier.width(52.dp))
        Text(b.uppercase(), fontSize = 9.sp, color = T.Low, modifier = Modifier.width(52.dp))
        Text(c.uppercase(), fontSize = 9.sp, color = T.Low, modifier = Modifier.width(96.dp))
    }
}

@Composable
private fun Row3(label: String, a: String, b: String, c: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = T.Hi, modifier = Modifier.weight(1f), maxLines = 2)
        Text(a, fontSize = 12.sp, color = T.Mid, modifier = Modifier.width(52.dp))
        Text(b, fontSize = 12.sp, color = T.Mid, modifier = Modifier.width(52.dp))
        Text(c, fontSize = 12.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = T.Hi, modifier = Modifier.width(96.dp))
    }
}

package com.tesseract.app

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** "Not a place" — stop asking about this spot. */
class DwellReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val lat = intent.getDoubleExtra("lat", 0.0)
        val lon = intent.getDoubleExtra("lon", 0.0)
        if (lat != 0.0 || lon != 0.0) DwellWatch.suppress(ctx, lat, lon)
        ctx.getSystemService(NotificationManager::class.java).cancel(Notifier.ID_PLACE)
    }
}

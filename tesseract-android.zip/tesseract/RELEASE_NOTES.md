Two things a separate relocation W-2 changes.

Wages already sourced by the payer now have their own field. A relocation W-2
carrying a figure in Box 16 was sourced when it was reported, so it is added
whole and never run through the working-day ratio. The worksheet shows the two
buckets separately and says why they are kept apart. In a PCS year the
difference is thousands of dollars in either direction.

And the estimated state tax is now split by who actually bears it. RITA
reimburses substantially all of the additional federal, state and local tax
caused by taxable relocation benefits, so tax attributable to the relocation
W-2 is largely recoverable while tax on ordinary wages is not. Showing one
number for both made the burden look larger than it is.

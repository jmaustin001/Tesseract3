package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * A destination you travel to, with its rates as published.
 *
 * These are not shipped with the app and are not guessed. There are roughly
 * three hundred non-standard areas and their lodging changes month by month;
 * any table built from memory would be wrong somewhere and look right
 * everywhere. So you look a place up once on GSA, type the two numbers, and
 * the app keeps it. Second trip onward is one tap.
 */
data class Locality(
    val id: String,
    val name: String,
    val mie: Double,
    /** Twelve monthly lodging ceilings, January first. Equal values when the
     *  locality is not seasonal. GSA publishes these in whole dollars, but the
     *  type is Double so a figure typed with cents is never silently rounded. */
    val lodging: List<Double>,
    val fiscalYear: Int,
    val noted: String
) {
    fun lodgingFor(month: Int) = lodging.getOrElse(month - 1) { lodging.firstOrNull() ?: 0.0 }
    fun rateFor(month: Int) = lodgingFor(month) + mie
    val seasonal get() = lodging.distinct().size > 1
}

object Localities {

    private const val KEY = "localities"

    fun all(ctx: Context): List<Locality> {
        val a = JSONArray(Store.prefString(ctx, KEY, "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val arr = o.optJSONArray("lodging") ?: JSONArray()
            Locality(
                o.optString("id"), o.optString("name"), o.optDouble("mie", 68.0),
                (0 until arr.length()).map { i -> arr.optDouble(i, 0.0) },
                o.optInt("fy", 0), o.optString("noted", "")
            )
        }
    }

    fun save(ctx: Context, list: List<Locality>) {
        val a = JSONArray()
        list.forEach { l ->
            a.put(JSONObject().apply {
                put("id", l.id); put("name", l.name); put("mie", l.mie)
                put("lodging", JSONArray().also { arr -> l.lodging.forEach { v -> arr.put(v) } })
                put("fy", l.fiscalYear); put("noted", l.noted)
            })
        }
        Store.setPrefString(ctx, KEY, a.toString())
    }

    fun upsert(ctx: Context, l: Locality) {
        val cur = all(ctx).toMutableList()
        val i = cur.indexOfFirst { it.id == l.id }
        if (i >= 0) cur[i] = l else cur.add(l)
        save(ctx, cur)
    }

    fun delete(ctx: Context, id: String) = save(ctx, all(ctx).filterNot { it.id == id })

    fun newId() = "loc" + System.currentTimeMillis().toString().takeLast(7)

    /** GSA's own lookup, for the year and place in question. */
    fun gsaUrl(query: String, fiscalYear: Int): String {
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        return if (q.isBlank()) "https://www.gsa.gov/travel/plan-book/per-diem-rates"
        else "https://www.gsa.gov/travel/plan-book/per-diem-rates/per-diem-rates-results?" +
                "action=perdiems_report&fiscal_year=$fiscalYear&zip=$q&city=$q"
    }
}

package com.tesseract.app

/**
 * An estimate of what a nonresident owes, built the way Form 763 works.
 *
 * Virginia does not tax the allocated slice directly. It computes the tax you
 * would owe as a resident on all your income, then multiplies that by the
 * share of your income that came from Virginia. The two approaches give
 * different answers, and this follows the one the form uses.
 *
 * Rates confirmed current for 2026. Everything here is an estimate for
 * planning — it ignores credits, additions, subtractions, itemised deductions
 * and anything else a return would consider.
 */
object VaTax {

    data class Estimate(
        val totalIncome: Double,
        val vaIncome: Double,
        val allocationPct: Double,
        val deduction: Double,
        val exemptionTotal: Double,
        val taxableAsResident: Double,
        val taxAsResident: Double,
        val vaTax: Double,
        val withheld: Double,
        val shortfall: Double,
        val quartersLeft: Int,
        val perQuarter: Double,
        val effectiveOnVaWages: Double,
        /** Tax attributable to relocation wages — the part RITA should reimburse. */
        val taxOnRelocation: Double,
        /** Tax on ordinary wages — the part that is actually yours. */
        val taxYouBear: Double,
        val year: Int,
        /** VAGI at or above this means a return is required. */
        val filingThreshold: Double,
        val mustFile: Boolean,
        /** How the tax-as-resident builds up, bracket by bracket. */
        val brackets: List<Band>
    )

    data class Band(val from: Double, val to: Double?, val rate: Double, val taxed: Double, val tax: Double)

    /**
     * Standard deduction by tax year — single or married filing separately, then
     * joint. It was $8,000 / $16,000 through 2023, $8,500 / $17,000 for 2024, and
     * $8,750 / $17,500 for 2025 and 2026. Current law has it falling back sharply
     * after 2026 unless the General Assembly extends it, and sources disagree on
     * what happens next — so later years reuse 2026 and the screen says so.
     */
    fun standardDeduction(year: Int, joint: Boolean): Double {
        val single = when {
            year <= 2023 -> 8_000.0
            year == 2024 -> 8_500.0
            else -> 8_750.0
        }
        return if (joint) single * 2 else single
    }

    fun deductionIsProvisional(year: Int) = year > 2026

    const val EXEMPTION = 930.0

    /**
     * Filing threshold, from the Form 763 instructions. Tested against VAGI —
     * essentially federal adjusted gross income from every source — not against
     * the income earned in Virginia. Joint applies only when both spouses have
     * Virginia-source income; otherwise the separate figure does.
     */
    const val THRESHOLD_SEPARATE = 11_950.0
    const val THRESHOLD_JOINT = 23_900.0

    /** 2% to $3,000, 3% to $5,000, 5% to $17,000, 5.75% above. */
    private val BANDS = listOf(
        0.0 to 0.02, 3_000.0 to 0.03, 5_000.0 to 0.05, 17_000.0 to 0.0575
    )

    fun bands(taxable: Double): List<Band> = BANDS.mapIndexed { i, (from, rate) ->
        val to = BANDS.getOrNull(i + 1)?.first
        val top = to ?: Double.MAX_VALUE
        val taxed = (minOf(taxable, top) - from).coerceAtLeast(0.0)
        Band(from, to, rate, taxed, taxed * rate)
    }

    /** 2% to $3,000, 3% to $5,000, 5% to $17,000, 5.75% above. */
    /**
     * The Form 763 effective rate on Virginia wages, worked out directly from
     * total income: tax as a resident divided by total income. It equals the
     * full worksheet's figure exactly — the allocation percentage cancels out —
     * but needs nothing beyond one income figure, so the dashboard can show it
     * without depending on the whole allocation chain being clean.
     */
    fun effectiveRate(totalIncome: Double, joint: Boolean, exemptions: Int, year: Int): Double {
        if (totalIncome <= 0) return 0.0
        val taxable = (totalIncome - standardDeduction(year, joint) -
                exemptions.coerceAtLeast(0) * EXEMPTION).coerceAtLeast(0.0)
        return taxOn(taxable) / totalIncome
    }

    fun taxOn(taxable: Double): Double =
        if (taxable <= 0) 0.0 else bands(taxable).sumOf { it.tax }

    fun estimate(
        totalIncome: Double,
        vaIncome: Double,
        relocationIncome: Double = 0.0,
        joint: Boolean,
        exemptions: Int,
        withheld: Double,
        monthsElapsed: Int,
        year: Int = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
    ): Estimate {
        val deduction = standardDeduction(year, joint)
        val exemptTotal = EXEMPTION * exemptions.coerceAtLeast(0)
        val taxable = (totalIncome - deduction - exemptTotal).coerceAtLeast(0.0)
        val asResident = taxOn(taxable)
        // Form 763 takes the allocation percentage to one decimal place
        val raw = if (totalIncome > 0) (vaIncome / totalIncome).coerceIn(0.0, 1.0) else 0.0
        val pct = Math.round(raw * 1000.0) / 1000.0
        val vaTax = asResident * pct
        val short = (vaTax - withheld).coerceAtLeast(0.0)

        // Virginia estimates are due in May, June, September and January
        val quarters = when (monthsElapsed) {
            in 0..4 -> 4; in 5..5 -> 3; in 6..8 -> 2; else -> 1
        }

        // relocation wages carry their share of the state tax, and RITA is meant
        // to reimburse substantially all of it
        val relocShare = if (vaIncome > 0) (relocationIncome / vaIncome).coerceIn(0.0, 1.0) else 0.0
        val onReloc = vaTax * relocShare

        return Estimate(
            totalIncome = totalIncome,
            vaIncome = vaIncome,
            allocationPct = pct,
            deduction = deduction,
            exemptionTotal = exemptTotal,
            taxableAsResident = taxable,
            taxAsResident = asResident,
            vaTax = vaTax,
            withheld = withheld,
            shortfall = short,
            quartersLeft = quarters,
            perQuarter = if (quarters > 0) short / quarters else short,
            effectiveOnVaWages = if (vaIncome > 0) vaTax / vaIncome else 0.0,
            taxOnRelocation = onReloc,
            taxYouBear = vaTax - onReloc,
            year = year,
            filingThreshold = if (joint) THRESHOLD_JOINT else THRESHOLD_SEPARATE,
            mustFile = totalIncome >= (if (joint) THRESHOLD_JOINT else THRESHOLD_SEPARATE) &&
                    vaIncome > 0,
            brackets = bands(taxable)
        )
    }
}

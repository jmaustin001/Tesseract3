package com.tesseract.app

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Days before the app was logging, filled in from your schedule rather than from
 * GPS. They are kept apart from real fixes on purpose: no coordinates are
 * invented, every one is marked reconstructed in the day view and in every
 * export, and the whole set can be removed in one step. A day that has a real
 * fix is never touched.
 */
object Reconstruct {

    private const val KEY = "reconDays"

    data class Day(
        val state: String,    // where you were
        val zone: String,     // datum name, or blank
        val role: String,     // that datum's role, or blank
        val status: String    // category, or blank
    )

    fun all(ctx: Context): Map<String, Day> {
        val raw = Store.prefString(ctx, KEY, "")
        if (raw.isBlank()) return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { k ->
                val d = o.getJSONObject(k)
                Day(d.optString("s"), d.optString("z"), d.optString("r"), d.optString("c"))
            }
        } catch (e: Exception) { emptyMap() }
    }

    private fun save(ctx: Context, map: Map<String, Day>) {
        val o = JSONObject()
        map.forEach { (k, d) ->
            o.put(k, JSONObject().apply {
                put("s", d.state); put("z", d.zone); put("r", d.role); put("c", d.status)
            })
        }
        Store.setPrefString(ctx, KEY, if (map.isEmpty()) "" else o.toString())
    }

    fun count(ctx: Context) = all(ctx).size

    /** The first day with a real GPS fix, or null if there is none yet. */
    fun firstFix(ctx: Context): String? = Store.samples(ctx).minOfOrNull { it.date }

    data class Plan(val workdays: List<String>, val offDays: List<String>, val skipped: Int)

    /** Which days a fill would write, without writing anything. */
    fun plan(ctx: Context, from: String, toInclusive: String): Plan {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val start = try { fmt.parse(from)!! } catch (e: Exception) { return Plan(emptyList(), emptyList(), 0) }
        val end = try { fmt.parse(toInclusive)!! } catch (e: Exception) { return Plan(emptyList(), emptyList(), 0) }
        val today = Store.today()
        val logged = Store.samples(ctx).map { it.date }.toSet()
        val work = mutableListOf<String>(); val off = mutableListOf<String>(); var skipped = 0
        val cal = Calendar.getInstance().apply { time = start }
        var guard = 0
        while (!cal.time.after(end) && guard++ < 800) {
            val d = fmt.format(cal.time)
            cal.add(Calendar.DAY_OF_YEAR, 1)
            if (d > today) break
            if (d in logged) { skipped++; continue }
            // the same rule every other day uses: duty weekdays, less holidays,
            // regular days off and anything you have marked by hand
            if (Workdays.earnedOn(ctx, d, "")) work.add(d) else off.add(d)
        }
        return Plan(work, off, skipped)
    }

    /** Write the plan. Replaces earlier reconstructions of the same dates only. */
    fun fill(ctx: Context, p: Plan, state: String, workZone: Datum?, workStatus: String,
             offZone: Datum?) {
        val map = all(ctx).toMutableMap()
        p.workdays.forEach {
            map[it] = Day(state, workZone?.name ?: "", workZone?.role ?: "", workStatus)
        }
        p.offDays.forEach {
            map[it] = Day(state, offZone?.name ?: "", offZone?.role ?: "", "")
        }
        save(ctx, map)
    }

    fun clear(ctx: Context) = save(ctx, emptyMap())
}

1.35.0 — TQSE (LP) is priced day by day, each day at its own month's ceiling.

GSA rates change every 1 October, so a stay that runs from September into
October crosses two fiscal years. The screen used to apply one lodging ceiling
to every day.

- The stay now has a first day (YYYY-MM-DD) and a number of days, with a
  "Count through today" button. Every day is dated from the first one.
- "The locality, month by month" shows one row per month the stay touches,
  labeled with its fiscal year (Sep 2026 · FY26, Oct 2026 · FY27), each with
  its own lodging and M&IE ceiling. Rows are saved with an explicit button;
  unsaved or missing figures are marked in gold or red.
- A month with nothing saved is offered a figure but never silently given one:
  the saved destination's figure when its fiscal year matches, else an
  earlier month of the same fiscal year. A figure is never carried across
  1 October.
- The result breaks down by month: days, dates, ceiling, lodging and M&IE.
- The 30-day step-down to 75% is counted from the first day and does not
  reset at a month or fiscal year boundary.
- Tapping a saved destination fills only the months in its own fiscal year.

1.34.1 — Fixes the app not opening.

1.33 changed the dashboard's dollar figure so that every worked day (about
186 with the reconstructed days) recounted the whole year's scheduled
workdays — roughly 68,000 date calculations on the main screen before it
could draw. Android froze it on launch.

- The year's workday count and the federal holiday list are now worked out
  once and kept, keyed on your schedule settings so an edit still takes
  effect immediately.
- SF-50 history, the per-day override tables and the category file are each
  read once per pass instead of once per day.
- The dashboard prices worked days in a single pass.
- New: if the app ever crashes, the reason is saved on the phone and shown at
  the top of the dashboard on the next launch, with Copy details and Dismiss.
  Nothing is sent anywhere.

No figures change — same rules, same results, computed once instead of
hundreds of times.

1.34.0 — The duty station anchors the day.

A day that touched your duty-station datum (the morning arrival is enough),
and whose duty-hours fixes all stayed within the local area around it, is now
normal duty at that station — earned in its state and credited to it in
Earnings by place. A Pentagon 0630–1000, DC 1030–1230, Pentagon 1300 day is a
Pentagon day, even when the 12:00 check lands in the District.

- Settings › Duty hours › Local area around duty station (mi): default 10,
  decimals fine, explicit Save. 10 mi from the Pentagon covers DC, Crystal
  City, Rosslyn and Alexandria. 0 means only fixes inside the datum count.
- A day that leaves the local area (TDY, flying out mid-day) is not anchored
  and is decided by the duty-hours fixes as before.
- Presence is untouched: a DC stop still shows DC in "states present". The
  log tags such a day "local" instead of "split", and it is not counted as a
  travel day or flagged for review.
- The day screen says when Auto anchored the day. Tapping a state or Split
  by hours still overrides it.
- CSV income_state_source reads "duty station, local area" for these days.

1.33.0 — DC, and days split by hours.

Day screen › Which state were you in
- VA, FL and DC are now separate on/off chips; tap every state you were in.
  Auto goes back to what the GPS fixes say. A day in VA and DC is still a
  VA day for the 183-day count.

Day screen › Which state earned it
- DC added alongside VA and FL, for a day worked wholly in the District.
- New "Split by hours": type the hours worked in each state (decimals fine),
  see the percentages, then Save split. Nothing changes until you save;
  Remove split puts the day back. Stored as hours, e.g. VA 4h · DC 4h.
- No datum or radius is needed — the split is set on the day by hand.

Everywhere the day is counted, a split day counts its share: the dashboard,
year tallies, Earnings by place (the DC half shows as "Elsewhere in DC"),
the Form 763 allocation ratio, and the dollars and tax. The day CSV shows
the split in income_state, "split by hand, by hours" as the source, and two
new columns: va_share and va_pay.

1.32.0 — Earnings by place labels places by where they are; Re-match past fixes.

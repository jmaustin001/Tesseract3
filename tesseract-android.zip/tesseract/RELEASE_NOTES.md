Two fixes to the earning figures.

The dashboard showed "$ 1", which reads as one dollar. It meant one earning
day. It now says "1 day" plainly, with what those days earned beneath it —
days times the daily rate — so the number and the money are each labeled.

The daily rate itself was wrong. It divided wages by workdays logged so far,
which early in the year produces absurd figures — with a single logged day,
the "daily rate" was the whole salary. It now divides by the year's scheduled
workdays under your own schedule: duty weekdays, less federal holidays and
regular days off. 2026 has 250, so $138,000 of taxable wages is $552 a day.
The allocation screen and worksheet use the same corrected rate.

Also: a day categorized as travel was being counted toward the twice-a-period
office requirement because a fix landed inside the duty-station datum. Passing
the Pentagon on a travel day is not reporting to it. Office days now require the
day to be categorized Duty Station — or, if left uncategorized, a scheduled
workday with a fix at the duty datum. Anything categorized otherwise never
counts, which keeps the locality count honest rather than generous.

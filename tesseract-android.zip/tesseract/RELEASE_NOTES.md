Fill in the year before the first fix.

The log starts in September, so the allocation was dividing Virginia workdays
by a few weeks of logged days instead of a year's. A new card — at the bottom
of the Year view, and in Settings — fills in the stretch before your first GPS
fix from your schedule: scheduled workdays as earning days, weekends, federal
holidays and regular days off as rest days. You choose the dates (1 January
through the day before your first fix by default), the state, which datum the
workdays and rest days belong to, and the workday category. It shows how many
of each it will write before you confirm.

These days are kept apart from real fixes. No coordinates are invented. A day
with a real fix is never touched. Each one says "reconstructed from your
schedule" in the day view, and "reconstructed" in the states_source and
income_state_source columns of the CSV. The worksheet and How solid this is
count them on their own line, and Needs review leaves them out. One button
removes the whole set.

Leave or TDY inside that stretch can be corrected day by day afterwards, like
any other day.

package com.tesseract.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Residency and income are two different questions.
 *
 * The 183-day test counts days you were PRESENT. A nonresident income
 * allocation counts days you WORKED and where. A Saturday in Virginia counts
 * toward residency and earns nothing; a Tuesday TDY in Texas earns Texas-side
 * wages while adding nothing to the Virginia presence count.
 */
object Workdays {

    /** US federal holidays, with the Saturday/Sunday observed shift applied. */
    fun federalHolidays(year: Int): Set<String> {
        val out = HashSet<String>()
        fun add(c: Calendar) { out.add(key(c)) }

        // fixed dates, observed on the nearest weekday
        listOf(1 to 1, 6 to 19, 7 to 4, 11 to 11, 12 to 25).forEach { (m, d) ->
            val c = cal(year, m, d)
            when (c.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SATURDAY -> c.add(Calendar.DAY_OF_YEAR, -1)
                Calendar.SUNDAY -> c.add(Calendar.DAY_OF_YEAR, 1)
            }
            add(c)
        }
        add(nth(year, 1, Calendar.MONDAY, 3))    // MLK
        add(nth(year, 2, Calendar.MONDAY, 3))    // Presidents
        add(last(year, 5, Calendar.MONDAY))      // Memorial
        add(nth(year, 9, Calendar.MONDAY, 1))    // Labor
        add(nth(year, 10, Calendar.MONDAY, 2))   // Columbus
        add(nth(year, 11, Calendar.THURSDAY, 4)) // Thanksgiving
        return out
    }

    fun isHoliday(date: String): Boolean {
        val y = date.take(4).toIntOrNull() ?: return false
        return date in federalHolidays(y)
    }

    fun weekdayOf(date: String): Int = parse(date)?.get(Calendar.DAY_OF_WEEK) ?: -1

    /** Not a scheduled duty day — Saturday by default, but the week is configurable. */
    fun isNonWorkWeekday(ctx: Context, date: String): Boolean {
        val d = weekdayOf(date)
        return d > 0 && d !in Store.workWeekdays(ctx)
    }

    /**
     * The regular day off of a compressed schedule. Counted in whole weeks from an
     * anchor date you set to any one of your days off.
     */
    fun isRdo(ctx: Context, date: String): Boolean {
        if (!Store.rdoOn(ctx)) return false
        if (weekdayOf(date) != Store.rdoWeekday(ctx)) return false
        val anchor = Store.rdoAnchor(ctx)
        if (anchor.isBlank()) return true          // every such weekday
        val a = parse(anchor) ?: return false
        val d = parse(date) ?: return false
        val days = ((d.timeInMillis - a.timeInMillis) / 86_400_000L).toInt()
        val weeks = Math.floorDiv(days, 7)
        return Math.floorMod(weeks, Store.rdoWeeks(ctx).coerceAtLeast(1)) == 0
    }

    /**
     * Did this day earn money? Any manual override wins outright — that is what
     * makes a Maxiflex or gliding schedule workable, where a Wednesday off is
     * normal and no rule could predict it.
     */
    fun earned(ctx: Context, d: DaySummary): Boolean = earnedOn(ctx, d.date, d.status)

    fun earnedOn(ctx: Context, date: String, status: String): Boolean {
        when (Store.workOverride(ctx, date)) {
            Store.WORKED -> return true
            Store.OFF -> return false
        }
        if (isNonWorkWeekday(ctx, date)) return false
        if (isRdo(ctx, date)) return false
        if (Store.observeHolidays(ctx) && isHoliday(date)) return false
        if (Status.dutyStatus(status) == "Leave") return false
        return true
    }

    /**
     * Scheduled workdays in a whole calendar year, under your own schedule:
     * duty weekdays, less federal holidays if you observe them, less regular days
     * off. A salary divided by this is a real daily rate. Divided by days logged
     * so far, it is nonsense early in the year — one logged day would make the
     * daily rate the entire salary.
     */
    fun scheduledWorkdays(ctx: Context, year: Int): Int =
        scheduledWorkdaysBetween(ctx, "$year-01-01", "${year + 1}-01-01")

    /** Scheduled workdays from one date up to, but not including, another. */
    fun scheduledWorkdaysBetween(ctx: Context, fromInclusive: String, toExclusive: String): Int {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = try { Calendar.getInstance().apply { time = fmt.parse(fromInclusive)!! } }
            catch (e: Exception) { return 0 }
        var n = 0
        var guard = 0
        while (guard++ < 800) {
            val d = fmt.format(cal.time)
            if (d >= toExclusive) break
            if (!isNonWorkWeekday(ctx, d) && !isRdo(ctx, d) &&
                !(Store.observeHolidays(ctx) && isHoliday(d))) n++
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return n
    }

    /**
     * Taxable wages over the year's scheduled workdays. Falls back to the SF-50
     * salary until a Box 1 or LES figure exists — higher, because pre-tax
     * deductions have not come out of it, and labeled as such where shown.
     */
    /** True to divide by paid days (OPM's 2,087 hours), false for days actually worked. */
    fun usePaidDays(ctx: Context) = Store.prefBool(ctx, "ratePaidDays", false)
    fun setUsePaidDays(ctx: Context, v: Boolean) = Store.setPrefBool(ctx, "ratePaidDays", v)

    /** 250-odd worked days, or 260.875 paid days — 2,087 hours over 8. */
    fun rateDivisor(ctx: Context, year: Int): Double =
        if (usePaidDays(ctx)) 2087.0 / 8.0 else scheduledWorkdays(ctx, year).toDouble()

    fun dailyRate(ctx: Context, year: Int): Double {
        val days = rateDivisor(ctx, year)
        if (days <= 0) return 0.0

        // best available basis, in order: a wage figure you set, then what your
        // LES entries project for the year, then the SF-50 salary — blended
        // across a mid-year raise when one is on record
        Store.grossWages(ctx).let { if (it > 0) return it / days }
        Pay.project(ctx, year)?.projectedTaxable?.let { if (it > 0) return it / days }
        blendedAnnualSalary(ctx, year).let { if (it > 0) return it / days }
        return 0.0
    }

    /** The annual figure the daily rate is dividing — shown, so a wrong one is visible. */
    fun rateSource(ctx: Context, year: Int): Double {
        Store.grossWages(ctx).let { if (it > 0) return it }
        Pay.project(ctx, year)?.projectedTaxable?.let { if (it > 0) return it }
        return blendedAnnualSalary(ctx, year)
    }

    /**
     * A wage base far below the SF-50 salary is usually a leftover test figure
     * rather than a real one. Worth flagging rather than quietly dividing by it.
     */
    fun rateLooksWrong(ctx: Context, year: Int): Boolean {
        val salary = maxOf(Store.annualSalary(ctx), Store.priorSalary(ctx))
        val used = rateSource(ctx, year)
        return salary > 0 && used > 0 && used < salary * 0.4
    }

    /** Which figure the rate is resting on, for labeling it honestly. */
    fun rateBasis(ctx: Context, year: Int): String = when {
        Store.grossWages(ctx) > 0 -> "taxable wages"
        (Pay.project(ctx, year)?.projectedTaxable ?: 0.0) > 0 -> "your LES, projected"
        blendedAnnualSalary(ctx, year) > 0 ->
            if (Store.priorSalary(ctx) > 0) "salary, blended across the raise"
            else "salary, before pre-tax deductions"
        else -> ""
    }

    // ---------- date-aware salary, and the running ledger ----------
    //
    // A promotion or a PCS changes the rate partway through the year. A single
    // flat daily rate is wrong for every day on the far side of that date, in
    // both directions. This is the fix: the rate a given day was actually paid
    // at, and a sum over the days actually logged rather than a ratio applied
    // to a full-year guess.

    /** The annual rate in effect on a given date — prior through the day before
     *  the effective date, current from it onward. Falls back to whichever one
     *  is set if the other is not, and to zero if neither is. */
    fun salaryRateOn(ctx: Context, date: String): Double {
        val current = Store.annualSalary(ctx)
        val prior = Store.priorSalary(ctx)
        val eff = Store.salaryEffective(ctx)
        return when {
            prior <= 0 || eff.isBlank() -> current
            date < eff -> prior
            else -> current
        }
    }

    /** The whole year's salary, correctly split across a mid-year raise. Degrades
     *  to the flat current rate when no prior rate or effective date is set. */
    fun blendedAnnualSalary(ctx: Context, year: Int): Double {
        val current = Store.annualSalary(ctx)
        val prior = Store.priorSalary(ctx)
        val eff = Store.salaryEffective(ctx)
        if (prior <= 0 || eff.isBlank() || !eff.startsWith("$year-")) return current
        val total = scheduledWorkdays(ctx, year)
        if (total <= 0) return current
        val before = scheduledWorkdaysBetween(ctx, "$year-01-01", eff)
        val after = total - before
        return prior / total * before + current / total * after
    }

    /** What one workday on a given date was actually worth, salary-wise. */
    fun dailyRateFor(ctx: Context, date: String, year: Int): Double {
        val divisor = scheduledWorkdays(ctx, year)
        if (divisor <= 0) return 0.0
        val rate = salaryRateOn(ctx, date)
        return if (rate > 0) rate / divisor else 0.0
    }

    /**
     * Dollars actually earned in a state, summed one logged workday at a time
     * rather than projected from a ratio. Grows only as real days are logged —
     * "so far," not "by year end." Each day is priced at whatever the salary
     * schedule says was in effect that day, so a raise mid-year is not spread
     * backward or forward onto days it never touched.
     */
    fun earningsAccrued(ctx: Context, year: Int, state: String): Double =
        Store.days(ctx, year)
            .filter { earned(ctx, it) && Store.incomeStateOf(ctx, it) == state }
            .sumOf { dailyRateFor(ctx, it.date, year) }

    /** Why the app decided what it decided, in plain words. */
    fun reason(ctx: Context, d: DaySummary): String = reasonOn(ctx, d.date, d.status)

    fun reasonOn(ctx: Context, date: String, status: String): String = when {
        Store.workOverride(ctx, date) == Store.WORKED -> "marked as worked"
        Store.workOverride(ctx, date) == Store.OFF -> "marked as a day off"
        isNonWorkWeekday(ctx, date) -> "not a scheduled duty day"
        isRdo(ctx, date) -> "regular day off"
        Store.observeHolidays(ctx) && isHoliday(date) -> "federal holiday"
        Status.dutyStatus(status) == "Leave" -> "on leave"
        else -> "regular workday"
    }

    /** Flags a day whose income state was guessed from fixes outside duty hours. */
    fun incomeIsSolid(d: DaySummary) = d.fixDuringDuty

    private fun cal(y: Int, m: Int, d: Int): Calendar =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d) }

    private fun nth(y: Int, month: Int, dow: Int, n: Int): Calendar =
        cal(y, month, 1).apply {
            var count = 0
            while (true) {
                if (get(Calendar.DAY_OF_WEEK) == dow) { count++; if (count == n) break }
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

    private fun last(y: Int, month: Int, dow: Int): Calendar =
        cal(y, month, 1).apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            while (get(Calendar.DAY_OF_WEEK) != dow) add(Calendar.DAY_OF_YEAR, -1)
        }

    private fun key(c: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)

    private fun parse(date: String): Calendar? = try {
        Calendar.getInstance().apply {
            time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
        }
    } catch (e: Exception) { null }
}

package com.tesseract.app

import android.app.NotificationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A notification can only show three buttons. This is the full five-way picker,
 * opened by tapping the notification body, with a free-text note for orders numbers.
 */
class DayPromptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val date = intent.getStringExtra("date") ?: Store.today()
        val summary = intent.getStringExtra("summary") ?: ""
        val guess = intent.getStringExtra("guess") ?: Status.DUTY

        setContent {
            MaterialTheme {
                var note by remember { mutableStateOf(Store.statusOf(this, date).second) }
                var chosen by remember { mutableStateOf(Store.statusOf(this, date).first.ifBlank { guess }) }

                Column(
                    Modifier.fillMaxSize().background(Color(0xFFE7EBEE)).padding(20.dp)
                ) {
                    Spacer(Modifier.height(28.dp))
                    Text("Categorise $date", fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold, color = Color(0xFF16232B))
                    if (summary.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(summary, fontSize = 13.sp, color = Color(0xFF5A6A72))
                    }
                    Spacer(Modifier.height(18.dp))

                    Status.all.forEach { s ->
                        val selected = s == chosen
                        Surface(
                            color = if (selected) Color(0xFF16232B) else Color.White,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            onClick = { chosen = s }
                        ) {
                            Row(Modifier.padding(16.dp)) {
                                Text(
                                    s, fontSize = 16.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) Color.White else Color(0xFF16232B),
                                    modifier = Modifier.weight(1f)
                                )
                                if (s == guess) Text(
                                    "GPS suggests", fontSize = 11.sp,
                                    color = if (selected) Color(0xFFAFC0C8) else Color(0xFF5A6A72)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Note — orders number, location, purpose") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            Store.setStatus(this@DayPromptActivity, date, chosen, note)
                            getSystemService(NotificationManager::class.java).cancel(Notifier.ID_STATUS)
                            finish()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16232B)),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save") }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Not now")
                    }
                }
            }
        }
    }
}

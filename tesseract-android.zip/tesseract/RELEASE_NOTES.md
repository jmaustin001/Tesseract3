Three fixes.

Numeric fields rejected the decimal point, so an LES figure could only be
entered rounded. They now take cents, with a decimal keypad.

The TQSE and TDY screens kept nothing between visits. Every figure you typed
was thrown away on leaving and the fields reverted to their defaults — which
is why the room rate and tax would not stick and the lodging maximum kept
coming back as 199. Every field on both screens now persists, as does a
half-finished LES entry.

The lodging tax line is shown in the reimbursement summary whether or not it
is zero, so the total always accounts for itself rather than silently omitting
a row.

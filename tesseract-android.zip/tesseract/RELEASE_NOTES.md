Destinations, saved once and reused.

Per diem is per locality, and lodging moves month by month — the DC area runs
from about $181 in August to $302 in the spring. A calculator that ignores
that gives the wrong answer confidently.

So the calculator now keeps destinations. Type a city or ZIP, tap through to
GSA's official table, read off M&IE and lodging, and save it. Every trip after
that is one tap. Seasonal places take twelve monthly lodging figures; the rest
take one. Choosing a month changes the rate, and the chosen destination drives
the meal deduction amounts too, not just the total.

What the app deliberately does not do is ship a nationwide rate table. There
are around three hundred non-standard areas with monthly variation; a table
built from memory would be wrong in places and look right everywhere. These
numbers are the ones you read off the official source, and each saved
destination records the fiscal year it was entered under, so a stale figure is
visible rather than silent.

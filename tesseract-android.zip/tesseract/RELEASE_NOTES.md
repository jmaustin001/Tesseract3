Build fix: the salary card referred to a variable belonging to the screen
around it rather than to itself. Compile error, nothing more.

Everything in 1.24.x is here — both daily rates side by side and reconciled to
the salary, the warning when an SF-50 rate starts partway through the year,
cents where cents matter, and figures that shrink to fit rather than wrapping.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tesseract.app"
    compileSdk = 34

    // A fixed signing key shipped with the project. Without it, every CI machine
    // invents its own throwaway debug key and Android refuses to install a new
    // build over the old one.
    signingConfigs {
        create("tesseract") {
            storeFile = file("tesseract.jks")
            storePassword = "tesseract2026"
            keyAlias = "tesseract"
            keyPassword = "tesseract2026"
        }
    }

    defaultConfig {
        applicationId = "com.tesseract.app"
        minSdk = 26
        targetSdk = 34
        // CI supplies the run number so the code climbs every build; a local
        // build falls back to 1.
        versionCode = (System.getenv("BUILD_NUMBER") ?: "1").toInt()
        versionName = "1.4.1"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("tesseract")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("tesseract")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}

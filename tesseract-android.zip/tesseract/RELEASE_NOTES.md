LES input is on the Pay screen — it always has been — and this build makes it
do more, fixes a real accuracy gap, and gives every dollar field full decimal
power.

DASHBOARD, REBUILT AROUND AN ACTUAL RUNNING TALLY
The headline figure used to multiply today's earning-day count by a single
flat daily rate — not tied to which days were actually logged, and wrong on
either side of a mid-year raise. It's now a real ledger: every day the log
marks as worked and earning in Virginia gets priced at whatever the salary
schedule says was in effect on that date, and the figures are summed. It
grows only as real days are logged — "so far," not a guess for the year.

A second line, clearly separated and honestly labeled "if this pace holds all
year," keeps the existing ratio-based projection — the same figures the
allocation worksheet already uses, so the two can never disagree. Before, one
line said "so far" while quietly showing a full-year projection; that
confusion is why the numbers looked wrong. Now there are two numbers with two
honest labels: an actual so far, and a projection for the year.

TWO SF-50 RATES, FOR A YEAR WITH A PROMOTION OR A PCS IN IT
The salary card now takes a prior rate (block 12C) alongside the current one
(block 20C). With both entered, every calculation — the daily rate, the
running ledger, the wage base fallback — prices each day at whichever rate was
actually in effect on it, split by scheduled workdays on each side of the
effective date rather than a flat average.

THE LES ENTRY NOW CAPTURES THE WHOLE PAGE
Hourly rate, annual salary as printed on the LES, and year-to-date pre-tax
deductions (TSP, FEHB, FSA and the like) can be entered alongside gross,
taxable, and federal and state tax. None of these change the tax figures —
Box 1 taxable wages still drives the allocation — but a mismatch between what
you'd expect and what's on the page now shows up rather than going unnoticed.

DECIMAL POWER, EVERYWHERE A DOLLAR CAN GO
Four fields were still whole-dollar only: the destination editor's M&IE and
lodging figures, the seasonal monthly lodging grid, and a custom per diem rate.
Typing cents into any of them would have been silently truncated on save,
which is the same failure already fixed once elsewhere in the app. The
underlying per diem and locality data now hold cents properly, so nothing
saved through these fields is thrown away.

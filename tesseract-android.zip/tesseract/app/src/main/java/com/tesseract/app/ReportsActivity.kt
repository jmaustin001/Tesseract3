package com.tesseract.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ReportsActivity : ComponentActivity() {
    var onFileChosen: ((Uri) -> Unit)? = null
    var onFileCreated: ((Uri) -> Unit)? = null

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { onFileChosen?.invoke(it) } }
    private val createDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")) { u ->
        u?.let { onFileCreated?.invoke(it) } }

    fun pickBackup(cb: (Uri) -> Unit) { onFileChosen = cb; openDoc.launch(arrayOf("application/json", "*/*")) }
    fun saveBackup(name: String, cb: (Uri) -> Unit) { onFileCreated = cb; createDoc.launch(name) }
    fun writeTo(uri: Uri, text: String) = contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
    fun readFrom(uri: Uri): String = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { ReportsScreen() } }
    }
}

@Composable
private fun ReportsScreen() {
    val ctx = LocalContext.current
    val act = ctx as? ReportsActivity
    val year = Store.year()
    var email by remember { mutableStateOf(Store.email(ctx)) }
    var msg by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    var confirmReplace by remember { mutableStateOf(false) }

    val counted = Store.countedState(ctx)
    val days = Store.days(ctx, year)
    val gaps = Store.gapDays(ctx, year).size
    val untagged = Store.untaggedOutDays(ctx, year).size

    fun restore(uri: Uri, replace: Boolean) {
        val a = act ?: return
        val r = Backup.restore(a, a.readFrom(uri), replace)
        if (r.error != null) { msg = r.error; bad = true; return }
        bad = false
        msg = "Restored ${r.samplesAdded} fixes, ${r.tagsAdded} categories." +
                (if (r.samplesSkipped > 0) " ${r.samplesSkipped} already here." else "")
    }

    TessScreen("Reports", "export · email · backup") {

        TCard("this year", T.Gold) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("${Store.stateDays(ctx, counted, year)}", "$counted days", T.Gold, Modifier.weight(1f))
                StatChip("${days.size}", "logged", T.Cyan, Modifier.weight(1f))
                StatChip("$gaps", "no data", if (gaps > 0) T.Danger else T.Teal, Modifier.weight(1f))
            }
            if (gaps > 0 || untagged > 0) {
                Spacer(Modifier.height(12.dp))
                Hint("The report email lists these problems in the body, so nothing goes out " +
                        "looking cleaner than the data behind it.")
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("wage allocation", T.Gold) {
            Hint("Days worked in the counted state over days worked anywhere, applied to " +
                    "your gross wages. Produces a worksheet for a CPA rather than a filled " +
                    "form — the figures with their reasoning attached.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Open wage allocation", accent = T.Gold) {
                ctx.startActivity(Intent(ctx, AllocationActivity::class.java))
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("read it here", T.Cyan) {
            Hint("The whole log on screen, filterable by month, earning days, or days " +
                    "that need review. No need to email yourself to check something.")
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Open the log") {
                ctx.startActivity(Intent(ctx, LogActivity::class.java))
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("send", T.Violet) {
            DarkField(email, "Send reports to", Modifier.fillMaxWidth()) {
                email = it; Store.setEmail(ctx, it)
            }
            Spacer(Modifier.height(12.dp))
            PrimaryBtn("Email the log now", accent = T.Violet) {
                ctx.startActivity(Intent.createChooser(Reports.emailIntent(ctx, year), "Send report"))
            }
            Spacer(Modifier.height(10.dp))
            Hint("Three files attach: one row per day, one row per raw fix, and a JSON backup. " +
                    "A reminder arrives on the 1st of each month.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("backup", T.Cyan) {
            PrimaryBtn("Save a backup file") {
                act?.saveBackup(Backup.suggestedFileName()) { uri ->
                    act.writeTo(uri, Backup.build(act)); msg = "Backup saved."; bad = false
                }
            }
            Spacer(Modifier.height(8.dp))
            GhostBtn("Restore — merge") { act?.pickBackup { u -> restore(u, false) } }
            Spacer(Modifier.height(8.dp))
            if (!confirmReplace) {
                GhostBtn("Restore — replace everything", color = T.Danger) { confirmReplace = true }
            } else {
                Hint("Replace wipes this phone's log, categories and datums first. That is the " +
                        "new-phone path, not the oops path.")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostBtn("Choose file", Modifier.weight(1f), color = T.Danger) {
                        confirmReplace = false; act?.pickBackup { u -> restore(u, true) }
                    }
                    GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { confirmReplace = false }
                }
            }
            if (msg.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(msg, fontSize = 12.sp, color = if (bad) T.Danger else T.Teal)
            }
            Spacer(Modifier.height(10.dp))
            Hint("Merge adds only what is missing and never overwrites a category already here. " +
                    "Save to Drive, not the phone — a backup on the device it backs up is not a backup.")
        }
    }
}

package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class TqseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { TqseScreen() } }
    }
}

private fun cash(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)
private val MONTHS_T = listOf("Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec")

@Composable
private fun TqseScreen() {
    val ctx = LocalContext.current

    // everything on this screen is remembered between visits — a relocation is
    // planned over weeks, not filled in once
    var days by remember { mutableStateOf(Store.prefString(ctx, "tqDays", "30")) }
    var lodgingMax by remember { mutableStateOf(Store.prefString(ctx, "tqLodgeMax", "199")) }
    var mieMax by remember { mutableStateOf(Store.prefString(ctx, "tqMieMax", "92")) }
    var actualLodging by remember { mutableStateOf(Store.prefString(ctx, "tqRoom", "180")) }
    var lodgingTax by remember { mutableStateOf(Store.prefString(ctx, "tqTax", "0")) }
    var over12 by remember { mutableStateOf(Store.prefString(ctx, "tqOver12", "0")) }
    var under12 by remember { mutableStateOf(Store.prefString(ctx, "tqUnder12", "0")) }
    var month by remember {
        mutableIntStateOf(Store.prefInt(ctx, "tqMonth",
            java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1))
    }

    // tax inputs
    var fed by remember { mutableStateOf(Store.prefString(ctx, "tqFed", "22")) }
    var state by remember { mutableStateOf(Store.prefString(ctx, "tqState", "5.75")) }

    var locTick by remember { mutableIntStateOf(0) }
    var loc by remember { mutableStateOf<Locality?>(null) }


    val lMax = lodgingMax.toDoubleOrNull() ?: 0.0
    val mMax = mieMax.toDoubleOrNull() ?: 0.0
    val localityRate = lMax + mMax

    val lp = Perdiem.lodgingsPlus(
        days = days.toIntOrNull() ?: 0,
        actualLodgingPerNight = actualLodging.toDoubleOrNull() ?: 0.0,
        lodgingTaxPerNight = lodgingTax.toDoubleOrNull() ?: 0.0,
        lodgingMax = lMax, mieMax = mMax,
        over12 = over12.toIntOrNull() ?: 0,
        under12 = under12.toIntOrNull() ?: 0
    )

    val payout = lp.total
    val tax = RelocTax.compute(
        taxable = payout,
        federalMarginal = (fed.toDoubleOrNull() ?: 22.0) / 100.0,
        stateMarginal = (state.toDoubleOrNull() ?: 0.0) / 100.0
    )

    TessScreen("TQSE (LP)", "lodgings plus · temporary quarters") {

        Spacer(Modifier.height(12.dp))
        TCard("lodgings plus reimbursement", T.Gold) {
            Text(cash(payout), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = T.Gold)
            Text("lodging against receipts, M&IE flat", fontSize = 12.sp, color = T.Mid)

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("First ${lp.first.days} days at ${(lp.first.factor * 100).toInt()}%",
                    fontSize = 12.sp, color = T.Low, modifier = Modifier.weight(1f))
            }
            Line("  lodging, capped at ${cash(lp.first.lodgingCap)} a night",
                    cash(lp.first.lodgingPaid))
                Line("  M&IE, flat", cash(lp.first.miePaid))
                if (lp.second.days > 0) {
                    Spacer(Modifier.height(8.dp))
                    Text("Next ${lp.second.days} days at ${(lp.second.factor * 100).toInt()}%",
                        fontSize = 12.sp, color = T.Low)
                    Line("  lodging, capped at ${cash(lp.second.lodgingCap)} a night",
                        cash(lp.second.lodgingPaid))
                    Line("  M&IE, flat", cash(lp.second.miePaid))
                }
                HorizontalDivider(color = T.Edge, modifier = Modifier.padding(vertical = 8.dp))
                Line("Lodging, against the cap", cash(lp.lodgingTotal))
                Line("M&IE, flat", cash(lp.mieTotal))
                Line("Lodging tax, outside the cap", cash(lp.taxTotal))
                Line("Total", cash(lp.total), bold = true)
            if (lp.cappedOut && lMax > 0.0) {
                Spacer(Modifier.height(8.dp))
                Text("Your lodging exceeds the cap — the excess is yours to absorb.",
                    fontSize = 11.sp, color = T.Danger)
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("what this is taxed at", T.Danger) {
            Text("Every dollar of it is wages.", fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold, color = T.Hi)
            Spacer(Modifier.height(6.dp))
            Hint("Since 2018 civilian relocation reimbursements are reported on the W-2 " +
                    "and taxed. TDY per diem is not — that is the difference between the " +
                    "two calculators, and it is why WTA and RITA exist.")

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(fed, "Federal marginal %", Modifier.weight(1f), numeric = true) { fed = it; Store.setPrefString(ctx, "tqFed", it) }
                DarkField(state, "State marginal %", Modifier.weight(1f), numeric = true) { state = it; Store.setPrefString(ctx, "tqState", it) }
            }
            Spacer(Modifier.height(6.dp))
            Hint("Leave state at zero if you will still be a Florida resident when this is " +
                    "paid. If Virginia has you by then, 5.75 is the top rate.")

            Spacer(Modifier.height(14.dp))
            Line("Reimbursement", cash(tax.taxable))
            Line("WTA advanced at ${(tax.wtaRate * 100).toInt()}%", cash(tax.wta))
            Line("Reported as wages", cash(tax.grossedUp), bold = true)
            Spacer(Modifier.height(10.dp))
            Line("Combined marginal rate", String.format(Locale.US, "%.2f%%", tax.cmtr * 100))
            Line("Full gross-up needed", cash(tax.trueGrossUp))
            Line(
                if (tax.ritaEstimate >= 0) "RITA owed to you next year"
                else "Owed back at RITA settlement",
                cash(kotlin.math.abs(tax.ritaEstimate)),
                bad = tax.ritaEstimate < 0
            )
            Spacer(Modifier.height(10.dp))
            Hint("WTA is an advance at the flat 22% supplemental rate. RITA settles the " +
                    "difference the following year against what you actually owed — and if " +
                    "your real rate is below 22%, RITA runs the other way and you repay. " +
                    "You must file for RITA; it does not arrive on its own.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("the locality", T.Teal) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(lodgingMax, "Lodging max, per night", Modifier.weight(1f),
                    numeric = true) { lodgingMax = it; Store.setPrefString(ctx, "tqLodgeMax", it) }
                DarkField(mieMax, "M&IE max, per day", Modifier.weight(1f),
                    numeric = true) { mieMax = it; Store.setPrefString(ctx, "tqMieMax", it) }
            }
            val differs = loc != null &&
                    (lMax != loc!!.lodgingFor(month).toDouble() ||
                            mMax != loc!!.mie.toDouble())
            if (loc != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (differs) "Edited — these differ from what ${loc!!.name} has stored."
                    else "Filled from ${loc!!.name} for ${MONTHS_T[month - 1]}.",
                    fontSize = 11.sp, color = if (differs) T.Gold else T.Teal
                )
            }
            if (lMax <= 0.0) {
                Spacer(Modifier.height(8.dp))
                Text("No lodging ceiling set — enter the locality maximum or the lodging " +
                        "line will compute as zero.", fontSize = 12.sp, color = T.Danger)
            }

            val saved = remember(locTick) { Localities.all(ctx) }
            if (saved.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                saved.forEach { l ->
                    Row(Modifier.fillMaxWidth().clickable {
                        loc = l
                        lodgingMax = fmtNum(l.lodgingFor(month))
                        mieMax = fmtNum(l.mie)
                    }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp))
                            .background(if (loc?.id == l.id) T.Teal else T.Edge))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(l.name, fontSize = 14.sp, color = T.Hi)
                            if (l.lodgingFor(month) <= 0)
                                Text("no lodging figure saved", fontSize = 10.sp, color = T.Danger)
                        }
                        Text(cash(l.rateFor(month).toDouble()), fontSize = 12.sp, color = T.Mid)
                    }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Hint("Destinations saved on the TDY screen appear here too.")
            }

            if (loc != null) {
                Spacer(Modifier.height(10.dp))
                GhostBtn("Save these figures onto ${loc!!.name} for ${MONTHS_T[month - 1]}",
                    color = T.Teal) {
                    val l = loc!!
                    val updated = l.lodging.toMutableList().also {
                        while (it.size < 12) it.add(lMax)
                        it[month - 1] = lMax
                    }
                    Localities.upsert(ctx, l.copy(lodging = updated, mie = mMax))
                    locTick++
                }
                Spacer(Modifier.height(6.dp))
                Hint("Fixes a destination saved without lodging, without going back to the " +
                        "other screen.")
            }

            Spacer(Modifier.height(12.dp))
            Text("MONTH IN QUARTERS", fontSize = 9.sp, color = T.Low,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(7.dp))
            Column {
                MONTHS_T.chunked(6).forEachIndexed { row, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        chunk.forEachIndexed { col, m ->
                            val idx = row * 6 + col + 1
                            val on = month == idx
                            Box(
                                Modifier.weight(1f).clip(RoundedCornerShape(7.dp))
                                    .background(if (on) T.Teal.copy(alpha = .20f) else T.Glow)
                                    .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(7.dp))
                                    .clickable {
                                        month = idx
                                        Store.setPrefInt(ctx, "tqMonth", idx)
                                        loc?.let {
                                            lodgingMax = fmtNum(it.lodgingFor(idx))
                                            Store.setPrefString(ctx, "tqLodgeMax", lodgingMax)
                                        }
                                    }.padding(vertical = 9.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(m, fontSize = 10.sp, color = if (on) T.Teal else T.Mid)
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("the stay", T.Cyan) {
            DarkField(days, "Days in temporary quarters", Modifier.fillMaxWidth(), integer = true) {
                days = it; Store.setPrefString(ctx, "tqDays", it)
            }
            Spacer(Modifier.height(6.dp))
            Hint("The multiplier drops from 100% to 75% after day 30. The clock does not " +
                    "stop for leave taken during the period.")

            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(actualLodging, "Room rate, per night", Modifier.weight(1f),
                    numeric = true) { actualLodging = it; Store.setPrefString(ctx, "tqRoom", it) }
                DarkField(lodgingTax, "Tax, per night", Modifier.weight(1f), numeric = true) {
                    lodgingTax = it; Store.setPrefString(ctx, "tqTax", it)
                }
            }
            Spacer(Modifier.height(8.dp))
            Hint("Keep them apart. The room rate is what counts against the ceiling; " +
                    "lodging tax is a separately reimbursable TQSE miscellaneous expense " +
                    "and is paid on top of it. Rolling the tax into the room rate would " +
                    "push you into the cap for money you never actually spent on the room.")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DarkField(over12, "Spouse and 12+", Modifier.weight(1f), integer = true) {
                    over12 = it; Store.setPrefString(ctx, "tqOver12", it)
                }
                DarkField(under12, "Under 12", Modifier.weight(1f), integer = true) {
                    under12 = it; Store.setPrefString(ctx, "tqUnder12", it)
                }
            }
            Spacer(Modifier.height(8.dp))
            Hint("Each person adds to the daily ceiling: 50% for a spouse or anyone twelve " +
                    "and over, 30% for under twelve, in the first period.")
            Spacer(Modifier.height(10.dp))
            Hint("Laundry and dry cleaning go the other way — the same rule folded those " +
                    "into the daily M&IE allowance, so they are not claimed separately.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("before you rely on this", T.Edge) {
            Hint("Lodgings Plus is the method DoD authorises; Actual Expense was dropped as " +
                    "redundant and Lump Sum is not available here. The percentage multipliers come from JTR Table " +
                    "5-85 and have already moved once — confirm them against the current table " +
                    "before planning around a figure. A planning estimate, settled by your " +
                    "travel office.")
        }
    }
}

@Composable
private fun Line(label: String, value: String, bold: Boolean = false, bad: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = T.Mid, modifier = Modifier.weight(1f))
        Text(value, fontSize = if (bold) 16.sp else 14.sp,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (bad) T.Danger else T.Hi)
    }
}

package com.tesseract.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Sample(
    val timestamp: Long,
    val date: String,
    val lat: Double,
    val lon: Double,
    val accuracyM: Int,
    val state: String,      // reverse-geocoded
    val zoneId: String,     // datum id, or Zones.OUT_ID
    val zoneName: String,   // snapshot of the datum name at the time of the fix
    val zoneRole: String,   // snapshot of the role
    val tz: String,
    val manual: Boolean
)

/**
 * Day categories. These are stable across any number of datums because they key off
 * the datum's role, not its name — rename or move a datum and the labels still work.
 */
object Status {
    const val UNSET = ""
    const val DUTY = "Duty Station"
    const val LEAVE_RES = "Leave Residence"
    const val TDY_RES = "TDY Residence"
    const val TDY_OTHER = "TDY Other"
    const val LEAVE_OTHER = "Leave Other"

    val all = listOf(DUTY, LEAVE_RES, TDY_RES, TDY_OTHER, LEAVE_OTHER)

    /** Anything you typed yourself rather than picked from the five. */
    fun isCustom(label: String) = label.isNotBlank() && label !in all

    fun dutyStatus(label: String) = when {
        label == DUTY -> "Duty"
        label == LEAVE_RES || label == LEAVE_OTHER -> "Leave"
        label == TDY_RES || label == TDY_OTHER -> "TDY"
        isCustom(label) -> "Custom"
        else -> ""
    }

    fun place(label: String) = when {
        label == DUTY -> "Duty station"
        label == LEAVE_RES || label == TDY_RES -> "Residence"
        label == TDY_OTHER || label == LEAVE_OTHER -> "Other"
        isCustom(label) -> "Custom"
        else -> ""
    }

    fun guessFor(role: String) = when (role) {
        Datum.DUTY -> DUTY
        Datum.RESIDENCE -> LEAVE_RES
        else -> TDY_OTHER
    }
}

data class DaySummary(
    val date: String,
    val states: Set<String>,
    val zones: Set<String>,     // datum names
    val roles: Set<String>,     // datum roles
    val sampleCount: Int,
    val status: String,
    val note: String,
    /** The state that earned the day's wages - decided by fixes during duty hours. */
    val primaryState: String = "",
    /** True when at least one fix landed inside duty hours, so the call is solid. */
    val fixDuringDuty: Boolean = false,
    /** Filled in from your schedule, before the app was logging — no GPS behind it. */
    val reconstructed: Boolean = false,
    /** The duty-station datum the day was anchored to, when the rest of the duty
     *  day stayed within the local area around it. Blank otherwise. */
    val dutyAnchor: String = ""
)

object Store {
    private const val FILE = "samples.json"
    private const val TAGS = "tags.json"
    private const val DATUMS = "datums.json"
    private const val PREFS = "tesseract_prefs"

    private fun f(ctx: Context, n: String) = File(ctx.filesDir, n)
    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dateKey(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))
    fun today(): String = dateKey(System.currentTimeMillis())
    fun year(): Int = Calendar.getInstance().get(Calendar.YEAR)

    // ---------- datums ----------

    /** Seeded once on first run; everything after that is whatever you edit it to. */
    private fun seed() = listOf(
        Datum("d1", "Oviedo residence", 28.6386, -81.1230, 50.0, Datum.RESIDENCE),
        Datum("d2", "Crystal City", 38.8566, -77.0510, 20.0, Datum.DUTY)
    )

    fun datums(ctx: Context): List<Datum> {
        if (!f(ctx, DATUMS).exists()) { saveDatums(ctx, seed()); return seed() }
        val a = JSONArray(f(ctx, DATUMS).readText())
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Datum(
                o.getString("id"), o.getString("name"),
                o.getDouble("lat"), o.getDouble("lon"),
                o.getDouble("radius"), o.optString("role", Datum.OTHER),
                o.optInt("color", 0)
            )
        }
    }

    @Synchronized
    fun saveDatums(ctx: Context, list: List<Datum>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id); put("name", it.name)
                put("lat", it.lat); put("lon", it.lon)
                put("radius", it.radiusMiles); put("role", it.role)
                put("color", it.color)
            })
        }
        f(ctx, DATUMS).writeText(a.toString())
    }

    fun upsertDatum(ctx: Context, d: Datum) {
        val list = datums(ctx).toMutableList()
        val i = list.indexOfFirst { it.id == d.id }
        if (i >= 0) list[i] = d else list.add(d)
        saveDatums(ctx, list)
    }

    fun deleteDatum(ctx: Context, id: String) =
        saveDatums(ctx, datums(ctx).filterNot { it.id == id })

    fun newDatumId() = "d" + System.currentTimeMillis().toString().takeLast(7)

    // ---------- samples ----------

    private fun arr(ctx: Context, n: String): JSONArray =
        if (f(ctx, n).exists()) JSONArray(f(ctx, n).readText()) else JSONArray()

    @Synchronized
    fun append(ctx: Context, s: Sample) {
        val a = arr(ctx, FILE)
        a.put(JSONObject().apply {
            put("ts", s.timestamp); put("date", s.date)
            put("lat", s.lat); put("lon", s.lon); put("acc", s.accuracyM)
            put("state", s.state)
            put("zoneId", s.zoneId); put("zoneName", s.zoneName); put("zoneRole", s.zoneRole)
            put("tz", s.tz); put("manual", s.manual)
        })
        f(ctx, FILE).writeText(a.toString())
    }

    fun samples(ctx: Context): List<Sample> {
        val a = arr(ctx, FILE)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Sample(
                o.getLong("ts"), o.getString("date"),
                o.optDouble("lat", 0.0), o.optDouble("lon", 0.0), o.optInt("acc", 0),
                o.optString("state", "?"),
                o.optString("zoneId", Zones.OUT_ID),
                o.optString("zoneName", Zones.OUT_NAME),
                o.optString("zoneRole", Datum.OTHER),
                o.optString("tz", ""), o.optBoolean("manual", false)
            )
        }
    }

    /**
     * Measure every past fix against the datums as they stand now. A fix keeps the
     * datum it was tagged with when it was taken; this is the explicit, one-button
     * exception, for a datum added or moved after the fixes it should have caught.
     * Each changed fix keeps its original tag, so undoRematch puts it all back.
     * Only the datum tag changes — never the state, the time or the coordinates.
     */
    data class Rematch(val fixesChanged: Int, val daysChanged: Int)

    @Synchronized
    fun rematchZones(ctx: Context, dryRun: Boolean): Rematch {
        val a = arr(ctx, FILE)
        val list = datums(ctx)
        var n = 0; val days = mutableSetOf<String>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val lat = o.optDouble("lat", 0.0); val lon = o.optDouble("lon", 0.0)
            if (lat == 0.0 && lon == 0.0) continue
            val z = list.map { it to Zones.milesFrom(it, lat, lon) }
                .filter { it.second <= it.first.radiusMiles }
                .minByOrNull { it.second }?.first
            val id = z?.id ?: Zones.OUT_ID
            val name = z?.name ?: Zones.OUT_NAME
            val role = z?.role ?: Datum.OTHER
            if (o.optString("zoneId") == id && o.optString("zoneName") == name &&
                o.optString("zoneRole") == role) continue
            n++; days.add(o.optString("date"))
            if (dryRun) continue
            if (!o.has("z0Name")) {
                o.put("z0Id", o.optString("zoneId", Zones.OUT_ID))
                o.put("z0Name", o.optString("zoneName", Zones.OUT_NAME))
                o.put("z0Role", o.optString("zoneRole", Datum.OTHER))
            }
            o.put("zoneId", id); o.put("zoneName", name); o.put("zoneRole", role)
        }
        if (!dryRun && n > 0) f(ctx, FILE).writeText(a.toString())
        return Rematch(n, days.size)
    }

    /** How many fixes carry a re-matched tag that undoRematch would restore. */
    fun rematchedCount(ctx: Context): Int {
        val a = arr(ctx, FILE)
        return (0 until a.length()).count { a.getJSONObject(it).has("z0Name") }
    }

    @Synchronized
    fun undoRematch(ctx: Context): Int {
        val a = arr(ctx, FILE)
        var n = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!o.has("z0Name")) continue
            o.put("zoneId", o.optString("z0Id")); o.put("zoneName", o.optString("z0Name"))
            o.put("zoneRole", o.optString("z0Role"))
            o.remove("z0Id"); o.remove("z0Name"); o.remove("z0Role"); n++
        }
        if (n > 0) f(ctx, FILE).writeText(a.toString())
        return n
    }

    /** Fixes whose state could not be resolved - usually no network abroad. */
    fun unresolvedCount(ctx: Context) = samples(ctx).count { it.state == "?" }

    /** Re-runs geocoding over every unresolved fix. Returns how many were fixed. */
    @Synchronized
    fun resolveUnknowns(ctx: Context, resolver: (Double, Double) -> String): Int {
        val a = arr(ctx, FILE)
        var fixed = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("state") != "?") continue
            val lat = o.optDouble("lat", 0.0); val lon = o.optDouble("lon", 0.0)
            if (lat == 0.0 && lon == 0.0) continue
            val s = resolver(lat, lon)
            if (s != "?") { o.put("state", s); fixed++ }
        }
        if (fixed > 0) f(ctx, FILE).writeText(a.toString())
        return fixed
    }

    // ---------- work overrides ----------
    //
    // A gliding or Maxiflex schedule means no rule can predict a day off, so a
    // manual override always beats the calendar.

    /** Duty day boundaries, in minutes past midnight. Wrapping is allowed for
     *  night shifts, so 2200-0600 works as well as 0700-1500. */
    fun dutyStart(c: Context) = prefs(c).getInt("dutyStart", 7 * 60)
    fun dutyEnd(c: Context) = prefs(c).getInt("dutyEnd", 15 * 60)
    fun setDutyStart(c: Context, m: Int) = prefs(c).edit().putInt("dutyStart", m).apply()
    fun setDutyEnd(c: Context, m: Int) = prefs(c).edit().putInt("dutyEnd", m).apply()

    /**
     * How far from the duty station a stop still counts as normal duty — a
     * meeting across the river, a building down the road. Miles, decimals fine.
     */
    fun localAreaMiles(c: Context): Double =
        prefString(c, "localAreaMi", "10").toDoubleOrNull()?.takeIf { it >= 0 } ?: 10.0

    fun setLocalAreaMiles(c: Context, v: Double) = setPrefString(c, "localAreaMi", fmtNum(v))

    /**
     * The duty station a day belongs to, if it belongs to one. The day has to
     * have touched a duty-station datum — the morning arrival is enough — and
     * every fix taken during duty hours has to be inside that datum or within
     * the local area around it. Then the day is normal duty at that station,
     * earned in its state, whatever the 12:00 check happened to land on.
     * A day that left the local area (TDY, flying out at 1100) is not anchored
     * and falls back to the duty-hours fixes as before.
     * Returns the datum name and its state, or null.
     */
    fun dutyAnchorOf(day: List<Sample>, onClock: List<Sample>, duty: List<Datum>,
                     localMi: Double): Pair<String, String>? {
        val atDuty = day.filter { it.zoneRole == Datum.DUTY && it.state != "?" && it.state.isNotBlank() }
        if (atDuty.isEmpty()) return null
        val name = atDuty.groupingBy { it.zoneName }.eachCount().maxByOrNull { it.value }!!.key
        val here = atDuty.filter { it.zoneName == name }
        val st = here.groupingBy { it.state }.eachCount().maxByOrNull { it.value }!!.key
        val d = duty.firstOrNull { it.name == name }
        val cLat = d?.lat ?: here.first().lat
        val cLon = d?.lon ?: here.first().lon
        val local = onClock.all {
            it.zoneName == name ||
                (!(it.lat == 0.0 && it.lon == 0.0) &&
                    Zones.milesBetween(it.lat, it.lon, cLat, cLon) <= maxOf(localMi, d?.radiusMiles ?: 0.0))
        }
        return if (local) name to st else null
    }

    fun inDutyHours(c: Context, ts: Long): Boolean {
        val cal = Calendar.getInstance().apply { timeInMillis = ts }
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val a = dutyStart(c); val b = dutyEnd(c)
        return if (a <= b) m in a..b else (m >= a || m <= b)
    }

    // ---------- work schedule ----------

    /** Which weekdays are normally duty days. Calendar.SUNDAY=1 .. SATURDAY=7. */
    fun workWeekdays(c: Context): Set<Int> {
        val raw = prefs(c).getString("workWeekdays", "2,3,4,5,6") ?: "2,3,4,5,6"
        return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
    }

    fun setWorkWeekdays(c: Context, days: Set<Int>) =
        prefs(c).edit().putString("workWeekdays", days.sorted().joinToString(",")).apply()

    fun observeHolidays(c: Context) = prefs(c).getBoolean("observeHolidays", true)
    fun setObserveHolidays(c: Context, v: Boolean) =
        prefs(c).edit().putBoolean("observeHolidays", v).apply()

    /** Regular day off — the every-other-Friday of a 5-4-9 or Maxiflex schedule. */
    fun rdoOn(c: Context) = prefs(c).getBoolean("rdoOn", false)
    fun rdoWeekday(c: Context) = prefs(c).getInt("rdoWeekday", Calendar.FRIDAY)
    fun rdoWeeks(c: Context) = prefs(c).getInt("rdoWeeks", 2)
    fun rdoAnchor(c: Context): String = prefs(c).getString("rdoAnchor", "") ?: ""

    fun setRdo(c: Context, on: Boolean, weekday: Int, weeks: Int, anchor: String) =
        prefs(c).edit().putBoolean("rdoOn", on).putInt("rdoWeekday", weekday)
            .putInt("rdoWeeks", weeks.coerceAtLeast(1)).putString("rdoAnchor", anchor).apply()

    /** Mark a whole stretch worked or off in one go — a leave block, a TDY run. */
    fun setWorkOverrideRange(c: Context, from: String, to: String, value: String?): Int {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val a = try { fmt.parse(from) } catch (e: Exception) { null } ?: return 0
        val b = try { fmt.parse(to) } catch (e: Exception) { null } ?: return 0
        if (a.after(b)) return 0
        val cal = Calendar.getInstance().apply { time = a }
        var n = 0
        while (!cal.time.after(b)) {
            setWorkOverride(c, fmt.format(cal.time), value); n++
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return n
    }

    // ---------- settling somewhere new ----------

    /** Hours in one place before the app asks whether it deserves a datum. */
    fun dwellHours(c: Context) = prefs(c).getInt("dwellHours", 12)
    fun setDwellHours(c: Context, h: Int) = prefs(c).edit().putInt("dwellHours", h).apply()

    /** How far the fixes may spread and still count as one place, in miles. */
    fun dwellRadius(c: Context) = prefs(c).getFloat("dwellRadius", 15f).toDouble()
    fun setDwellRadius(c: Context, mi: Double) =
        prefs(c).edit().putFloat("dwellRadius", mi.toFloat()).apply()

    fun prefInt(c: Context, key: String, def: Int) = prefs(c).getInt(key, def)
    fun setPrefInt(c: Context, key: String, v: Int) = prefs(c).edit().putInt(key, v).apply()
    fun prefBool(c: Context, key: String, def: Boolean) = prefs(c).getBoolean(key, def)
    fun setPrefBool(c: Context, key: String, v: Boolean) = prefs(c).edit().putBoolean(key, v).apply()

    fun prefString(c: Context, key: String, def: String): String =
        prefs(c).getString(key, def) ?: def
    fun setPrefString(c: Context, key: String, v: String) =
        prefs(c).edit().putString(key, v).apply()

    // ---------- pay ----------

    /** W-2 Box 1 federal taxable wages. Pre-tax items are already out of it. */
    fun grossWages(c: Context) = prefs(c).getFloat("grossWages", 0f).toDouble()
    fun setGrossWages(c: Context, v: Double) =
        prefs(c).edit().putFloat("grossWages", v.toFloat()).apply()

    /**
     * Wages the payer already sourced to the counted state — a relocation W-2
     * with a figure in Box 16. These bypass the working-day ratio entirely:
     * someone else has decided where they belong and reported it.
     */
    fun directWages(c: Context) = prefs(c).getFloat("directWages", 0f).toDouble()
    fun setDirectWages(c: Context, v: Double) =
        prefs(c).edit().putFloat("directWages", v.toFloat()).apply()

    fun directLabel(c: Context): String =
        prefs(c).getString("directLabel", "Relocation W-2") ?: "Relocation W-2"
    fun setDirectLabel(c: Context, v: String) =
        prefs(c).edit().putString("directLabel", v).apply()

    /**
     * Adjusted basic pay off the SF-50, block 20C — basic plus locality. This is
     * the rate, not what you will earn in the year: a PCS changes locality
     * partway through, so a year's actual wages come from the LES, not this.
     */
    // Salaries are kept as the exact text typed. A 32-bit float drifts by a
    // fraction of a cent on six-figure amounts; a string does not. The old float
    // keys are still read as a fallback so nothing saved before is lost.
    /** The rate in effect today, from the SF-50 history. */
    fun annualSalary(c: Context): Double = Salaries.current(c)?.rate ?: 0.0
    fun setAnnualSalary(c: Context, v: Double) =
        setPrefString(c, "curAdjusted", if (v <= 0) "" else fmtNum(v))

    fun salaryEffective(c: Context): String = prefString(c, "salaryEffective", "")
    fun setSalaryEffective(c: Context, v: String) = setPrefString(c, "salaryEffective", v)

    /**
     * The rate before this one — block 12C, the "from" side of the SF-50 action.
     * A promotion and a PCS often land on the same paperwork, so there are two
     * rates in play for one year: this one through the day before the effective
     * date, annualSalary from it onward.
     */
    fun priorSalary(c: Context): Double =
        prefString(c, "priorAdjusted", "").toDoubleOrNull()
            ?: prefs(c).getFloat("priorSalary", 0f).toDouble()
    fun setPriorSalary(c: Context, v: Double) =
        setPrefString(c, "priorAdjusted", if (v <= 0) "" else fmtNum(v))

    /**
     * One side of an SF-50 pay action, as printed. "cur" is the TO side
     * (blocks 20A-20C), "prior" the FROM side (blocks 12A-12C). Each field is
     * the exact text typed, so what you saved is what you see.
     */
    data class Sf50(
        val grade: String,      // pay plan and grade or band, e.g. NH-04
        val base: String,       // basic pay, block 20A / 12A
        val locPct: String,     // locality percentage
        val locAmt: String,     // locality adjustment, block 20B / 12B
        val adjusted: String    // adjusted basic pay, block 20C / 12C
    )

    fun sf50(c: Context, side: String) = Sf50(
        prefString(c, "${side}Grade", ""),
        prefString(c, "${side}Base", ""),
        prefString(c, "${side}LocPct", ""),
        prefString(c, "${side}LocAmt", ""),
        prefString(c, "${side}Adjusted", "").ifBlank {
            // an adjusted figure saved by an earlier version, before this record existed
            val old = prefs(c).getFloat(if (side == "cur") "annualSalary" else "priorSalary", 0f)
            if (old > 0f) fmtNum(old.toDouble()) else ""
        }
    )

    fun setSf50(c: Context, side: String, r: Sf50) {
        setPrefString(c, "${side}Grade", r.grade.trim())
        setPrefString(c, "${side}Base", r.base)
        setPrefString(c, "${side}LocPct", r.locPct)
        setPrefString(c, "${side}LocAmt", r.locAmt)
        setPrefString(c, "${side}Adjusted", r.adjusted)
    }

    fun hoursPerDay(c: Context) = prefs(c).getFloat("hoursPerDay", 8f).toDouble()
    fun setHoursPerDay(c: Context, v: Double) =
        prefs(c).edit().putFloat("hoursPerDay", v.toFloat()).apply()

    /** Multiplies every text size in the app. 1.0 is the design size. */
    fun textScale(c: Context) = prefs(c).getFloat("textScale", 1f)
    fun setTextScale(c: Context, v: Float) = prefs(c).edit().putFloat("textScale", v).apply()

    // ---------- tax estimate inputs ----------

    fun filingJoint(c: Context) = prefs(c).getBoolean("filingJoint", true)
    fun setFilingJoint(c: Context, v: Boolean) = prefs(c).edit().putBoolean("filingJoint", v).apply()

    /** Federal AGI for the household — the denominator of the allocation. */
    fun totalIncome(c: Context) = prefs(c).getFloat("totalIncome", 0f).toDouble()
    fun setTotalIncome(c: Context, v: Double) =
        prefs(c).edit().putFloat("totalIncome", v.toFloat()).apply()

    fun exemptions(c: Context) = prefs(c).getInt("exemptions", 1)
    fun setExemptions(c: Context, n: Int) = prefs(c).edit().putInt("exemptions", n).apply()

    /** Virginia tax actually withheld so far. Usually zero when DFAS has Florida. */
    fun vaWithheld(c: Context) = prefs(c).getFloat("vaWithheld", 0f).toDouble()
    fun setVaWithheld(c: Context, v: Double) =
        prefs(c).edit().putFloat("vaWithheld", v.toFloat()).apply()

    // ---------- per-day income state ----------
    //
    // Which state earned a split travel day is a convention, and conventions
    // differ. When a CPA names one, it gets applied here rather than argued with.

    private val jsonCache = java.util.concurrent.ConcurrentHashMap<String, Pair<String, JSONObject>>()

    /**
     * A saved table of per-day choices, parsed once per saved version. These are
     * read for every day on every screen, and parsing each one 300 times per
     * screen was enough to stall the app. Read only — writers parse fresh.
     */
    private fun table(c: Context, key: String): JSONObject {
        val raw = prefs(c).getString(key, "{}") ?: "{}"
        jsonCache[key]?.let { if (it.first == raw) return it.second }
        val o = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
        jsonCache[key] = raw to o
        return o
    }

    fun incomeStateOverride(c: Context, date: String): String? {
        val o = table(c, "incomeStates")
        return if (o.has(date)) o.optString(date) else null
    }

    fun setIncomeStateOverride(c: Context, date: String, state: String?) {
        val o = JSONObject(prefs(c).getString("incomeStates", "{}") ?: "{}")
        if (state == null) o.remove(date) else o.put(date, state)
        prefs(c).edit().putString("incomeStates", o.toString()).apply()
    }

    /**
     * A day split by hand is stored as hours per state, "VA=4;DC=4". Hours, not
     * percentages, because hours are what a calendar invite or a sign-in sheet
     * shows. Returns null for anything that is not a split.
     */
    fun parseSplit(raw: String?): LinkedHashMap<String, Double>? {
        if (raw == null || !raw.contains('=')) return null
        val out = linkedMapOf<String, Double>()
        raw.split(';').forEach { part ->
            val kv = part.split('=')
            if (kv.size != 2) return@forEach
            val st = kv[0].trim().uppercase()
            val h = kv[1].trim().toDoubleOrNull() ?: return@forEach
            if (st.isNotBlank() && h > 0) out[st] = (out[st] ?: 0.0) + h
        }
        return if (out.values.sum() > 0) out else null
    }

    fun formatSplit(hours: Map<String, Double>): String =
        hours.filter { it.value > 0 }.entries.joinToString(";") { "${it.key}=${fmtNum(it.value)}" }

    /**
     * Where a day's wages belong, as shares that add up to 1: your split if you
     * made one, else your single state, else the duty-hours fix. A morning at
     * the Pentagon and an afternoon meeting in the District is VA 0.5, DC 0.5 —
     * only the Virginia half is Virginia-source.
     */
    fun incomeShares(c: Context, d: DaySummary): Map<String, Double> {
        val o = incomeStateOverride(c, d.date)
        parseSplit(o)?.let { h ->
            val tot = h.values.sum()
            return h.mapValues { it.value / tot }
        }
        return mapOf((o ?: d.primaryState) to 1.0)
    }

    fun incomeShareIn(c: Context, d: DaySummary, state: String): Double =
        incomeShares(c, d)[state] ?: 0.0

    fun isIncomeSplit(c: Context, d: DaySummary) = incomeShares(c, d).size > 1

    /** The state that earned most of the day — the whole of it unless you split it. */
    fun incomeStateOf(c: Context, d: DaySummary): String =
        incomeShares(c, d).maxByOrNull { it.value }?.key ?: d.primaryState

    /** "VA" for a whole day, "VA 4h · DC 4h" for a split one. */
    fun incomeLabel(c: Context, d: DaySummary): String {
        val h = parseSplit(incomeStateOverride(c, d.date))
        return if (h == null || h.size < 2) incomeStateOf(c, d)
        else h.entries.joinToString(" · ") { "${it.key} ${fmtNum(it.value)}h" }
    }

    // ---------- presence override ----------
    //
    // The state a fix resolves to drives the day count, and a reverse lookup can
    // fail or be wrong — a VPN, no signal, a tower on the far side of a line.
    // This is the correction, and the CSV records that a person made it.

    fun stateOverride(c: Context, date: String): String? {
        val o = table(c, "stateOverrides")
        return if (o.has(date)) o.optString(date) else null
    }

    /** Pass "VA", or "VA|FL" for a genuine travel day, or null to go back to auto. */
    fun setStateOverride(c: Context, date: String, states: String?) {
        val o = JSONObject(prefs(c).getString("stateOverrides", "{}") ?: "{}")
        if (states == null) o.remove(date) else o.put(date, states)
        prefs(c).edit().putString("stateOverrides", o.toString()).apply()
    }

    // ---------- your own categories ----------
    //
    // A custom category typed once used to vanish with the day. Named patterns
    // recur — situational telework, a standing detail — so they are kept.

    fun customCategories(c: Context): List<String> {
        val raw = prefString(c, "customCats", "")
        return raw.split("\n").map { it.trim() }.filter { it.isNotBlank() }
    }

    fun addCustomCategory(c: Context, label: String) {
        val v = label.trim()
        if (v.isBlank() || v in Status.all) return
        val cur = customCategories(c).toMutableList()
        if (cur.none { it.equals(v, true) }) {
            cur.add(v)
            setPrefString(c, "customCats", cur.joinToString("\n"))
        }
    }

    /**
     * Seeded once. Telework at the residence earns Florida-source wages; leave at
     * the residence earns nothing. Same house, same GPS fix, opposite tax
     * consequences — so they need separate labels from the start rather than
     * being reconstructed later.
     */
    fun seedDefaultCategories(c: Context) {
        if (prefBool(c, "catsSeeded", false)) return
        listOf(
            "Residence — TS telework situational",
            "Residence — telework regular"
        ).forEach { addCustomCategory(c, it) }
        setPrefBool(c, "catsSeeded", true)
    }

    fun removeCustomCategory(c: Context, label: String) {
        val cur = customCategories(c).filterNot { it.equals(label.trim(), true) }
        setPrefString(c, "customCats", cur.joinToString("\n"))
    }

    const val WORKED = "worked"
    const val OFF = "off"

    fun workOverride(c: Context, date: String): String? {
        val o = table(c, "workOverrides")
        return if (o.has(date)) o.optString(date) else null
    }

    fun setWorkOverride(c: Context, date: String, value: String?) {
        val raw = prefs(c).getString("workOverrides", "{}") ?: "{}"
        val o = JSONObject(raw)
        if (value == null) o.remove(date) else o.put(date, value)
        prefs(c).edit().putString("workOverrides", o.toString()).apply()
    }

    fun addManualDay(ctx: Context, date: String, state: String, d: Datum?) {
        append(
            ctx, Sample(
                System.currentTimeMillis(), date, 0.0, 0.0, 0, state,
                d?.id ?: Zones.OUT_ID, d?.name ?: Zones.OUT_NAME, d?.role ?: Datum.OTHER,
                TimeZone.getDefault().id, manual = true
            )
        )
    }

    // ---------- tags ----------

    @Synchronized
    fun setStatus(ctx: Context, date: String, status: String, note: String = "") {
        val o = if (f(ctx, TAGS).exists()) JSONObject(f(ctx, TAGS).readText()) else JSONObject()
        o.put(date, JSONObject().apply { put("status", status); put("note", note) })
        f(ctx, TAGS).writeText(o.toString())
    }

    fun statusOf(ctx: Context, date: String): Pair<String, String> =
        statusFrom(tagsJson(ctx), date)

    private fun tagsJson(ctx: Context): JSONObject? =
        if (!f(ctx, TAGS).exists()) null
        else try { JSONObject(f(ctx, TAGS).readText()) } catch (e: Exception) { null }

    private fun statusFrom(all: JSONObject?, date: String): Pair<String, String> {
        val o = all?.optJSONObject(date) ?: return Status.UNSET to ""
        return o.optString("status", Status.UNSET) to o.optString("note", "")
    }

    // ---------- rollups ----------

    fun days(ctx: Context, year: Int? = null): List<DaySummary> {
        val dutyDatums = datums(ctx).filter { it.role == Datum.DUTY }
        val localMi = localAreaMiles(ctx)
        val tags = tagsJson(ctx)   // the category file, read once for the whole pass
        val fromFixes = samples(ctx)
            .filter { year == null || it.date.startsWith("$year-") }
            .groupBy { it.date }
            .map { (date, list) ->
                val (st, note) = statusFrom(tags, date)
                val override = stateOverride(ctx, date)
                    ?.split("|")?.filter { it.isNotBlank() }?.toSet()
                // Where the money was earned is decided by the fixes taken during
                // duty hours. Flying out at 1700 does not move the day's wages; being
                // somewhere else at 1000 does. Falls back to the whole day when no fix
                // landed inside the window.
                val onClock = list.filter { inDutyHours(ctx, it.timestamp) }
                val pool = if (onClock.isNotEmpty()) onClock else list
                // a day at the duty station with nothing outside the local area is
                // normal duty there, even if one check caught a meeting in DC
                val anchor = dutyAnchorOf(list, onClock, dutyDatums, localMi)
                val primary = override?.firstOrNull()
                    ?: anchor?.second
                    ?: pool.groupingBy { it.state }.eachCount().maxByOrNull { it.value }?.key ?: ""
                val duringDuty = onClock.isNotEmpty()
                DaySummary(
                    date,
                    override ?: list.map { it.state }.toSet(),
                    list.map { it.zoneName }.toSet(),
                    list.map { it.zoneRole }.toSet(),
                    list.size, st, note, primary, duringDuty,
                    dutyAnchor = anchor?.first ?: ""
                )
            }
        // days filled in from the schedule, only where no real fix exists
        val have = fromFixes.map { it.date }.toSet()
        val recon = Reconstruct.all(ctx)
            .filter { (d, _) -> d !in have && (year == null || d.startsWith("$year-")) }
            .map { (date, r) ->
                val (st, note) = statusFrom(tags, date)
                val override = stateOverride(ctx, date)
                    ?.split("|")?.filter { it.isNotBlank() }?.toSet()
                DaySummary(
                    date,
                    override ?: setOf(r.state),
                    if (r.zone.isBlank()) emptySet() else setOf(r.zone),
                    if (r.role.isBlank()) emptySet() else setOf(r.role),
                    0,
                    if (st.isBlank()) r.status else st,
                    note,
                    override?.firstOrNull() ?: r.state,
                    false,
                    true
                )
            }
        return (fromFixes + recon).sortedBy { it.date }
    }

    /** Days where fixes landed in more than one state — arrival and departure days. */
    /**
     * States the day was actually resolved to. A fix taken with no network comes
     * back as "?", and counting that as a second state made ordinary days look
     * like travel days.
     */
    fun resolvedStates(d: DaySummary) = d.states.filter { it != "?" && it.isNotBlank() }

    fun isSplit(d: DaySummary) = resolvedStates(d).size > 1

    fun hasUnresolved(d: DaySummary) = d.states.any { it == "?" }

    /**
     * A day where the missing duty-hours fix actually matters: it touched more
     * than one state, so the duty-hours fix is what would decide which state
     * earned it, and you have not decided it yourself. A single-state day is
     * earned in that state however sparse its fixes, so it is never weak.
     */
    fun weakIncome(c: Context, d: DaySummary): Boolean =
        !d.reconstructed && !d.fixDuringDuty && d.dutyAnchor.isBlank() && isSplit(d) &&
                incomeStateOverride(c, d.date) == null &&
                workOverride(c, d.date) == null &&
                Workdays.earned(c, d)

    /**
     * Why a day is in Needs review, or null if it is not. Anything you have set
     * by hand on the day clears the matching reason.
     */
    fun reviewReason(c: Context, d: DaySummary): String? = when {
        d.reconstructed -> null
        d.status.isBlank() -> "no category — pick one"
        hasUnresolved(d) -> "a fix couldn't be matched to a state — set where you were"
        weakIncome(c, d) -> "travel day, no fix in duty hours — set which state earned it"
        else -> null
    }

    fun travelDays(ctx: Context, year: Int) = days(ctx, year).filter { isSplit(it) }

    fun stateDays(ctx: Context, state: String, year: Int) =
        days(ctx, year).count { state in it.states }

    fun datumDays(ctx: Context, name: String, year: Int) =
        days(ctx, year).count { name in it.zones }

    /** Days that earned wages attributable to a given state. */
    /**
     * The most recent unbroken run of TDY-categorized days: start, length, end.
     * Saves counting travel days on your fingers, and the log is what would
     * substantiate the voucher anyway.
     */
    fun lastTdyRun(ctx: Context): Triple<String, Int, String>? {
        val tdy = days(ctx, year())
            .filter { Status.dutyStatus(it.status) == "TDY" }
            .map { it.date }
            .sorted()
        if (tdy.isEmpty()) return null

        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var end = tdy.last()
        var start = end
        for (i in tdy.indices.reversed()) {
            if (tdy[i] == start) continue
            val c = Calendar.getInstance().apply { time = fmt.parse(start)!! }
            c.add(Calendar.DAY_OF_YEAR, -1)
            if (fmt.format(c.time) == tdy[i]) start = tdy[i] else break
        }
        val a = fmt.parse(start)!!.time
        val b = fmt.parse(end)!!.time
        val len = ((b - a) / 86_400_000L).toInt() + 1
        return Triple(start, len, end)
    }

    /** Worked days earned in a state; a day split by hours counts its share. */
    fun earningDays(ctx: Context, state: String, year: Int): Double =
        days(ctx, year).sumOf { if (Workdays.earned(ctx, it)) incomeShareIn(ctx, it, state) else 0.0 }

    fun earningDaysTotal(ctx: Context, year: Int) =
        days(ctx, year).count { Workdays.earned(ctx, it) }

    fun offStationDays(ctx: Context, year: Int) =
        days(ctx, year).count { Zones.OUT_NAME in it.zones }

    fun untaggedOutDays(ctx: Context, year: Int) =
        days(ctx, year).filter { Zones.OUT_NAME in it.zones && it.status == Status.UNSET }

    fun gapDays(ctx: Context, year: Int): List<String> {
        val logged = days(ctx, year).map { it.date }.toSet()
        val first = logged.minOrNull() ?: return emptyList()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance().apply { time = fmt.parse(first)!! }
        val end = Calendar.getInstance()
        val gaps = mutableListOf<String>()
        while (!cal.after(end)) {
            val k = fmt.format(cal.time)
            if (k !in logged) gaps.add(k)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return gaps
    }

    fun projectedStateDays(ctx: Context, state: String, year: Int): Int {
        val logged = days(ctx, year).size
        if (logged < 7) return -1
        return ((stateDays(ctx, state, year).toDouble() / logged) * 365).toInt()
    }

    // ---------- settings ----------

    /** The state whose days are counted against the limit. Change this when you PCS. */
    fun countedState(c: Context): String = prefs(c).getString("countedState", "VA") ?: "VA"
    fun setCountedState(c: Context, s: String) = prefs(c).edit().putString("countedState", s).apply()

    /** The state you are trying to prove you kept. */
    fun homeState(c: Context): String = prefs(c).getString("homeState", "FL") ?: "FL"
    fun setHomeState(c: Context, s: String) = prefs(c).edit().putString("homeState", s).apply()

    fun soft1(c: Context) = prefs(c).getInt("soft1", 125)
    fun soft2(c: Context) = prefs(c).getInt("soft2", 150)
    fun hard(c: Context) = prefs(c).getInt("hard", 175)
    fun limit(c: Context) = prefs(c).getInt("limit", 183)

    fun setSoft1(c: Context, n: Int) = prefs(c).edit().putInt("soft1", n).apply()
    fun setSoft2(c: Context, n: Int) = prefs(c).edit().putInt("soft2", n).apply()
    fun setHard(c: Context, n: Int) = prefs(c).edit().putInt("hard", n).apply()
    fun setLimit(c: Context, n: Int) = prefs(c).edit().putInt("limit", n).apply()

    fun promptHour(c: Context) = prefs(c).getInt("promptHour", 18)
    fun setPromptHour(c: Context, h: Int) = prefs(c).edit().putInt("promptHour", h).apply()

    fun checkHours(c: Context): List<Int> =
        (prefs(c).getString("hours", "0,6,9,14,18") ?: "0,6,9,14,18")
            .split(",").mapNotNull { it.trim().toIntOrNull() }.sorted()

    fun setCheckHours(c: Context, h: List<Int>) =
        prefs(c).edit().putString("hours", h.sorted().joinToString(",")).apply()

    fun email(c: Context): String = prefs(c).getString("email", "") ?: ""
    fun setEmail(c: Context, v: String) = prefs(c).edit().putString("email", v).apply()

    /** Warning stages reset each calendar year, and again if you change the counted state. */
    fun stageFired(c: Context): Int {
        val p = prefs(c)
        if (p.getInt("stageYear", 0) != year()) return 0
        if (p.getString("stageState", "") != countedState(c)) return 0
        return p.getInt("stage", 0)
    }

    fun setStageFired(c: Context, stage: Int) = prefs(c).edit()
        .putInt("stage", stage).putInt("stageYear", year())
        .putString("stageState", countedState(c)).apply()

    fun lastPrompted(c: Context): String = prefs(c).getString("lastPrompt", "") ?: ""
    fun setLastPrompted(c: Context, d: String) = prefs(c).edit().putString("lastPrompt", d).apply()

    // ---------- raw file access, for backup and restore ----------

    fun rawText(ctx: Context, name: String): String =
        if (f(ctx, name).exists()) f(ctx, name).readText() else ""

    fun writeRaw(ctx: Context, name: String, text: String) = f(ctx, name).writeText(text)

    const val F_SAMPLES = FILE
    const val F_TAGS = TAGS
    const val F_DATUMS = DATUMS

    /** Every setting as a plain map, so a backup captures the whole configuration. */
    fun settingsMap(ctx: Context): Map<String, Any?> = prefs(ctx).all

    fun applySettings(ctx: Context, map: Map<String, Any?>) {
        val e = prefs(ctx).edit()
        map.forEach { (k, v) ->
            when (v) {
                is String -> e.putString(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Float -> e.putFloat(k, v)
                is Double -> e.putFloat(k, v.toFloat())
                is Boolean -> e.putBoolean(k, v)
            }
        }
        e.apply()
    }

    /**
     * The day the duty station changes. Days are still counted per calendar year -
     * that is the law - but reports split either side of this date, because the year
     * you move is not comparable to a full year at the new station.
     */
    fun pcsDate(c: Context): String = prefs(c).getString("pcsDate", "") ?: ""
    fun setPcsDate(c: Context, v: String) = prefs(c).edit().putString("pcsDate", v.trim()).apply()

    /** Days in a state on or after the PCS date. */
    fun stateDaysFrom(ctx: Context, state: String, year: Int, from: String) =
        days(ctx, year).count { it.date >= from && state in it.states }

    /** Days in a state before the PCS date. */
    fun stateDaysBefore(ctx: Context, state: String, year: Int, before: String) =
        days(ctx, year).count { it.date < before && state in it.states }

    /** owner/repo that the build workflow publishes releases to. */
    fun updateRepo(c: Context): String =
        prefs(c).getString("updateRepo", "jmaustin001/Tesseract3") ?: ""
    fun setUpdateRepo(c: Context, v: String) = prefs(c).edit().putString("updateRepo", v.trim()).apply()

    fun onboarded(c: Context) = prefs(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = prefs(c).edit().putBoolean("onboarded", v).apply()

    fun eraseAll(ctx: Context) { f(ctx, FILE).delete(); f(ctx, TAGS).delete() }

    /**
     * Clears settings and datums so setup runs again. The log survives unless you
     * ask for it to go — changing where you live should not destroy the evidence of
     * where you were.
     */
    fun resetSetup(ctx: Context, eraseLog: Boolean) {
        prefs(ctx).edit().clear().apply()
        f(ctx, DATUMS).delete()
        if (eraseLog) eraseAll(ctx)
    }
}

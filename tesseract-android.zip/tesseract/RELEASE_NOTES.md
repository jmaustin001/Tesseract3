Fix: choosing a saved destination silently overrode the rates you had typed.

A destination saved without a lodging figure carried zero, and selecting it
replaced a perfectly good typed value with that zero — so the lodging cap
became nothing, the lodging line computed as nothing, and a red warning said
your lodging exceeded the cap. The number you entered was ignored rather than
lost, which is worse, because nothing on screen said so.

Destinations now fill the fields instead of overriding them. The lodging and
M&IE boxes are always visible and always editable, typing over either one
stops it tracking the destination, and changing the month refills lodging for
that month. What you type always wins.

Also: a destination can no longer be saved without a lodging figure, any that
already lack one are flagged in the list, and the TQSE screen can write the
current figures back onto a saved destination to repair it in place. The cap
warning no longer fires when there is simply no cap set.

1.41.0 — TDY estimate: try a trip or forecast the rest of the year.

A new "estimate · nothing saved" card on the TDY screen. What you type is
remembered between visits, but nothing reaches the trip log or the day log.

- One trip: where, state, dates, M&IE and lodging. Shows the tax-free M&IE,
  this year's total with it, the lodging ceiling, the workdays, and — for a
  trip outside Virginia — the salary earned there instead, the Virginia tax
  that takes off, and the Virginia days avoided. "Save this as a planned
  trip" opens it in the trip editor, ready to save into the log.
- Rest of the year: trips a month, days and workdays each, M&IE rate and the
  usual TDY state. Forecasts M&IE through 31 December, this year's total,
  workdays and salary moved out of Virginia, the Virginia tax that takes
  off, and Virginia days by 31 December at most against the 183 limit.

1.40.0 — A running TDY log, and what TDY does to the Virginia share.

- TDY log · year: every trip oldest first, with its M&IE and a running
  total, year arrows, and "earned so far". Planned trips show their M&IE
  greyed with no running figure until they happen.
- Each trip now carries the state the work was done in (filled from its
  datum when you pick one). Under each trip: its workdays, the salary on
  them at the SF-50 in effect, how many the log earns outside Virginia, and
  a gold warning for any TDY workday the log still earns in Virginia or that
  has no log entry.
- TDY and VA card: workdays on TDY, salary on them, and how much of it the
  log earns outside Virginia — the part that comes out of the Form 763 share.
- Put these days in the log (open a saved trip): logged days with no
  category become TDY (TDY Res for a residence datum, TDY Other otherwise);
  days with no entry are added by hand at the trip's state and datum; days
  with another category are left alone and counted; future days wait.
  Previewed, tap twice.
- Reports now include tesseract-tdy-trips.csv: every trip with days, M&IE,
  meal deductions, lodging ceiling, workdays, salary, salary outside the
  counted state, running M&IE total and note.

1.39.0 — TDY per diem: saved trips, tax-free M&IE year to date.

The TDY screen is now built around what M&IE puts in your pocket. It stays
separate from TQSE, which is taxable relocation money.

- Tax-free M&IE · year: M&IE earned so far this year (days through today),
  plus all trips this year including planned ones, and the trip count.
- With your salary: annual salary from your SF-50s, plus M&IE year to date,
  and salary plus every trip this year. Your combined marginal rate (default
  29.65% = 22% federal + 7.65% FICA, no Florida tax) shows the taxable pay it
  would take to net the same, and the tax it avoids.
- Trips: add, edit and delete, each with explicit Save. Each trip has where,
  travel-out and travel-back dates, M&IE and lodging per night (as read off
  GSA), government meals, the long-term flat rate if your orders authorize it,
  and a note. Live breakdown: full days, 75% travel days, meals, tax-free M&IE.
  Lodging shows as a ceiling reimbursed against receipts, never as take-home.
- Tie a trip to a datum: "Fill the dates from the log" takes the latest run of
  days at that datum or categorized TDY, and the trip shows how many of its
  days the log confirms. A residence datum warns that TDY where you live and
  commute from generally pays no lodging and may pay no M&IE.
- A trip spanning New Year is split between the two years.
- Saved destinations still fill a trip in one tap, and still feed TQSE.

1.38.0 — Clear a day, confirm future dates, official PP numbers, orders/leave.

Clear this day
- On the day screen and in the year view's day box: "Clear this day", tap
  twice. Removes everything entered by hand — days added from a datum, the
  category and note, the state, worked/day-off and earning choices, and a
  schedule-filled entry. Fixes the phone actually took are kept, and the
  confirmation says how many.

Future dates
- Opening a day after today asks "hasn't happened yet — enter it anyway?"
  before anything can be entered: on the day screen as a dialog, in the year
  view by holding back the datum and worked/day-off buttons until you confirm.

Pay periods
- Numbered the way the LES numbers them: biweekly, counted from the first
  period that starts in January. 20 Sep 2026 is PP 19, 4 Oct PP 20. Labels
  show the dates too: "PP 20 · Oct 4–17". A PP number typed under the old
  scheme is set aside; type one only if your LES disagrees.
- Fixed: day differences across a daylight-saving change could come out a
  day short. That shifted pay period numbers and could shift a regular day
  off; every such calculation now rounds to whole days.

Orders and leave
- Each pay period counts scheduled workdays on orders (TDY) and on leave and
  shows them: "On orders 3 days · leave 1 day — 6 of 10 workdays left to
  report". When orders and leave leave fewer workdays than the requirement,
  the period shows COVERED (violet) instead of short or open.

1.37.0 — TQSE lodging tax by where you stayed.

"The stay" › WHERE YOU STAYED replaces the single room rate and tax fields.
- The first entry runs from the first day; add an entry for each move or new
  room rate, from the day it starts. Every night is priced at the entry that
  covers it.
- Each entry has where (hotel, apartment, city), room per night, and tax per
  night — typed in dollars, or tap $ / % to enter it as a percentage of the
  room rate. A percentage shows the dollar figure it works out to.
- Explicit Save; a date before the first day, two entries on one date, or a
  bad date blocks the save and says why.
- Your existing room rate and tax become the first entry; nothing is lost.
- The result lists each place separately within each month.

1.36.1 — TQSE: room rate and tax per night are back in plain view.

"The stay" card now sits above the month-by-month ceilings, and the room rate
and tax per night fields come straight after the first day and day count. In
1.35 they were still there but pushed far down the screen. Nothing else
changes; saved figures are kept.

1.36.0 — Colors for your own categories; label rest days in one step.

A) Category colors
- Settings › Your categories: pick a color when adding a category (ten,
  none close to the five built-in colors). Tap an existing category's color
  square to change it.
- The year view's Category mode draws each custom category in its own
  color, and the legend lists them by name instead of one "Custom" key.

B) Rest days before the first fix
- The "before the first fix" card has a new REST DAYS — CATEGORY choice
  (defaults to a category with "Weekend" in its name).
- "Label them": gives every filled-in rest day that still has no category
  (weekends, federal holidays, regular days off) that category. Previewed
  with a count and date range, tap twice. Days you already categorized,
  workdays, and every day with a real GPS fix are left alone.
- Undo clears exactly the labels that button set.
- A new fill also applies the rest-day category.

1.35.0 — TQSE (LP) is priced day by day, each day at its own month's ceiling.

GSA rates change every 1 October, so a stay that runs from September into
October crosses two fiscal years. The screen used to apply one lodging ceiling
to every day.

- The stay now has a first day (YYYY-MM-DD) and a number of days, with a
  "Count through today" button. Every day is dated from the first one.
- "The locality, month by month" shows one row per month the stay touches,
  labeled with its fiscal year (Sep 2026 · FY26, Oct 2026 · FY27), each with
  its own lodging and M&IE ceiling. Rows are saved with an explicit button;
  unsaved or missing figures are marked in gold or red.
- A month with nothing saved is offered a figure but never silently given one:
  the saved destination's figure when its fiscal year matches, else an
  earlier month of the same fiscal year. A figure is never carried across
  1 October.
- The result breaks down by month: days, dates, ceiling, lodging and M&IE.
- The 30-day step-down to 75% is counted from the first day and does not
  reset at a month or fiscal year boundary.
- Tapping a saved destination fills only the months in its own fiscal year.

1.34.1 — Fixes the app not opening.

1.33 changed the dashboard's dollar figure so that every worked day (about
186 with the reconstructed days) recounted the whole year's scheduled
workdays — roughly 68,000 date calculations on the main screen before it
could draw. Android froze it on launch.

- The year's workday count and the federal holiday list are now worked out
  once and kept, keyed on your schedule settings so an edit still takes
  effect immediately.
- SF-50 history, the per-day override tables and the category file are each
  read once per pass instead of once per day.
- The dashboard prices worked days in a single pass.
- New: if the app ever crashes, the reason is saved on the phone and shown at
  the top of the dashboard on the next launch, with Copy details and Dismiss.
  Nothing is sent anywhere.

No figures change — same rules, same results, computed once instead of
hundreds of times.

1.34.0 — The duty station anchors the day.

A day that touched your duty-station datum (the morning arrival is enough),
and whose duty-hours fixes all stayed within the local area around it, is now
normal duty at that station — earned in its state and credited to it in
Earnings by place. A Pentagon 0630–1000, DC 1030–1230, Pentagon 1300 day is a
Pentagon day, even when the 12:00 check lands in the District.

- Settings › Duty hours › Local area around duty station (mi): default 10,
  decimals fine, explicit Save. 10 mi from the Pentagon covers DC, Crystal
  City, Rosslyn and Alexandria. 0 means only fixes inside the datum count.
- A day that leaves the local area (TDY, flying out mid-day) is not anchored
  and is decided by the duty-hours fixes as before.
- Presence is untouched: a DC stop still shows DC in "states present". The
  log tags such a day "local" instead of "split", and it is not counted as a
  travel day or flagged for review.
- The day screen says when Auto anchored the day. Tapping a state or Split
  by hours still overrides it.
- CSV income_state_source reads "duty station, local area" for these days.

1.33.0 — DC, and days split by hours.

Day screen › Which state were you in
- VA, FL and DC are now separate on/off chips; tap every state you were in.
  Auto goes back to what the GPS fixes say. A day in VA and DC is still a
  VA day for the 183-day count.

Day screen › Which state earned it
- DC added alongside VA and FL, for a day worked wholly in the District.
- New "Split by hours": type the hours worked in each state (decimals fine),
  see the percentages, then Save split. Nothing changes until you save;
  Remove split puts the day back. Stored as hours, e.g. VA 4h · DC 4h.
- No datum or radius is needed — the split is set on the day by hand.

Everywhere the day is counted, a split day counts its share: the dashboard,
year tallies, Earnings by place (the DC half shows as "Elsewhere in DC"),
the Form 763 allocation ratio, and the dollars and tax. The day CSV shows
the split in income_state, "split by hand, by hours" as the source, and two
new columns: va_share and va_pay.

1.32.0 — Earnings by place labels places by where they are; Re-match past fixes.

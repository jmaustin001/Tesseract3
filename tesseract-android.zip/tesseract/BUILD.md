# Building Tesseract — start to finish

No coding required. Two routes: one installs nothing on your computer, one is a
single click once set up. Pick either.

---

# Route A — build in the cloud (no software to install)

GitHub builds it on their computers and hands you the finished APK. About 15 minutes
the first time, 2 minutes for every rebuild after.

### 1. Make a free GitHub account
Go to **github.com** and sign up. Free tier is all you need.

### 2. Make an empty repository
- Click the **+** in the top right → **New repository**
- Name: `tesseract`
- Select **Private** (this is your tax data setup — no reason for it to be public)
- Leave every checkbox unticked
- Click **Create repository**

### 3. Upload the code
- Unzip `tesseract-android.zip` on your computer. You'll get a folder called `tesseract`.
- **Open that folder.** You should see `app`, `build.gradle.kts`, `settings.gradle.kts`,
  `gradle.properties`, `README.md`, and a hidden `.github` folder.
- On the GitHub page you just made, click **uploading an existing file**
- Drag the **contents** of the `tesseract` folder in — not the folder itself. This
  matters: `settings.gradle.kts` has to sit at the top level of the repository, not
  inside a subfolder.
- If `.github` doesn't come across (some computers hide it), see the note at the
  bottom of this file.
- Scroll down, click **Commit changes**

### 4. Wait for the build
- Click the **Actions** tab at the top
- A run called "Build APK" starts on its own. Yellow dot = building, green tick = done.
- First run takes 5–10 minutes. Later ones are faster.

### 5. Download the APK
- Click the finished run
- Scroll to **Artifacts** at the bottom
- Click **tesseract-apk** — it downloads a zip
- Unzip it. Inside is `app-debug.apk`.

### 6. Get it onto your phone
Email it to yourself, or drop it in Drive, then open it on the phone.
Jump to **Installing on the phone** below.

**To rebuild later** (after I change something): upload the changed files the same
way, and the build starts by itself.

---

# Route B — build on your own computer

One 2 GB install, then it's a menu click forever after.

### 1. Install Android Studio
**developer.android.com/studio** → Download → run the installer → accept every default.
It downloads the Android SDK on first launch. Let it finish.

### 2. Open the project
- Unzip `tesseract-android.zip`
- Android Studio → **Open** → select the `tesseract` folder → OK
- It syncs the project. First time takes a few minutes.
- **If it asks about the Gradle wrapper**, choose to create/use the recommended
  wrapper and let it proceed.
- **If a yellow bar offers to upgrade or install anything** (AGP, SDK components,
  build tools), click the accept option. Say yes to whatever it asks for.

### 3. Build
Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**

When it finishes, a notification appears in the bottom right with a **locate** link.
Click it to open the folder. The file is:

```
tesseract/app/build/outputs/apk/debug/app-debug.apk
```

### 4. Onto the phone
USB cable, or email it to yourself, or Drive.

**Even easier:** plug the phone in with USB debugging on, and press the green ▶ Run
button. It builds and installs in one go.

---

# Installing on the phone

Android blocks apps that didn't come from the Play Store until you say otherwise.

1. Tap the `app-debug.apk` file
2. "For your security, your phone isn't allowed to install unknown apps from this
   source" → tap **Settings**
3. Turn on **Allow from this source**
4. Back out, tap the file again, tap **Install**
5. "Play Protect doesn't recognize this app" → tap **Install anyway**

That warning is just saying nobody has published this app publicly. Correct — you
built it thirty seconds ago.

# First launch — do these three or it won't work

1. **Location: Allow all the time.** The setup wizard asks. Android gives you "while
   using the app" first; you have to go into the system screen and pick all the time.
   Without it, no background checks.
2. **Battery: Unrestricted.** Settings → Apps → Tesseract → Battery → Unrestricted.
   The dashboard flags this in red if it's not set. Android will throttle the
   background job otherwise and you'll get missing days.
3. **Notifications: Allow.** This is how the daily prompts and limit warnings reach you.

Then walk the five setup screens. Stand at the Oviedo house when you tap
**Use my position** if you want that center exact.

---

# About the "cut and paste into a Play Store app" idea

Worth being straight with you: that doesn't really exist for a project like this.
On-device compilers on the Play Store (AIDE and similar) can handle small single-file
Java apps, but they choke on modern Gradle and Jetpack Compose builds — which is what
this is. You'd spend longer fighting it than doing Route A.

Route A is the closest thing to what you're after: you never install a compiler, you
just upload files to a webpage and download the result.

# Putting it on the Play Store

You don't need to. Sideloading works indefinitely and the app never expires.

If you ever want it on Play anyway: $25 one-time developer registration, and the
debug APK won't do — you'd need **Build → Generate Signed Bundle / APK** and a
keystore file you keep forever. Since this app is for exactly one person and holds
your location history, publishing it is the wrong move. Keep sideloading.

---

# If something goes wrong

**Route A, no "Build APK" under Actions** — the `.github` folder didn't upload.
It's hidden on Mac (Cmd+Shift+. shows hidden files) and on Windows (View → Hidden
items). Easier fix: on GitHub click **Add file → Create new file**, type
`.github/workflows/build.yml` as the name — typing the slashes makes the folders —
then paste in the contents of that file from the zip and commit.

**Route A build fails red** — click the run, click the failed step, and send me the
last 20 lines of red text. That's usually a version thing I can fix in a minute.

**Route B, "SDK not found"** — Android Studio → Settings → Languages & Frameworks →
Android SDK → tick **Android 14 (API 34)** → Apply. Then Build again.

**Route B, sync fails on first open** — File → **Sync Project with Gradle Files**,
and accept anything it offers to download.

**App installs but never logs anything** — always-on location permission wasn't
granted. Dashboard → Tracking health → **Allow location all the time**.

**No daily prompt appears** — battery optimization. Settings → Apps → Tesseract →
Battery → Unrestricted.

package com.tesseract.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

/**
 * The day log answers one question. Domicile is argued on a different set of
 * facts entirely, and those live in filing cabinets rather than on a phone.
 * This is a place to record which ones are in hand.
 */
class DomicileActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { DomicileScreen() } }
    }
}

@Composable
private fun DomicileScreen() {
    val ctx = LocalContext.current
    val resumed = (ctx as? DomicileActivity)?.resumeTick ?: 0
    var tick by remember { mutableIntStateOf(0) }

    val done = remember(tick, resumed) { Domicile.heldCount(ctx) }
    // plain read — tick changing is what forces the recomposition
    fun checked(id: String) = Domicile.isChecked(ctx, id)
    fun toggle(id: String) { Domicile.toggle(ctx, id); tick++ }

    TessScreen("Domicile evidence", "$done of ${Domicile.ITEMS.size} in hand") {

        TCard("why this is separate", T.Violet) {
            Hint("The day count defends against statutory residency — a pure arithmetic " +
                    "test. Domicile is argued on where your life actually is, and no GPS " +
                    "log settles it. These are the facts that do. None of them live on " +
                    "this phone, so this is only a record of what you have.")
        }

        Spacer(Modifier.height(10.dp))
        TCard("checklist") {
            Domicile.ITEMS.forEachIndexed { i, item ->
                Row(
                    Modifier.fillMaxWidth().clickable { toggle(item.id) }
                        .padding(vertical = 9.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    val on = checked(item.id)
                    Box(
                        Modifier.padding(top = 2.dp).size(18.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (on) T.Teal else T.Glow)
                            .border(1.dp, if (on) T.Teal else T.Edge, RoundedCornerShape(5.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (on) Text("✓", fontSize = 11.sp, color = androidx.compose.ui.graphics.Color(0xFF051020),
                            fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.label, fontSize = 14.sp,
                            color = if (on) T.Hi else T.Mid,
                            fontWeight = if (on) FontWeight.Medium else FontWeight.Normal)
                        if (item.why.isNotBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(item.why, fontSize = 11.sp, color = T.Low, lineHeight = 14.sp)
                        }
                    }
                }
                if (i < Domicile.ITEMS.lastIndex) HorizontalDivider(color = T.Edge.copy(alpha = .4f))
            }
        }

        Spacer(Modifier.height(10.dp))
        TCard("share it", T.Cyan) {
            PrimaryBtn("Share the checklist") {
                val f = Domicile.writeFile(ctx)
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                ctx.startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Domicile evidence checklist")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Share checklist"))
            }
        }
    }
}

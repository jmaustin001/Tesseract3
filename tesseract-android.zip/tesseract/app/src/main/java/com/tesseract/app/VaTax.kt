package com.tesseract.app

/**
 * An estimate of what a nonresident owes, built the way Form 763 works.
 *
 * Virginia does not tax the allocated slice directly. It computes the tax you
 * would owe as a resident on all your income, then multiplies that by the
 * share of your income that came from Virginia. The two approaches give
 * different answers, and this follows the one the form uses.
 *
 * Rates confirmed current for 2026. Everything here is an estimate for
 * planning — it ignores credits, additions, subtractions, itemised deductions
 * and anything else a return would consider.
 */
object VaTax {

    data class Estimate(
        val totalIncome: Double,
        val vaIncome: Double,
        val allocationPct: Double,
        val deduction: Double,
        val exemptionTotal: Double,
        val taxableAsResident: Double,
        val taxAsResident: Double,
        val vaTax: Double,
        val withheld: Double,
        val shortfall: Double,
        val quartersLeft: Int,
        val perQuarter: Double,
        val effectiveOnVaWages: Double,
        /** Tax attributable to relocation wages — the part RITA should reimburse. */
        val taxOnRelocation: Double,
        /** Tax on ordinary wages — the part that is actually yours. */
        val taxYouBear: Double
    )

    const val STANDARD_SINGLE = 8_000.0
    const val STANDARD_JOINT = 16_000.0
    const val EXEMPTION = 930.0

    /** 2% to $3,000, 3% to $5,000, 5% to $17,000, 5.75% above. */
    fun taxOn(taxable: Double): Double {
        if (taxable <= 0) return 0.0
        var t = 0.0
        t += minOf(taxable, 3_000.0) * 0.02
        if (taxable > 3_000) t += (minOf(taxable, 5_000.0) - 3_000.0) * 0.03
        if (taxable > 5_000) t += (minOf(taxable, 17_000.0) - 5_000.0) * 0.05
        if (taxable > 17_000) t += (taxable - 17_000.0) * 0.0575
        return t
    }

    fun estimate(
        totalIncome: Double,
        vaIncome: Double,
        relocationIncome: Double = 0.0,
        joint: Boolean,
        exemptions: Int,
        withheld: Double,
        monthsElapsed: Int
    ): Estimate {
        val deduction = if (joint) STANDARD_JOINT else STANDARD_SINGLE
        val exemptTotal = EXEMPTION * exemptions.coerceAtLeast(0)
        val taxable = (totalIncome - deduction - exemptTotal).coerceAtLeast(0.0)
        val asResident = taxOn(taxable)
        val pct = if (totalIncome > 0) (vaIncome / totalIncome).coerceIn(0.0, 1.0) else 0.0
        val vaTax = asResident * pct
        val short = (vaTax - withheld).coerceAtLeast(0.0)

        // Virginia estimates are due in May, June, September and January
        val quarters = when (monthsElapsed) {
            in 0..4 -> 4; in 5..5 -> 3; in 6..8 -> 2; else -> 1
        }

        // relocation wages carry their share of the state tax, and RITA is meant
        // to reimburse substantially all of it
        val relocShare = if (vaIncome > 0) (relocationIncome / vaIncome).coerceIn(0.0, 1.0) else 0.0
        val onReloc = vaTax * relocShare

        return Estimate(
            totalIncome = totalIncome,
            vaIncome = vaIncome,
            allocationPct = pct,
            deduction = deduction,
            exemptionTotal = exemptTotal,
            taxableAsResident = taxable,
            taxAsResident = asResident,
            vaTax = vaTax,
            withheld = withheld,
            shortfall = short,
            quartersLeft = quarters,
            perQuarter = if (quarters > 0) short / quarters else short,
            effectiveOnVaWages = if (vaIncome > 0) vaTax / vaIncome else 0.0,
            taxOnRelocation = onReloc,
            taxYouBear = vaTax - onReloc
        )
    }
}

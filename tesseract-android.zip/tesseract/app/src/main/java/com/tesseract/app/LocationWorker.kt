package com.tesseract.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume

class LocationWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    @SuppressLint("MissingPermission")
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val client = LocationServices.getFusedLocationProviderClient(ctx)
        val loc = suspendCancellableCoroutine<Location?> { cont ->
            client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                .addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(null) }
        } ?: return if (runAttemptCount < 2) Result.retry() else Result.success()

        val lat = round5(loc.latitude)
        val lon = round5(loc.longitude)
        val state = resolveState(ctx, lat, lon)
        val datum = Zones.classify(ctx, lat, lon)
        val now = System.currentTimeMillis()
        val date = Store.dateKey(now)

        // The datum name and role are snapshotted into the sample, so renaming or
        // moving a datum later never rewrites what the log already says.
        Store.append(
            ctx, Sample(
                now, date, lat, lon, loc.accuracy.toInt(), state,
                datum?.id ?: Zones.OUT_ID,
                datum?.name ?: Zones.OUT_NAME,
                datum?.role ?: Datum.OTHER,
                TimeZone.getDefault().id, manual = false
            )
        )

        maybePrompt(ctx, date, state, datum, lat, lon)
        checkThresholds(ctx)
        return Result.success()
    }

    /**
     * One prompt per day, never repeated. Off-station fixes prompt immediately, since
     * that is the moment you know whether it is TDY or leave. Everything else waits
     * for the evening check.
     */
    private fun maybePrompt(
        ctx: Context, date: String, state: String, datum: Datum?, lat: Double, lon: Double
    ) {
        if (Store.lastPrompted(ctx) == date) return
        if (Store.statusOf(ctx, date).first != Status.UNSET) return

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (datum != null && hour < Store.promptHour(ctx)) return

        val summary = if (datum != null) {
            "Fix in ${States.fullName(state)}, inside ${datum.name}."
        } else {
            val duty = Zones.firstWithRole(ctx, Datum.DUTY)
            if (duty != null)
                "Fix in ${States.fullName(state)}, ${Zones.milesFrom(duty, lat, lon).toInt()} mi from ${duty.name}."
            else "Fix in ${States.fullName(state)}, outside every datum."
        }
        Notifier.askDay(ctx, date, summary, Status.guessFor(datum?.role ?: Datum.OTHER))
        Store.setLastPrompted(ctx, date)
    }

    /**
     * State comes from reverse geocoding, never from a radius: a 20-mile circle on
     * Crystal City reaches into DC and Maryland, which are not Virginia days.
     */
    private fun resolveState(ctx: Context, lat: Double, lon: Double): String = try {
        @Suppress("DEPRECATION")
        val r = Geocoder(ctx, Locale.US).getFromLocation(lat, lon, 1)
        (r?.firstOrNull()?.let { States.forAddress(it.adminArea, it.countryCode) } ?: "?")
    } catch (e: Exception) {
        "?"  // offline; the coordinates are still on record
    }

    /** Three stages, each firing once per year, against whichever state you are counting. */
    private fun checkThresholds(ctx: Context) {
        val year = Store.year()
        val st = Store.countedState(ctx)
        val name = States.fullName(st)
        val count = Store.stateDays(ctx, st, year)
        val fired = Store.stageFired(ctx)

        val s1 = Store.soft1(ctx); val s2 = Store.soft2(ctx)
        val hard = Store.hard(ctx); val limit = Store.limit(ctx)

        val stage = when {
            count >= limit -> 4
            count >= hard -> 3
            count >= s2 -> 2
            count >= s1 -> 1
            else -> 0
        }
        if (stage <= fired) return

        when (stage) {
            1 -> Notifier.alert(ctx, "$count days in $name",
                "First checkpoint at $s1. ${limit - count} days of room left before $limit.")
            2 -> Notifier.alert(ctx, "$count days in $name — second checkpoint",
                "Past $s2. ${limit - count} days left before $limit. Worth planning the rest of the year deliberately.")
            3 -> Notifier.alert(ctx, "$count days in $name — hard warning",
                "Past $hard. Only ${limit - count} days remain before $limit. Talk to your CPA before booking anything else in $name.")
            4 -> Notifier.alert(ctx, "$count days in $name — $limit reached",
                "You are at or past $limit days in $name this calendar year.")
        }
        Store.setStageFired(ctx, stage)
    }

    private fun round5(v: Double) = String.format(Locale.US, "%.5f", v).toDouble()
}

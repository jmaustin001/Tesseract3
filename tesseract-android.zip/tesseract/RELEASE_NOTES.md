Dark rebuild. The dashboard is now a hub rather than one long scroll:
hero counter with the warning stages marked on the bar, a card that
appears only when something needs attention, and four tiles into their
own screens — Year view, Datums, Reports, Settings.

Also in this build:
- Year grid moved to its own screen, tappable, with a state/category colour toggle
- In-app updates: check, download and install from Settings
- Earlier builds can be listed and rolled back to
- Battery: retry storms capped, one-tap optimisation exemption, hibernation warning

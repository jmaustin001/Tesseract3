Pinch to zoom actually works now. Every square in the year grid is clickable,
and a child that handles touch swallows the pinch before the container sees it
— so the gesture is now caught on the initial pass and only claimed once two
fingers are down. Taps still reach the squares. Up to five times, with a reset
button and the current magnification shown.

The $ now marks every workday in both views, whichever state earned it, not
only Virginia days and not only in the state view.

The dashboard leads with earning days. Days present is still there, still with
the warning stages on the bar, because presence is what triggers statutory
residency and earning days do not. Two numbers, the one you asked for first.

Reports now attach five files instead of three: the day-by-day log, the raw
fixes, the JSON backup, the wage allocation worksheet with its tax estimate,
and the domicile evidence checklist.

Also fixed: the category legend still carried the old duplicate color for
Custom, and now shows magenta along with a key for the $.

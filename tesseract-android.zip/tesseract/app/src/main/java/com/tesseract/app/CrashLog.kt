package com.tesseract.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * If the app ever dies, the reason is written to a file before it goes, and the
 * dashboard shows it on the next launch with a Copy button — so a crash can be
 * pasted into a conversation instead of guessed at. Nothing leaves the phone.
 */
object CrashLog {
    private const val FILE = "last_crash.txt"

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val ver = try {
                    app.packageManager.getPackageInfo(app.packageName, 0).versionName
                } catch (x: Exception) { "?" }
                File(app.filesDir, FILE).writeText(
                    "Tesseract $ver · " +
                        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) +
                        " · thread ${t.name}\n\n" + sw.toString().take(12_000)
                )
            } catch (x: Exception) { }
            previous?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? =
        File(ctx.filesDir, FILE).takeIf { it.exists() }?.readText()

    fun clear(ctx: Context) { File(ctx.filesDir, FILE).delete() }
}

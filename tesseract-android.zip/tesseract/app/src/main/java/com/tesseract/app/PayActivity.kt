package com.tesseract.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class PayActivity : ComponentActivity() {
    var resumeTick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); resumeTick++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TessTheme { PayScreen() } }
    }
}

private fun usd(v: Double) = "$" + String.format(Locale.US, "%,.0f", v)
private fun usd2(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)

@Composable
private fun PayScreen() {
    val ctx = LocalContext.current
    val year = Store.year()
    val resumed = (ctx as? PayActivity)?.resumeTick ?: 0
    var tick by remember { mutableIntStateOf(0) }

    val snaps = remember(tick, resumed) { Pay.forYear(ctx, year) }
    val latest = snaps.lastOrNull()
    val proj = remember(tick, resumed) { Pay.project(ctx, year, Pay.everyDays(ctx)) }
    val counted = Store.countedState(ctx)

    var adding by remember { mutableStateOf(snaps.isEmpty()) }
    var end by remember { mutableStateOf(Store.today()) }
    // a half-finished entry survives leaving the screen
    var gross by remember { mutableStateOf(Store.prefString(ctx, "payDraftGross", "")) }
    var taxable by remember { mutableStateOf(Store.prefString(ctx, "payDraftTaxable", "")) }
    var fed by remember { mutableStateOf(Store.prefString(ctx, "payDraftFed", "")) }
    var st by remember { mutableStateOf(Store.prefString(ctx, "payDraftState", "")) }
    var msg by remember { mutableStateOf("") }

    TessScreen("Pay", "year to date · $year") {

        SalaryCard { tick++ }
        Spacer(Modifier.height(10.dp))

        if (latest != null) {
            TCard("as of ${latest.periodEnd}", T.Gold) {
                Text(usd(latest.ytdTaxable), fontSize = 34.sp,
                    fontWeight = FontWeight.Bold, color = T.Gold)
                Text("taxable wages year to date — the Box 1 figure so far",
                    fontSize = 12.sp, color = T.Mid)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip(usd(latest.ytdGross), "gross", T.Cyan, Modifier.weight(1f))
                    StatChip(usd(latest.ytdFederal), "federal", T.Teal, Modifier.weight(1f))
                    StatChip(usd(latest.ytdState), "$counted held", 
                        if (latest.ytdState > 0) T.Teal else T.Danger, Modifier.weight(1f))
                }
                if (latest.ytdState <= 0.0) {
                    Spacer(Modifier.height(12.dp))
                    Text("Nothing withheld for $counted.", fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold, color = T.Danger)
                    Spacer(Modifier.height(4.dp))
                    Hint("Expected while your record says Florida — but the liability is " +
                            "accruing anyway, and $counted wants it quarterly. This is the " +
                            "figure to watch the day after a PCS, because if it never starts " +
                            "you need estimated payments rather than a surprise in April.")
                }
            }
        }

        if (proj != null) {
            Spacer(Modifier.height(10.dp))
            TCard("where the year lands", T.Cyan) {
                Hint("Straight-line from ${proj.throughDate}, ${proj.daysElapsed} days in. " +
                        "Early in the year this swings a lot; by autumn it is close.")
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth()) {
                    Text("Taxable wages", fontSize = 13.sp, color = T.Mid,
                        modifier = Modifier.weight(1f))
                    Text(usd(proj.projectedTaxable), fontSize = 15.sp,
                        fontWeight = FontWeight.Bold, color = T.Hi)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text("Federal withheld", fontSize = 13.sp, color = T.Mid,
                        modifier = Modifier.weight(1f))
                    Text(usd(proj.projectedFederal), fontSize = 14.sp, color = T.Hi)
                }
                Spacer(Modifier.height(12.dp))
                PrimaryBtn("Use $" + String.format(Locale.US, "%,.0f", proj.projectedTaxable) +
                        " as the wage base") {
                    Store.setGrossWages(ctx, proj.projectedTaxable)
                    msg = "Allocation screen updated."
                }
                Spacer(Modifier.height(6.dp))
                Hint("Feeds the wage allocation directly, so you stop typing it in twice. " +
                        "Swap it for the real Box 1 once the W-2 arrives.")
            }
        }

        if (snaps.isNotEmpty() && Pay.missedCount(ctx, year) > 0) {
            Spacer(Modifier.height(10.dp))
            TCard("missed entries", T.Edge) {
                Text("${Pay.missedCount(ctx, year)} period" +
                        "${if (Pay.missedCount(ctx, year) == 1) "" else "s"} not entered",
                    fontSize = 14.sp, color = T.Hi)
                Spacer(Modifier.height(6.dp))
                Hint("Nothing is lost. Every LES restates the year to date, so the next " +
                        "entry you make carries the full total and the record catches itself " +
                        "up. There is no gap to go back and fill.")
            }
        }

        Spacer(Modifier.height(10.dp))
        if (!adding) {
            PrimaryBtn("Add an LES") { adding = true; end = Pay.nextDue(ctx) ?: Store.today() }
        } else {
            TCard("from the LES", T.Teal) {
                Hint("Four figures off the year-to-date column. Nothing is stored but the " +
                        "numbers — no screenshot, no document, nothing with your name on it.")
                Spacer(Modifier.height(14.dp))
                DarkField(end, "Period ending (YYYY-MM-DD)", Modifier.fillMaxWidth()) { end = it }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(gross, "YTD gross", Modifier.weight(1f), numeric = true) { gross = it; Store.setPrefString(ctx, "payDraftGross", it) }
                    DarkField(taxable, "YTD taxable", Modifier.weight(1f), numeric = true) {
                        taxable = it; Store.setPrefString(ctx, "payDraftTaxable", it)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkField(fed, "YTD federal tax", Modifier.weight(1f), numeric = true) {
                        fed = it; Store.setPrefString(ctx, "payDraftFed", it)
                    }
                    DarkField(st, "YTD $counted tax", Modifier.weight(1f), numeric = true) {
                        st = it; Store.setPrefString(ctx, "payDraftState", it)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryBtn("Save", Modifier.weight(1f), accent = T.Teal) {
                        if (taxable.toDoubleOrNull() != null) {
                            Pay.upsert(ctx, PaySnapshot(
                                end.trim(),
                                gross.toDoubleOrNull() ?: 0.0,
                                taxable.toDoubleOrNull() ?: 0.0,
                                fed.toDoubleOrNull() ?: 0.0,
                                st.toDoubleOrNull() ?: 0.0,
                                counted
                            ))
                            adding = false; tick++
                            gross = ""; taxable = ""; fed = ""; st = ""
                            listOf("payDraftGross", "payDraftTaxable", "payDraftFed",
                                "payDraftState").forEach { Store.setPrefString(ctx, it, "") }
                            msg = "Saved."
                        } else msg = "YTD taxable is the one figure that is needed."
                    }
                    GhostBtn("Cancel", Modifier.weight(1f), color = T.Low) { adding = false }
                }
            }
        }

        if (msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(msg, fontSize = 12.sp, color = T.Teal)
        }

        if (snaps.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            TCard("the record") {
                snaps.reversed().forEachIndexed { i, p ->
                    val prev = snaps.getOrNull(snaps.size - i - 2)
                    val d = Pay.since(prev, p)
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.periodEnd, fontSize = 13.sp,
                                fontWeight = FontWeight.Medium, color = T.Hi)
                            Text("since last: ${usd2(d.ytdTaxable)} taxable",
                                fontSize = 10.sp, color = T.Low)
                        }
                        Text(usd(p.ytdTaxable), fontSize = 14.sp, color = T.Hi)
                        TextButton(onClick = { Pay.delete(ctx, p.periodEnd); tick++ }) {
                            Text("×", fontSize = 16.sp, color = T.Low)
                        }
                    }
                    HorizontalDivider(color = T.Edge.copy(alpha = .4f))
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        PayReminderCard { tick++ }
    }
}

@Composable
private fun PayReminderCard(changed: () -> Unit) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Pay.remindersOn(ctx)) }
    var anchor by remember { mutableStateOf(Pay.anchor(ctx)) }
    var every by remember { mutableStateOf(Pay.everyDays(ctx).toString()) }

    TCard("reminders", T.Violet) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Remind me each payday", fontSize = 14.sp, color = T.Hi)
                Text(Pay.nextDue(ctx)?.let { "Next on $it" } ?: "Set a payday below",
                    fontSize = 11.sp, color = T.Low)
            }
            Switch(checked = on, onCheckedChange = {
                on = it; Pay.setRemindersOn(ctx, it)
                if (it) PayScheduler.schedule(ctx) else PayScheduler.cancel(ctx)
                changed()
            })
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DarkField(anchor, "A payday (YYYY-MM-DD)", Modifier.weight(2f)) {
                anchor = it
                if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)) {
                    Pay.setAnchor(ctx, it)
                    if (on) PayScheduler.schedule(ctx)
                    changed()
                }
            }
            DarkField(every, "Every N days", Modifier.weight(1f), numeric = true) {
                every = it
                it.toIntOrNull()?.let { n -> Pay.setEveryDays(ctx, n); changed() }
            }
        }
        Spacer(Modifier.height(8.dp))
        Hint("Any one payday sets the pattern; the rest are counted from it. Miss one and " +
                "nothing breaks — the next LES carries the year-to-date totals forward.")
    }
}

@Composable
private fun SalaryCard(changed: () -> Unit) {
    val ctx = LocalContext.current
    var salary by remember { mutableStateOf(Store.annualSalary(ctx).let {
        if (it <= 0) "" else String.format(Locale.US, "%.2f", it) }) }
    var eff by remember { mutableStateOf(Store.salaryEffective(ctx)) }
    val s = salary.toDoubleOrNull() ?: 0.0

    TCard("salary · SF-50", T.Gold) {
        DarkField(salary, "Adjusted basic pay, block 20C", Modifier.fillMaxWidth(),
            numeric = true) {
            salary = it
            Store.setAnnualSalary(ctx, it.toDoubleOrNull() ?: 0.0); changed()
        }
        Spacer(Modifier.height(8.dp))
        DarkField(eff, "Effective date, block 4 (YYYY-MM-DD)", Modifier.fillMaxWidth()) {
            eff = it
            if (it.isBlank() || Regex("\\d{4}-\\d{2}-\\d{2}").matches(it))
                Store.setSalaryEffective(ctx, it)
        }

        if (s > 0) {
            // OPM's own divisor: 2,087 hours a year
            val hourly = s / 2087.0
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip(usd2(hourly), "hourly", T.Gold, Modifier.weight(1f))
                StatChip(usd(hourly * 8), "daily", T.Gold, Modifier.weight(1f))
                StatChip(usd(hourly * 80), "per pay period", T.Gold, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Hint("Worked the way OPM does it: salary over 2,087 hours. This is what one " +
                    "ordinary day of pay is, and what to check an LES against.")
        }

        Spacer(Modifier.height(12.dp))
        Hint("Block 20C is the new rate — basic pay plus locality. Block 12C is the old one, " +
                "the \"from\" side of the action. A PCS changes your locality partway " +
                "through the year, so this is a rate, not what you will earn in the year: " +
                "for that the LES year-to-date figures below are the real record. Until you " +
                "enter one, the dashboard estimates from this salary instead.")
    }
}
